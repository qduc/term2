export const ASK_USER_CUSTOM_ANSWER_LABEL = 'Something else… (type your answer)';
export const ASK_USER_DECLINE_LABEL = 'Decline to answer';
export const ASK_USER_DECLINE_RESULT = 'User declined to answer.';
export const ASK_USER_NO_ANSWER_RESULT = 'User did not provide an answer.';
export const ASK_USER_NO_RESPONSE_DISPLAY = 'No response from user';
export const ASK_USER_SUBMIT_LABEL = 'Submit answer';
export const ASK_USER_PREV_QUESTION_LABEL = '◀ Previous question';
export const ASK_USER_NEXT_QUESTION_LABEL = 'Next question ▶';

/**
 * Answers that end the whole ask_user call rather than answering the question
 * on screen. Multi-question prompts must not fold these into their answer list
 * and advance: declining, or cancelling with Escape, finishes the tool.
 */
export const isAskUserTerminalAnswer = (answer: string | undefined): boolean =>
  answer === ASK_USER_DECLINE_RESULT || answer === ASK_USER_NO_ANSWER_RESULT;

export const ASK_USER_RESERVED_OPTION_LABELS = [
  ASK_USER_CUSTOM_ANSWER_LABEL,
  ASK_USER_DECLINE_LABEL,
  ASK_USER_SUBMIT_LABEL,
] as const;

