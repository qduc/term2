import path from 'path';
import process from 'process';
import { validateCommandSafety } from '../../utils/shell/command-safety/index.js';
import { logValidationError as logValidationErrorUtil } from '../../utils/shell/command-logger.js';
import type { ILoggingService, ISettingsService } from '../../services/service-interfaces.js';
import type { ExecutionContext } from '../../services/execution-context.js';
import type { ShellSandboxRunner } from '../../utils/shell/sandbox/sandbox-policy.js';
import type { SessionAccessState } from '../../services/session/session-access-state.js';
import type { NestedToolCompatibilityState } from '../../services/session/nested-tool-compatibility-state.js';

/** Minimal shape of the shell params the approval decision reads. */
export interface ShellApprovalRequest {
  command: string;
  sandbox?: 'default' | 'unsandboxed';
}

/** Everything `decideShellNeedsApproval` consults to reach a decision. */
export interface ShellApprovalDependencies {
  loggingService: ILoggingService;
  settingsService: ISettingsService;
  executionContext?: ExecutionContext;
  shellSandboxRunner: ShellSandboxRunner;
  /** Root-only: Docker host-control grants/denials. */
  sessionAccess?: SessionAccessState;
  /** Isolated legacy protocol for nested tools only. */
  nestedCompatibility?: NestedToolCompatibilityState;
  /** Root-only: pause denied reads through the application-owned post-execute seam. */
  postExecuteDeniedRead?: boolean;
}

/**
 * Strip redundant 'cd <path> &&' prefix if it targets the current working directory
 */
export function stripRedundantCd(command: string, cwd: string): string {
  const cdPattern = /^cd\s+([^\s&]+)\s+&&\s+(.+)$/;
  const match = command.match(cdPattern);

  if (match) {
    const [, targetPath, restOfCommand] = match;
    // Resolve the target path to absolute
    const absoluteTargetPath = path.resolve(cwd, targetPath);

    // If target path is same as cwd, strip the cd part
    if (absoluteTargetPath === cwd) {
      return restOfCommand;
    }
  }

  return command;
}

export function isMutatingCommand(command: string, cwd: string, log: ILoggingService): boolean {
  return validateCommandSafety(stripRedundantCd(command, cwd), log); // true = YELLOW/RED
}

export function getConversationSessionId(context: unknown): string | undefined {
  if (!context || typeof context !== 'object') return undefined;
  const runContext = (context as { context?: unknown }).context;
  if (!runContext || typeof runContext !== 'object') return undefined;
  const sessionId = (runContext as { sessionId?: unknown }).sessionId;
  return typeof sessionId === 'string' && sessionId.length > 0 ? sessionId : undefined;
}

/**
 * Decide whether a shell command requires user approval.
 *
 * Extracted verbatim from the `shell` tool's `needsApproval` closure so the
 * policy can be reasoned about without the execution machinery. Behavior,
 * including logging side effects and the fail-safe `true` on validation
 * errors, is unchanged.
 *
 * @returns `true` when the command must prompt for approval, `false` when it
 * may run without prompting.
 */
export async function decideShellNeedsApproval(
  params: ShellApprovalRequest,
  context: unknown,
  deps: ShellApprovalDependencies,
): Promise<boolean> {
  const {
    loggingService,
    settingsService,
    executionContext,
    shellSandboxRunner,
    sessionAccess,
    nestedCompatibility,
    postExecuteDeniedRead = false,
  } = deps;
  // Create command logger function with dependencies
  const logValidationError = (message: string) => logValidationErrorUtil(settingsService, message);
  // Read per call: the sandbox can be toggled while a session is running, and a
  // stale value would let needsApproval and execute disagree about Docker.
  const isSandboxEnabled = () => settingsService.get('sandbox.enabled') !== false;

  if (settingsService.get('shell.autoApproveMode') === 'always') {
    loggingService.security('Shell tool needsApproval: auto-approved in YOLO mode', {
      command: typeof params?.command === 'string' ? params.command.substring(0, 100) : String(params?.command),
    });
    return false;
  }
  try {
    if (params.sandbox === 'unsandboxed') {
      return true;
    }

    const cwd = executionContext?.getCwd() || process.cwd();
    const sessionId = getConversationSessionId(context);
    const sandboxEnabled = isSandboxEnabled();
    const dockerHostControlRequested =
      sandboxEnabled &&
      (sessionAccess?.requiresDockerApproval(params.command) ??
        nestedCompatibility?.docker.requiresApproval(sessionId, params.command) ??
        false);
    if (
      dockerHostControlRequested &&
      !(sessionAccess?.hasDockerProject(cwd) ?? nestedCompatibility?.docker.hasProject(cwd) ?? false) &&
      !(
        sessionAccess?.hasDockerSessionGrant(cwd) ??
        (sessionId ? nestedCompatibility?.docker.hasSession(sessionId, cwd) : false) ??
        false
      )
    ) {
      return true;
    }
    const sshService = executionContext?.getSSHService();
    if (!sshService && sandboxEnabled) {
      // If a previous sandboxed run denied a read for this command, require
      // approval so the user can allow/remember the path or escape unsandboxed.
      if (!postExecuteDeniedRead && nestedCompatibility?.deniedReads.peek(params.command)) {
        return true;
      }
      const availability = await shellSandboxRunner.availability();
      if (availability.type === 'available') {
        return false;
      }
      return true;
    }

    const isDangerous = isMutatingCommand(params.command, cwd, loggingService);

    // Log security event for all shell commands with dangerous flag
    loggingService.security('Shell tool needsApproval check', {
      commands: [params.command.substring(0, 100)], // Truncate for safety
      optimizedCommand: stripRedundantCd(params.command, cwd).substring(0, 100),
      isDangerous,
    });

    return isDangerous;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logValidationError(`Validation failed: ${errorMessage}`);
    loggingService.error('Shell tool validation error', {
      error: errorMessage,
      // params.command may itself be why we're in this catch (e.g. undefined
      // after a malformed tool call), so don't re-dereference it unguarded.
      commands: [typeof params.command === 'string' ? params.command.substring(0, 100) : String(params.command)],
    });
    return true; // fail-safe: require approval on validation errors
  }
}
