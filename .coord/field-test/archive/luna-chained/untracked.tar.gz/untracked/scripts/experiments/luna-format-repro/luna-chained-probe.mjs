#!/usr/bin/env node
// Luna CHAINED-state harness (server-side previous_response_id chains).
//
// Why this exists: luna-format-repro.mjs drives the Codex Responses endpoint
// DIRECTLY (stateless: every history turn replays the full input array), and
// its paired A/B fired 0/8. The prime suspect for production Luna
// apply_patch runaways is server-side chained state: the app's Codex WS lane
// sends previous_response_id + a trimmed delta (ChainedWireState), which no
// direct-endpoint replay can replicate. This script drives the SAME
// production path the app uses: ApplicationRunLoop -> CodexResponsesWSModel
// (websocket transport) with previousResponseId carried between turns.
//
// Production-mirror design (derived from real traffic, e.g. session
// 07-28-48_9bff1): turn0 is a FULL-HISTORY request (no previousResponseId:
// additional_tools + developer instructions + user message) in which the
// model issues a REAL tool call; every later turn sends previous_response_id
// plus exactly ONE function_call_output answering THAT turn's real call_id.
// The server accepts the chain because each output's call_id was minted by
// the server in the preceding response. Synthetic callIds (call_synth_*)
// are rejected with 400 'No tool output found for function call ...', and
// the client orphan-guard throws OrphanedChainedToolOutputError for them —
// so every callId in this harness comes from a live model turn.
//
// Tool policy: the agent carries only read_file (executes FOR REAL against
// the worktree — harmless, in-workspace) and apply_patch (answered
// synthetically by the interceptor, so the probe never writes files).
// Shell is excluded entirely. Approval prompts are disabled
// (shell.autoApproveMode 'always' + interceptor short-circuit) so a turn
// never parks on an approval and breaks the callId chain: every turn must
// yield exactly one real function_call event or the harness fails fast.
//
// After N_HISTORY chained turns, the probe turn sends an oversized
// apply_patch consolidation ask as a single tool_result delta (the guard's
// shape: codex + gpt-5.6-luna + previousResponseId + exactly one tool_result
// input arms ToolArgumentRunawayGuard, 45fps / 2.8cpf / 60s timeout) and
// watches the guard: fired = stream.completed rejects with code
// 'tool_argument_runaway'. The abort path logs recordResponseClosed(outcome
// 'aborted') WITH the full raw transcript, plus TERM2_RAW_TRAFFIC=1 gives
// the raw sent sidecar.
//
// Side effects: live Codex API calls only (bounded: N_HISTORY + N_PROBES per
// run; keep both small) and temp-dir traffic logs.
//
// Usage:
//   node --import tsx scripts/experiments/luna-format-repro/luna-chained-probe.mjs [nHistory] [nProbes] [outPath]
//   CODEX_TOKEN=...   bearer token (default: read-only from ~/.codex/auth.json)
//   CODEX_BASE_URL=... endpoint override (default: chatgpt.com codex backend)
//   TERM2_RAW_TRAFFIC=1  write raw sent sidecars next to sanitized artifacts
//
// Exit code: 0 = all clean, 1 = >=1 probe fired (guard trip), 2 = harness error.
// Result JSON: { config, probes: [{ probe, fired, errorCode, ms, responseId,
//   completedResponseId }], fired, n, historyTurns, logDir }.
import { writeFileSync, readFileSync, existsSync, readdirSync, mkdirSync } from 'node:fs';
import { homedir, tmpdir } from 'node:os';
import { join } from 'node:path';

const MODEL = 'gpt-5.6-luna';
const N_HISTORY = Number(process.argv[2] || 6);
const N_PROBES = Number(process.argv[3] || 2);
const OUT_PATH = process.argv[4] || '/tmp/luna-format-repro/chained.json';
if (process.argv[2] === '--help' || process.argv[2] === '-h') {
  console.log(
    'usage: node --import tsx scripts/experiments/luna-format-repro/luna-chained-probe.mjs [nHistory] [nProbes] [outPath]',
  );
  process.exit(0);
}

function loadToken() {
  const raw = JSON.parse(readFileSync(join(homedir(), '.codex', 'auth.json'), 'utf8'));
  const t = raw.tokens ?? raw;
  if (!t?.access_token) throw new Error('no access_token in ~/.codex/auth.json');
  return t.access_token;
}
if (!process.env.CODEX_TOKEN) process.env.CODEX_TOKEN = loadToken();
process.env.TERM2_RAW_TRAFFIC ??= '1';

const { ApplicationRunLoop } = await import('../../../source/services/agent-runtime/application-run-loop.ts');
const { getProvider } = await import('../../../source/providers/index.ts');
const { LoggingService } = await import('../../../source/services/logging/logging-service.ts');
const { SessionContextService } = await import('../../../source/services/session/session-context-service.ts');
const { SettingsService } = await import('../../../source/services/settings/settings-service.ts');
const { getAgentDefinition } = await import('../../../source/agent.ts');
const { buildAgentTools } = await import('../../../source/lib/agent-factory.ts');
const { shouldUseNativePatchTool } = await import('../../../source/lib/tool-selection-policy.ts');
const { createEditorImpl } = await import('../../../source/lib/editor-impl.ts');
const { ToolInterceptorRegistry } = await import('../../../source/lib/tool-interceptor-registry.ts');

const logDir = join(process.env.TMPDIR || tmpdir(), `luna-chained-${Date.now()}`);
mkdirSync(logDir, { recursive: true });
const sessionContextService = new SessionContextService();
const logger = new LoggingService({ logDir, sessionContextService });
const settings = new SettingsService({ loggingService: logger, disableFilePersistence: true });
settings.set('agent.provider', 'codex', { persist: false });
settings.set('agent.model', MODEL, { persist: false });
settings.set('agent.transport', 'websocket', { persist: false });
// Harness-only: never park a chained turn on an approval prompt (a parked
// turn yields no new call_id and breaks the server chain). Writes are still
// impossible: apply_patch is answered synthetically by the interceptor below
// and shell is not in the tool set at all.
settings.set('shell.autoApproveMode', 'always', { persist: false });
const sessionId = `luna-chained-${Date.now()}`;
const trafficContext = { sessionId, sessionStartedAt: new Date().toISOString() };

// Production instructions + native patch tool shape for codex/gpt-5.6-luna,
// but the tool SET is restricted to read_file (real execution, harmless
// in-workspace read) and apply_patch (synthetic answers, no writes). The
// model may call either; both yield server-minted real call_ids, which is
// all the chain needs.
const editor = createEditorImpl({ loggingService: logger, settingsService: settings });
const interceptors = new ToolInterceptorRegistry({ logger });
const { instructions, tools: toolDefinitions } = getAgentDefinition(
  { settingsService: settings, loggingService: logger, executionContext: undefined },
  MODEL,
);
const KEEP_TOOLS = new Set(['read_file', 'apply_patch']);
const keptDefinitions = toolDefinitions.filter((definition) => KEEP_TOOLS.has(definition.name));
if (!keptDefinitions.some((definition) => definition.name === 'read_file')) {
  throw new Error('harness: read_file definition missing; refusing to run without a real read tool');
}
const providerDef = getProvider('codex');
const tools = buildAgentTools({
  toolDefinitions: keptDefinitions,
  resolvedModel: MODEL,
  shouldUseNativePatchTool: shouldUseNativePatchTool({
    providerId: 'codex',
    model: MODEL,
    capabilities: providerDef?.capabilities,
  }),
  deps: {
    settings,
    logger,
    editor,
    providerId: 'codex',
    serviceTierOverrideForNextRequest: null,
    createMentor: async () => '',
    runSubagent: async () => ({ finalText: '' }),
    runSubagentAsync: async () => ({}),
    getSubagentResult: async () => ({}),
    sendSubagentMessage: () => ({}),
    cancelSubagentRun: () => ({}),
    checkToolInterceptors: (name, params, callId) => interceptors.check(name, params, callId),
  },
});
const agent = {
  name: 'luna-chained-probe',
  model: MODEL,
  modelSettings: { reasoning: { effort: 'high', summary: 'auto' } },
  instructions,
  // One startStream = one model request + one tool round, so stream.completed
  // resolves with the new chained responseId. maxTurns: 1 (per-startStream)
  // pairs with this: without it the loop would issue a second request.
  tools: tools.map((definition) => ({ ...definition, terminateAfterExecution: true })),
};

const TARGET = 'source/services/background-task-activity.ts';
// Only apply_patch is synthetic (never writes). read_file falls through to
// REAL execution so its result is genuine context; either way the call_id
// the model was issued is server-real and chains. The fiction ("Updated ...")
// keeps a patch turn natural; a read turn's real output is captured from the
// turn events and fed forward instead (see oneTurn callers).
interceptors.add(async (name) => (name === 'apply_patch' ? `Updated ${TARGET}.` : null));

// Whitespace-semantic update hunks: the production update_file shape.
function tsDiff(i) {
  return [
    '@@ method assessLiveness',
    ' export const assessBackgroundTaskLiveness = ({',
    '   tasks,',
    '   thresholds,',
    `   taskKind${i},`,
    ' }: {',
    '   tasks: BackgroundTask[];',
    '   thresholds: LivenessThresholds;',
    ' }) => {',
    `-  return tasks.filter((t) => t.status === 'running');`,
    `+  return tasks.filter((t) => t.status === 'running' && !t.cancelled${i});`,
    ' };',
    '@@ method describeStatus',
    ` export function describeStatus${i}(t: BackgroundTask): string {`,
    `+  if (t.cancelled${i}) return 'cancelled';`,
    "   return t.status;",
    ' }',
  ].join('\n');
}
const FIRST_ASK =
  `Read ${TARGET} lines 1-40 and reply with the function names you see. Use read_file; do not edit anything.`;
const HISTORY_ASK =
  `Continue: read the next unread 40-line chunk of ${TARGET} with read_file and reply with the function names you see. Do not edit anything.`;
const BIG_ASK =
  `Apply an update_file patch to ${TARGET}: refactor assessBackgroundTaskLiveness and describeStatus plus the five neighbouring helpers (isStale, heartbeatAge, watchThreshold, pruneCancelled, summarizeLiveness) to thread a new LivenessOptions parameter through every signature, keeping all existing context lines space-prefixed and every indentation level exact. Emit the full multi-hunk diff in one apply_patch call.`;

const loop = new ApplicationRunLoop({
  resolveModel: (model) =>
    providerDef.createStreamedModel(model, {
      settingsService: settings,
      loggingService: logger,
      sessionContextService,
    }),
  resolveMaxParallelToolCalls: () => 1,
  logDiagnostic: (message, meta) => logger.info(message, meta),
});

let sentInputChars = 0;
let previousResponseId = null;
let historyTurns = 0;

const isCallItem = (event) =>
  event?.type === 'item' && (event.item?.type === 'function_call' || event.item?.type === 'custom_tool_call');
const isResultItem = (event) =>
  event?.type === 'item' &&
  (event.item?.type === 'function_call_result' || event.item?.type === 'custom_tool_call_output');

async function oneTurn(input) {
  sentInputChars += JSON.stringify(input).length;
  const t0 = Date.now();
  const stream = await sessionContextService.runWithContext(trafficContext, () =>
    loop.startStream(agent, input, {
      providerId: 'codex',
      supportsConversationChaining: true,
      ...(previousResponseId ? { previousResponseId } : {}),
      sessionId,
      maxTurns: 1,
    }),
  );
  // Drain: one model request + one tool round (terminateAfterExecution), so
  // the completed promise carries the responseId for the next chained turn;
  // a guard trip rejects it with code 'tool_argument_runaway'.
  const events = [];
  try {
    for await (const event of stream) events.push(event);
    await stream.completed;
  } catch (error) {
    return { error, events, ms: Date.now() - t0 };
  }
  const call = events.find(isCallItem)?.item;
  const result = events.find(isResultItem)?.item;
  return {
    events,
    ms: Date.now() - t0,
    responseId: stream.lastResponseId ?? null,
    // Server-minted call_id the NEXT chained turn must answer. Absent when
    // the model produced text with no tool call (or parked on approval) —
    // the chain cannot continue, so callers fail fast.
    callId: call?.callId ?? null,
    callName: call?.name ?? null,
    customCall: call?.type === 'custom_tool_call',
    resultOutput: typeof result?.output === 'string' ? result.output : null,
  };
}

function fail(msg) {
  throw new Error(msg);
}

// Turn0: FULL-HISTORY (no previousResponseId) with a real read ask. The
// model issues a real tool call; its call_id anchors the whole chain.
{
  const turn = await oneTurn(FIRST_ASK);
  if (turn.error) fail(`history turn 0 failed: ${turn.error?.message ?? turn.error}`);
  if (!turn.responseId) fail('history turn 0 produced no responseId; chaining unavailable');
  if (!turn.callId) fail(`history turn 0 issued no tool call (approval park or text-only); chain has no anchor`);
  previousResponseId = turn.responseId;
  historyTurns++;
  console.log(`history 0: call=${turn.callName} responseId=yes`);
  var lastCallId = turn.callId;
  var lastCustom = turn.customCall;
  var lastOutput = turn.resultOutput ?? `Updated ${TARGET}.`;
}

// Turns 1..N-1: single tool_result answers to the previous REAL call_id —
// exactly the production chained shape (previous_response_id + one
// function_call_output). The output text is the genuine prior result.
for (let i = 1; i < N_HISTORY; i++) {
  const input = [
    lastCustom
      ? { type: 'custom_tool_call_output', callId: lastCallId, output: lastOutput.slice(0, 1500) }
      : { type: 'function_call_result', callId: lastCallId, output: `${HISTORY_ASK}\n\nPrior result:\n${lastOutput.slice(0, 1200)}` },
  ];
  const turn = await oneTurn(input);
  if (turn.error) fail(`history turn ${i} failed: ${turn.error?.message ?? turn.error}`);
  if (!turn.responseId) fail(`history turn ${i} produced no responseId; chain broken`);
  if (!turn.callId) fail(`history turn ${i} issued no tool call; chain broken`);
  previousResponseId = turn.responseId;
  lastCallId = turn.callId;
  lastCustom = turn.customCall;
  lastOutput = turn.resultOutput ?? `Updated ${TARGET}.`;
  historyTurns++;
  console.log(`history ${i}: call=${turn.callName} responseId=yes`);
}

const probes = [];
let anyFired = false;
for (let k = 0; k < N_PROBES; k++) {
  // Probe: single tool_result delta answering the last REAL call_id, carrying
  // the oversized consolidation ask — the guard's exact shape.
  const input = [
    lastCustom
      ? {
          type: 'custom_tool_call_output',
          callId: lastCallId,
          output: `${lastOutput.slice(0, 1500)}\n\nNow: ${BIG_ASK} (diff context for reference:\n${tsDiff(999)})`,
        }
      : {
          type: 'function_call_result',
          callId: lastCallId,
          output: `${lastOutput.slice(0, 1200)}\n\nNow: ${BIG_ASK} (diff context for reference:\n${tsDiff(999)})`,
        },
  ];
  const t0 = Date.now();
  const turn = await oneTurn(input);
  const fired = turn.error?.code === 'tool_argument_runaway';
  if (fired) anyFired = true;
  probes.push({
    probe: k,
    fired,
    errorCode: turn.error ? (turn.error.code ?? String(turn.error?.message ?? turn.error).slice(0, 120)) : null,
    ms: Date.now() - t0,
    responseId: previousResponseId,
    completedResponseId: turn.responseId ?? null,
    toolCalls: turn.events.filter((e) => e?.type === 'item' && String(e.item?.type ?? '').includes('call')).length,
  });
  console.log(JSON.stringify({ ...probes[k], responseId: previousResponseId ? 'chained' : null }));
  if (!turn.error && turn.responseId) previousResponseId = turn.responseId;
}

const out = {
  config: { model: MODEL, nHistory: N_HISTORY, nProbes: N_PROBES, bigAsk: BIG_ASK.length },
  probes,
  fired: probes.filter((p) => p.fired).length,
  n: probes.length,
  historyTurns,
  sentInputChars,
  logDir,
  trafficDir: join(logDir, 'provider-traffic'),
  trafficFiles: existsSync(join(logDir, 'provider-traffic')) ? readdirSync(join(logDir, 'provider-traffic')).length : 0,
};
mkdirSync(OUT_PATH.split('/').slice(0, -1).join('/') || '.', { recursive: true });
writeFileSync(OUT_PATH, JSON.stringify(out, null, 1));
console.log(`wrote ${OUT_PATH} fired=${anyFired} logDir=${logDir}`);
process.exit(anyFired ? 1 : 0);
