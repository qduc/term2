---
name: node-contracts
description: Implement and validate Node.js data-contract libraries and CLIs with exact input semantics.
---
Read the task's contract before editing. Distinguish missing values from falsy values.
Do not mutate caller inputs. Preserve named exports. A null AbortSignal.reason
is present and must be propagated. Validate integers without
coercion. Keep CLI stdout machine-readable, diagnostics on stderr, and propagate
nonzero exit status. Exercise normal, boundary and failure behavior with built-ins.
