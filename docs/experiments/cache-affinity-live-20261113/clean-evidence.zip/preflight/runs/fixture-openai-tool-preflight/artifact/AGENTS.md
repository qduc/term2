Use the node-contracts skill for these Node.js library and CLI tasks.
Preserve public exports and all existing tests, instructions and skills. Use the
available tools normally; do not replace checks with claims. Use only Node built-ins
and edit source files under src/. No network or package installation is needed.
Run the public tests and any focused checks you need. Do not hardcode fixture values.
