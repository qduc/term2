import fs from 'node:fs';
import { collectPages } from './pages.mjs';
const pages = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
console.log(JSON.stringify(await collectPages(async ({cursor}) => pages.find(p => p.cursor === (cursor ?? null)))));
