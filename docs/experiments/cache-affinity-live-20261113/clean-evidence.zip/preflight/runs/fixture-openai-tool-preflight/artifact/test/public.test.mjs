import { test } from 'node:test'; import assert from 'node:assert/strict'; import { collectPages } from '../src/pages.mjs';
test('collects a terminal page', async () => { assert.deepEqual(await collectPages(async () => ({items:[1], nextCursor:null})), [1]); });
test('keeps an empty-string cursor', async () => { let n=0; assert.deepEqual(await collectPages(async () => ++n===1 ? {items:[1],nextCursor:''}:{items:[2]}),[1,2]); });
