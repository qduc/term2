import {classifyApiError} from './errors.mjs';
export async function withRetry(operation, {maxAttempts=3, sleep=async()=>{}, now=Date.now, signal}={}) { for(let n=0;;n++){try{return await operation();}catch(e){if(n>=maxAttempts||!classifyApiError(e,{nowMs:now()}).retryable)throw e;await sleep(0,signal);}} }
