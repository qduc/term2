import {test} from 'node:test'; import assert from 'node:assert/strict'; import {classifyApiError} from '../src/errors.mjs'; import {withRetry} from '../src/retry.mjs';
test('quota is not a transient rate limit',()=>assert.deepEqual(classifyApiError({status:429,error:{code:'insufficient_quota'}}),{kind:'quota',retryable:false}));
test('one retry succeeds',async()=>{let n=0;assert.equal(await withRetry(async()=>{if(++n===1)throw {status:503};return 7}),7);assert.equal(n,2)});
