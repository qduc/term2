export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  const signal = options.signal;
  const items = [];
  const fetchedCursors = new Set();
  let pageCount = 0;

  const abort = () => {
    if (signal?.aborted) {
      if (signal.reason !== undefined) throw signal.reason;
      throw new DOMException('The operation was aborted', 'AbortError');
    }
  };

  while (true) {
    abort();
    if (cursor !== null && cursor !== undefined) {
      if (typeof cursor !== 'string' && !(typeof cursor === 'number' && Number.isFinite(cursor))) {
        throw new TypeError('cursor must be a string or finite number');
      }
      const key = `${typeof cursor}:${String(cursor)}`;
      if (fetchedCursors.has(key)) throw new Error('Repeated cursor');
      fetchedCursors.add(key);
    }
    if (pageCount >= maxPages) throw new RangeError('Maximum page count exceeded');

    const page = await fetchPage({ cursor, signal });
    pageCount++;
    abort();

    if (page === null || typeof page !== 'object' || Array.isArray(page)) {
      throw new TypeError('Page must be an object');
    }
    if (!Array.isArray(page.items)) throw new TypeError('Page items must be an array');
    const nextCursor = page.nextCursor;
    if (nextCursor !== null && nextCursor !== undefined &&
        typeof nextCursor !== 'string' &&
        !(typeof nextCursor === 'number' && Number.isFinite(nextCursor))) {
      throw new TypeError('nextCursor must be a string or finite number');
    }
    for (const item of page.items) items.push(item);
    if (nextCursor === null || nextCursor === undefined) break;
    cursor = nextCursor;
  }

  return items;
}
