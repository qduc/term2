import fs from 'node:fs';
import { collectPages } from './pages.mjs';

try {
  const pages = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  if (!Array.isArray(pages)) throw new TypeError('pages.json must contain an array');

  const items = await collectPages(async ({ cursor }) =>
    pages.find(page => page.cursor === (cursor === undefined ? null : cursor))
  );
  console.log(JSON.stringify(items));
} catch (error) {
  console.error(error?.message ?? String(error));
  process.exitCode = 1;
}
