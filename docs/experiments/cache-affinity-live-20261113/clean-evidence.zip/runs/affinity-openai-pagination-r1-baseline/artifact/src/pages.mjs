export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  const signal = options.signal;
  let cursor = options.cursor;
  const isCursor = value => typeof value === 'string' ||
    (typeof value === 'number' && Number.isFinite(value));
  if (cursor !== undefined && cursor !== null && !isCursor(cursor)) {
    throw new TypeError('cursor must be a string, finite number, null, or undefined');
  }

  const throwIfAborted = () => {
    if (!signal?.aborted) return;
    if (signal != null && 'reason' in Object(signal)) throw signal.reason;
    const error = new Error('The operation was aborted');
    error.name = 'AbortError';
    throw error;
  };
  const items = [];
  const seen = new Set();
  let pagesFetched = 0;

  while (true) {
    throwIfAborted();
    if (cursor !== undefined && cursor !== null) {
      if (seen.has(cursor)) throw new Error('Repeated pagination cursor');
      seen.add(cursor);
    }
    if (pagesFetched >= maxPages) throw new RangeError('Maximum page count exceeded');

    const page = await fetchPage({ cursor, signal });
    pagesFetched++;
    throwIfAborted();
    if (page === null || typeof page !== 'object' || Array.isArray(page) || !Array.isArray(page.items)) {
      throw new TypeError('Page must be an object with an items array');
    }

    const nextCursor = page.nextCursor;
    if (nextCursor !== undefined && nextCursor !== null && !isCursor(nextCursor)) {
      throw new TypeError('nextCursor must be a string, finite number, null, or undefined');
    }
    for (const item of page.items) items.push(item);
    if (nextCursor === undefined || nextCursor === null) return items;
    cursor = nextCursor;
  }
}
