const QUOTA_CODES = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

function statusValue(value) {
  if (typeof value === 'number' && Number.isInteger(value)) {
    return value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^\d+$/.test(value)) {
    const status = Number(value);
    return status >= 100 && status <= 599 ? status : undefined;
  }
  return undefined;
}

function header(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') return headers.get(name) ?? undefined;
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function retryDelay(error, nowMs) {
  const headers = error?.headers ?? error?.response?.headers;
  const milliseconds = header(headers, 'retry-after-ms');
  if (milliseconds !== undefined && milliseconds !== null && String(milliseconds).trim() !== '') {
    const value = typeof milliseconds === 'number' ? milliseconds : Number(milliseconds);
    if (Number.isFinite(value) && value >= 0) return value;
  }

  const retryAfter = header(headers, 'retry-after');
  if (retryAfter === undefined || retryAfter === null) return undefined;
  const value = String(retryAfter).trim();
  if (/^\d+(?:\.\d+)?$/.test(value)) {
    const delay = Number(value) * 1000;
    return Number.isFinite(delay) ? delay : undefined;
  }
  const isHttpDate = /^(?:[A-Z][a-z]{2}, \d{2} [A-Z][a-z]{2} \d{4} \d{2}:\d{2}:\d{2} GMT|[A-Z][a-z]+, \d{2}-[A-Z][a-z]{2}-\d{2} \d{2}:\d{2}:\d{2} GMT|[A-Z][a-z]{2} [A-Z][a-z]{2} +\d{1,2} \d{2}:\d{2}:\d{2} \d{4})$/.test(value);
  if (!isHttpDate) return undefined;
  const date = Date.parse(value);
  if (!Number.isFinite(date)) return undefined;
  const delay = date - nowMs;
  return Number.isFinite(delay) ? Math.max(0, delay) : undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const nestedError = error?.error;
  const codes = [error?.code, nestedError?.code];
  const structuredStatus = [
    error?.status,
    error?.response?.status,
    nestedError?.status,
    error?.statusCode,
    error?.code,
  ].map(statusValue).find((value) => value !== undefined);
  const prefix = [
    typeof error === 'string' ? error : undefined,
    typeof nestedError === 'string' ? nestedError : nestedError?.message,
    error?.message,
  ]
    .find((text) => typeof text === 'string' && /^(?:\d{3}\s*:|HTTP\s+\d{3}\b)/i.test(text));
  const prefixStatus = prefix === undefined
    ? undefined
    : statusValue(prefix.match(/^(?:HTTP\s+)?(\d{3})/i)?.[1]);
  const status = structuredStatus ?? prefixStatus;

  let result;
  if (status === 402 || codes.some((code) => QUOTA_CODES.has(code))) {
    result = {kind: 'quota', retryable: false};
  } else if (status === 401 || status === 403) {
    result = {kind: 'authentication', retryable: false};
  } else if (status === 429) {
    result = {kind: 'rate_limit', retryable: true};
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    result = {kind: 'transient', retryable: true};
  } else if (status === 400 || status === 404 || status === 413 || status === 422) {
    result = {kind: 'invalid_request', retryable: false};
  } else if (codes.includes('ECONNRESET') || codes.includes('ETIMEDOUT') || codes.includes('EAI_AGAIN')) {
    result = {kind: 'transient', retryable: true};
  } else {
    result = {kind: 'unknown', retryable: false};
  }

  const delay = retryDelay(error, nowMs);
  if (delay !== undefined) {
    result.retryAfterMs = delay;
    if ((result.kind === 'rate_limit' || result.kind === 'transient') && delay > 60000) {
      result.retryable = false;
    }
  }
  return result;
}
