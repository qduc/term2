const QUOTA_CODES = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

function parseStatus(value) {
  let status = value;
  if (typeof status === 'string' && /^\s*\d+\s*$/.test(status)) {
    status = Number(status.trim());
  }
  return Number.isInteger(status) && status >= 100 && status <= 599
    ? status
    : undefined;
}

function statusFromPrefix(value) {
  if (typeof value !== 'string') return undefined;
  const match = value.match(/^\s*(?:HTTP\s+)?(\d{3})(?=\s|:)/i);
  return match ? parseStatus(match[1]) : undefined;
}

function isQuotaCode(value) {
  return typeof value === 'string' && QUOTA_CODES.has(value);
}

function getHeader(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    if (value !== null && value !== undefined) return value;
    return undefined;
  }
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function validNonnegativeNumber(value) {
  if (typeof value === 'number') return Number.isFinite(value) && value >= 0 ? value : undefined;
  if (typeof value === 'string' && /^\s*\d+(?:\.\d+)?\s*$/.test(value)) {
    const number = Number(value.trim());
    return Number.isFinite(number) ? number : undefined;
  }
  return undefined;
}

function retryDelay(error, nowMs) {
  const headers = error?.headers ?? error?.response?.headers;
  const milliseconds = validNonnegativeNumber(getHeader(headers, 'retry-after-ms'));
  if (milliseconds !== undefined) return milliseconds;

  const retryAfter = getHeader(headers, 'retry-after');
  const seconds = validNonnegativeNumber(retryAfter);
  if (seconds !== undefined) return seconds * 1000;
  if (typeof retryAfter === 'string' && retryAfter.trim() !== '') {
    const dateMs = Date.parse(retryAfter);
    if (Number.isFinite(dateMs)) return Math.max(0, dateMs - nowMs);
  }
  return undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const structuredStatuses = [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ];
  let status;
  for (const candidate of structuredStatuses) {
    status = parseStatus(candidate);
    if (status !== undefined) break;
  }
  if (status === undefined) {
    status = statusFromPrefix(error?.message) ?? statusFromPrefix(error?.error);
  }

  const quota = status === 402 || isQuotaCode(error?.code) || isQuotaCode(error?.error?.code);
  let kind = 'unknown';
  let retryable = false;

  if (quota) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if (status === 400 || status === 404 || status === 413 || status === 422) {
    kind = 'invalid_request';
  } else if (status === undefined && ['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN'].includes(error?.code)) {
    kind = 'transient';
    retryable = true;
  }

  const delay = retryDelay(error, nowMs);
  if (delay === undefined) return {kind, retryable};
  if ((kind === 'rate_limit' || kind === 'transient') && delay > 60000) retryable = false;
  return {kind, retryable, retryAfterMs: delay};
}
