import {setTimeout as delay} from 'node:timers/promises';
import {classifyApiError} from './errors.mjs';

function throwIfAborted(signal) {
  if (!signal?.aborted) return;
  if ('reason' in signal) throw signal.reason;
  throw new DOMException('The operation was aborted', 'AbortError');
}

async function defaultSleep(delayMs, signal) {
  try {
    await delay(delayMs, undefined, signal ? {signal} : undefined);
  } catch (error) {
    if (signal?.aborted) throwIfAborted(signal);
    throw error;
  }
}

export async function withRetry(operation, options = {}) {
  const {
    maxAttempts = 3,
    sleep = defaultSleep,
    now = Date.now,
    signal,
  } = options;

  if (typeof operation !== 'function') throw new TypeError('operation must be a function');
  if (!Number.isInteger(maxAttempts) || maxAttempts <= 0) {
    throw new RangeError('maxAttempts must be a positive integer');
  }
  if (typeof sleep !== 'function') throw new TypeError('sleep must be a function');
  if (typeof now !== 'function') throw new TypeError('now must be a function');

  throwIfAborted(signal);
  for (let attempt = 1; ; attempt += 1) {
    try {
      return await operation();
    } catch (error) {
      if (attempt >= maxAttempts) throw error;
      const classification = classifyApiError(error, {nowMs: now()});
      if (!classification.retryable) throw error;
      await sleep(classification.retryAfterMs ?? 0, signal);
      throwIfAborted(signal);
    }
  }
}
