const QUOTA_CODES = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

function statusValue(value) {
  if (typeof value === 'number') {
    return Number.isInteger(value) && value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^\d+$/.test(value.trim())) {
    const status = Number(value.trim());
    return status >= 100 && status <= 599 ? status : undefined;
  }
  return undefined;
}

function prefixedStatus(value) {
  if (typeof value !== 'string') return undefined;
  const match = value.match(/^\s*(?:HTTP\s+)?(\d{3})(?=\s|:|$)/i);
  return match ? statusValue(match[1]) : undefined;
}

function readHeader(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') return headers.get(name);
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find(candidate => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function retryDelay(error, nowMs) {
  const headers = error?.headers ?? error?.response?.headers;
  const milliseconds = readHeader(headers, 'retry-after-ms');
  if (milliseconds !== undefined && milliseconds !== null && milliseconds !== '') {
    const value = typeof milliseconds === 'number'
      ? milliseconds
      : (String(milliseconds).trim() === '' ? NaN : Number(milliseconds));
    if (Number.isFinite(value) && value >= 0) return value;
  }

  const retryAfter = readHeader(headers, 'retry-after');
  if (typeof retryAfter !== 'string' && typeof retryAfter !== 'number') return undefined;
  const text = String(retryAfter).trim();
  if (/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)) {
    const seconds = Number(text);
    const delay = seconds * 1000;
    return Number.isFinite(delay) ? delay : undefined;
  }
  if (!text.includes(',') && !/^[A-Za-z]{3}\s+[A-Za-z]{3}\s+\d{1,2}\s/.test(text)) return undefined;
  const date = Date.parse(text);
  const delay = date - nowMs;
  return Number.isFinite(delay) ? Math.max(0, delay) : undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const nestedError = error?.error;
  const codes = [error?.code, nestedError?.code];
  const isQuota = codes.some(code => typeof code === 'string' && QUOTA_CODES.has(code));

  const status = [
    error?.status,
    error?.response?.status,
    nestedError?.status,
    error?.statusCode,
    error?.code,
  ].map(statusValue).find(value => value !== undefined)
    ?? prefixedStatus(error?.error)
    ?? prefixedStatus(error?.message);

  let kind = 'unknown';
  let retryable = false;
  if (isQuota || status === 402) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if ([400, 404, 413, 422].includes(status)) {
    kind = 'invalid_request';
  } else if (codes.some(code => ['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN'].includes(code))) {
    kind = 'transient';
    retryable = true;
  }

  const delay = retryDelay(error, nowMs);
  if (delay !== undefined && delay > 60000 && (kind === 'rate_limit' || kind === 'transient')) {
    retryable = false;
  }
  return {
    kind,
    retryable,
    ...(delay === undefined ? {} : {retryAfterMs: delay}),
  };
}
