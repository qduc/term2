const quotaCodes = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

function usableStatus(value) {
  let status = value;
  if (typeof status === 'string' && /^\d+$/.test(status.trim())) {
    status = Number(status.trim());
  }
  return Number.isInteger(status) && status >= 100 && status <= 599
    ? status
    : undefined;
}

function prefixedStatus(error) {
  for (const value of [error?.message, error]) {
    if (typeof value !== 'string') continue;
    const match = value.match(/^\s*(?:HTTP\s+)?(\d{3})(?:\s*[:\s-]|$)/i);
    if (match) return usableStatus(match[1]);
  }
  return undefined;
}

function getHeader(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    if (value != null) return value;
  }
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function parseHttpDate(value) {
  const weekdays = '(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)';
  const months = '(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)';
  const validFormat = new RegExp(
    `^(?:${weekdays}, \\d{2} ${months} \\d{4} \\d{2}:\\d{2}:\\d{2} GMT|` +
      `(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), \\d{2}-${months}-\\d{2} \\d{2}:\\d{2}:\\d{2} GMT|` +
      `${weekdays} ${months} [ \\d]\\d \\d{2}:\\d{2}:\\d{2} \\d{4})$`,
  );
  return validFormat.test(value) ? Date.parse(value) : NaN;
}

function retryDelay(error, nowMs) {
  const headers = error?.headers ?? error?.response?.headers;
  const milliseconds = getHeader(headers, 'retry-after-ms');
  let delay;

  if (typeof milliseconds === 'number' && Number.isFinite(milliseconds) && milliseconds >= 0) {
    delay = milliseconds;
  } else if (typeof milliseconds === 'string' && /^\+?(?:\d+(?:\.\d*)?|\.\d+)$/.test(milliseconds.trim())) {
    const parsed = Number(milliseconds.trim());
    if (Number.isFinite(parsed) && parsed >= 0) delay = parsed;
  }

  if (delay === undefined) {
    const value = getHeader(headers, 'retry-after');
    if (typeof value === 'number' && Number.isFinite(value) && value >= 0) {
      delay = value * 1000;
    } else if (typeof value === 'string') {
      const trimmed = value.trim();
      if (/^\+?(?:\d+(?:\.\d*)?|\.\d+)$/.test(trimmed)) {
        const seconds = Number(trimmed);
        if (Number.isFinite(seconds)) delay = seconds * 1000;
      } else {
        const dateMs = parseHttpDate(trimmed);
        if (Number.isFinite(dateMs) && Number.isFinite(nowMs)) delay = Math.max(0, dateMs - nowMs);
      }
    }
  }
  return delay;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const status = [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ].map(usableStatus).find((candidate) => candidate !== undefined) ?? prefixedStatus(error);

  const codes = [error?.code, error?.error?.code];
  const isQuota = status === 402 || codes.some((code) => quotaCodes.has(code));
  let kind = 'unknown';
  let retryable = false;

  if (isQuota) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if (status === 400 || status === 404 || status === 413 || status === 422) {
    kind = 'invalid_request';
  } else if (['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN'].includes(error?.code)) {
    kind = 'transient';
    retryable = true;
  }

  const delay = retryDelay(error, nowMs);
  if (delay !== undefined && delay > 60000 && retryable) retryable = false;

  const result = {kind, retryable};
  if (delay !== undefined) result.retryAfterMs = delay;
  return result;
}
