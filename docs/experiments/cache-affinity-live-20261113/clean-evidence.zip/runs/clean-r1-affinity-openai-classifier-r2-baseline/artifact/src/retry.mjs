import {classifyApiError} from './errors.mjs';

function abortReason(signal) {
  if (signal && 'reason' in signal && signal.reason !== undefined) return signal.reason;
  return new DOMException('The operation was aborted', 'AbortError');
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortReason(signal);
}

function delay(ms, signal) {
  if (signal === undefined) return new Promise((resolve) => setTimeout(resolve, ms));
  throwIfAborted(signal);

  return new Promise((resolve, reject) => {
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortReason(signal));
    };
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    signal.addEventListener('abort', onAbort, {once: true});
    if (signal.aborted) onAbort();
  });
}

export async function withRetry(operation, options = {}) {
  if (typeof operation !== 'function') throw new TypeError('operation must be a function');

  const {
    maxAttempts = 3,
    sleep = delay,
    now = Date.now,
    signal,
  } = options;
  if (!Number.isInteger(maxAttempts) || maxAttempts <= 0) {
    throw new RangeError('maxAttempts must be a positive integer');
  }

  for (let attempt = 1; ; attempt += 1) {
    throwIfAborted(signal);
    let error;
    try {
      return await operation();
    } catch (caught) {
      error = caught;
    }

    if (attempt >= maxAttempts) throw error;
    const classification = classifyApiError(error, {nowMs: now()});
    if (!classification.retryable) throw error;

    await sleep(classification.retryAfterMs ?? 0, signal);
    throwIfAborted(signal);
  }
}
