export async function summarizeEvents(lines) {
  const winners = new Map();
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line !== 'string' || line.trim() === '') continue;

    let event;
    try {
      event = JSON.parse(line);
    } catch {
      invalidLines++;
      continue;
    }

    if (
      event === null || typeof event !== 'object' || Array.isArray(event) ||
      typeof event.id !== 'string' || event.id.trim() === '' ||
      typeof event.account !== 'string' || event.account.trim() === '' ||
      !Number.isSafeInteger(event.amountCents) ||
      !Number.isInteger(event.revision) || event.revision < 0
    ) {
      invalidLines++;
      continue;
    }

    const previous = winners.get(event.id);
    if (previous !== undefined) duplicateEvents++;
    if (previous === undefined || event.revision >= previous.revision) {
      winners.set(event.id, event);
    }
  }

  const aggregate = new Map();
  for (const event of winners.values()) {
    const account = aggregate.get(event.account) ?? {
      account: event.account,
      netCents: 0,
      count: 0,
    };
    const netCents = account.netCents + event.amountCents;
    if (!Number.isSafeInteger(netCents)) {
      throw new RangeError('Aggregate amountCents exceeds the safe integer range');
    }
    account.netCents = netCents;
    account.count++;
    aggregate.set(event.account, account);
  }

  const accounts = [...aggregate.values()].sort((left, right) =>
    left.account < right.account ? -1 : left.account > right.account ? 1 : 0
  );
  return { accounts, invalidLines, duplicateEvents };
}
