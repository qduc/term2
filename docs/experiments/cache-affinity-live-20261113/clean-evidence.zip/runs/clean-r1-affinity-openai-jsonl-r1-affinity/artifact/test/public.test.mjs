import {test} from 'node:test';import assert from 'node:assert/strict';import {summarizeEvents} from '../src/summary.mjs';
test('latest correction wins across accounts',async()=>assert.deepEqual(await summarizeEvents(['{"id":"a","account":"X","amountCents":5,"revision":0}','{"id":"a","account":"Y","amountCents":8,"revision":1}']),{accounts:[{account:'Y',netCents:8,count:1}],invalidLines:0,duplicateEvents:1}));
test('blank and malformed input',async()=>assert.deepEqual(await summarizeEvents(['','bad']),{accounts:[],invalidLines:1,duplicateEvents:0}));
