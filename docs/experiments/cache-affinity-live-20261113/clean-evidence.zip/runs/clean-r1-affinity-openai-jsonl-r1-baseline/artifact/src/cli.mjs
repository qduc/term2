import fs from 'node:fs';
import readline from 'node:readline';
import { summarizeEvents } from './summary.mjs';

async function* readLines(files) {
  for (const file of files) {
    const input = file === '-' ? process.stdin : fs.createReadStream(file);
    const reader = readline.createInterface({ input, crlfDelay: Infinity });
    for await (const line of reader) {
      yield line;
    }
  }
}

try {
  const files = process.argv.slice(2);
  if (files.length === 0) {
    throw new Error('At least one input file is required');
  }
  if (files.some((file) => file.length === 0)) {
    throw new Error('Input file names must not be empty');
  }
  if (files.filter((file) => file === '-').length > 1) {
    throw new Error('Standard input may be specified at most once');
  }

  const report = await summarizeEvents(readLines(files));
  process.stdout.write(`${JSON.stringify(report)}\n`);
  process.exitCode = report.invalidLines > 0 ? 2 : 0;
} catch (error) {
  process.stderr.write(`Error: ${error.message}\n`);
  process.exitCode = 1;
}
