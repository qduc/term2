export async function summarizeEvents(lines) {
  const winners = new Map();
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line !== 'string') {
      invalidLines++;
      continue;
    }
    if (line.trim() === '') continue;

    let event;
    try {
      event = JSON.parse(line);
    } catch {
      invalidLines++;
      continue;
    }

    if (
      event === null ||
      typeof event !== 'object' ||
      Array.isArray(event) ||
      typeof event.id !== 'string' || event.id.trim() === '' ||
      typeof event.account !== 'string' || event.account.trim() === '' ||
      !Number.isSafeInteger(event.amountCents) ||
      !Number.isInteger(event.revision) || event.revision < 0
    ) {
      invalidLines++;
      continue;
    }

    if (winners.has(event.id)) {
      duplicateEvents++;
      if (event.revision >= winners.get(event.id).revision) {
        winners.set(event.id, event);
      }
    } else {
      winners.set(event.id, event);
    }
  }

  const accountTotals = new Map();
  for (const event of winners.values()) {
    const total = accountTotals.get(event.account) ?? {
      account: event.account,
      netCents: 0,
      count: 0,
    };
    const netCents = total.netCents + event.amountCents;
    if (!Number.isSafeInteger(netCents)) {
      throw new RangeError('Account aggregate exceeds the safe integer range');
    }
    total.netCents = netCents;
    total.count++;
    accountTotals.set(event.account, total);
  }

  const accounts = [...accountTotals.values()].sort((left, right) =>
    left.account < right.account ? -1 : left.account > right.account ? 1 : 0,
  );

  return { accounts, invalidLines, duplicateEvents };
}
