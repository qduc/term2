import fs from 'node:fs';
import readline from 'node:readline';
import {summarizeEvents} from './summary.mjs';

async function* readInputs(paths) {
  for (const path of paths) {
    const input = path === '-' ? process.stdin : fs.createReadStream(path);
    const lines = readline.createInterface({input, crlfDelay: Infinity});
    for await (const line of lines) yield line;
  }
}

async function main() {
  const paths = process.argv.slice(2);
  if (paths.length === 0 || paths.filter(path => path === '-').length > 1) {
    throw new Error('Provide one or more input files; stdin (-) may be specified at most once');
  }

  const report = await summarizeEvents(readInputs(paths));
  process.stdout.write(`${JSON.stringify(report)}\n`);
  if (report.invalidLines > 0) process.exitCode = 2;
}

main().catch(error => {
  process.stderr.write(`${error?.message ?? String(error)}\n`);
  process.exitCode = 1;
});
