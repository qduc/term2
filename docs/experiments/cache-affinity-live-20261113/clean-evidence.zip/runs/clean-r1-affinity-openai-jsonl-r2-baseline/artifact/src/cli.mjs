import { createReadStream } from 'node:fs';
import { createInterface } from 'node:readline';
import { summarizeEvents } from './summary.mjs';

async function* readLines(source) {
  const reader = createInterface({ input: source, crlfDelay: Infinity });
  for await (const line of reader) yield line;
}

async function main() {
  const files = process.argv.slice(2);
  if (files.length === 0) throw new TypeError('At least one input file is required');
  if (files.filter((file) => file === '-').length > 1) {
    throw new TypeError("Standard input ('-') may be specified only once");
  }

  async function* inputLines() {
    for (const file of files) {
      const source = file === '-' ? process.stdin : createReadStream(file);
      yield* readLines(source);
    }
  }

  const report = await summarizeEvents(inputLines());
  process.stdout.write(`${JSON.stringify(report)}\n`);
  if (report.invalidLines > 0) process.exitCode = 2;
}

main().catch((error) => {
  process.stderr.write(`${error?.message ?? String(error)}\n`);
  process.exitCode = 1;
});
