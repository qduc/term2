export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }
  if (options === null || typeof options !== 'object' || Array.isArray(options)) {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  if (cursor === null) cursor = undefined;
  const items = [];
  const seenCursors = new Set();
  let pagesFetched = 0;
  let firstPage = true;

  const validateCursor = (value) => {
    if (value !== null && value !== undefined &&
        typeof value !== 'string' &&
        !(typeof value === 'number' && Number.isFinite(value))) {
      throw new TypeError('cursor must be a string, finite number, null, or undefined');
    }
  };
  const throwIfAborted = () => {
    if (options.signal?.aborted) {
      const reason = options.signal.reason;
      if (reason !== undefined) throw reason;
      const error = new Error('The operation was aborted');
      error.name = 'AbortError';
      throw error;
    }
  };

  while (firstPage || (cursor !== null && cursor !== undefined)) {
    firstPage = false;
    validateCursor(cursor);
    if (seenCursors.has(cursor)) {
      throw new Error('Repeated cursor');
    }
    if (pagesFetched >= maxPages) {
      throw new RangeError('maxPages exceeded');
    }

    throwIfAborted();
    seenCursors.add(cursor);
    const page = await fetchPage({ cursor, signal: options.signal });
    pagesFetched += 1;
    throwIfAborted();

    if (page === null || typeof page !== 'object' || Array.isArray(page)) {
      throw new TypeError('fetchPage must return a page object');
    }
    if (!Array.isArray(page.items)) {
      throw new TypeError('page.items must be an array');
    }
    validateCursor(page.nextCursor);

    for (const item of page.items) items.push(item);
    cursor = page.nextCursor;
  }
  return items;
}
