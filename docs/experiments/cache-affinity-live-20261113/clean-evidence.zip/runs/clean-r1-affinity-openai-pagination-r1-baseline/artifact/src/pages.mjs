function validateCursor(cursor) {
  if (cursor !== null && cursor !== undefined &&
      typeof cursor !== 'string' &&
      !(typeof cursor === 'number' && Number.isFinite(cursor))) {
    throw new TypeError('cursor must be a string or finite number');
  }
}

function throwIfAborted(signal) {
  if (signal?.aborted) {
    if (signal.reason !== undefined) throw signal.reason;
    const error = new Error('The operation was aborted');
    error.name = 'AbortError';
    throw error;
  }
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }
  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  validateCursor(cursor);
  const signal = options.signal;
  const items = [];
  const fetchedCursors = new Set();
  let pageCount = 0;

  while (true) {
    throwIfAborted(signal);
    if (pageCount >= maxPages) {
      throw new RangeError(`pagination exceeded maxPages (${maxPages})`);
    }
    if (fetchedCursors.has(cursor)) {
      throw new Error('pagination repeated a cursor');
    }
    fetchedCursors.add(cursor);

    const page = await fetchPage({ cursor, signal });
    pageCount += 1;
    throwIfAborted(signal);

    if (page === null || typeof page !== 'object' || Array.isArray(page)) {
      throw new TypeError('fetchPage must return a page object');
    }
    if (!Array.isArray(page.items)) {
      throw new TypeError('page.items must be an array');
    }
    validateCursor(page.nextCursor);
    for (const item of page.items) items.push(item);

    if (page.nextCursor === null || page.nextCursor === undefined) return items;
    cursor = page.nextCursor;
  }
}
