function validateCursor(cursor) {
  if (cursor !== null && cursor !== undefined &&
      typeof cursor !== 'string' &&
      !(typeof cursor === 'number' && Number.isFinite(cursor))) {
    throw new TypeError('cursor must be a string, finite number, null, or undefined');
  }
}

function throwIfAborted(signal) {
  if (!signal?.aborted) return;
  if (signal && (typeof signal === 'object' || typeof signal === 'function') &&
      'reason' in signal) {
    throw signal.reason;
  }
  const error = new Error('The operation was aborted');
  error.name = 'AbortError';
  throw error;
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object' || Array.isArray(options)) {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  validateCursor(cursor);
  const signal = options.signal;
  const seen = new Set();
  const items = [];

  for (let pageCount = 0; ; pageCount++) {
    throwIfAborted(signal);
    if (pageCount >= maxPages) throw new RangeError('maxPages exceeded');
    if (seen.has(cursor)) throw new Error('repeated cursor');
    seen.add(cursor);

    const page = await fetchPage({ cursor, signal });
    throwIfAborted(signal);
    if (page === null || typeof page !== 'object' || Array.isArray(page) ||
        !Array.isArray(page.items)) {
      throw new TypeError('fetchPage must return a page with an items array');
    }
    validateCursor(page.nextCursor);
    for (const item of page.items) items.push(item);

    if (page.nextCursor === null || page.nextCursor === undefined) return items;
    cursor = page.nextCursor;
  }
}
