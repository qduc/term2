import fs from 'node:fs';
import { collectPages } from './pages.mjs';

try {
  const pages = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  if (!Array.isArray(pages)) throw new TypeError('pages.json must contain an array');
  const items = await collectPages(async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    return pages.find(page => page !== null && typeof page === 'object' && page.cursor === key);
  });
  process.stdout.write(`${JSON.stringify(items)}\n`);
} catch (error) {
  process.stderr.write(`${error?.message ?? String(error)}\n`);
  process.exitCode = 1;
}
