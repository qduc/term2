export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object' || Array.isArray(options)) {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  const isCursor = value => value === null || value === undefined ||
    typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));
  const cursorKey = value => `${typeof value}:${String(value)}`;
  let cursor = options.cursor;
  if (!isCursor(cursor)) throw new TypeError('cursor must be a string or finite number');

  const seen = new Set();
  if (cursor !== null && cursor !== undefined) seen.add(cursorKey(cursor));
  const items = [];
  let pageCount = 0;

  const throwIfAborted = signal => {
    if (signal?.aborted) {
      if (signal != null && 'reason' in Object(signal)) throw signal.reason;
      const error = new Error('The operation was aborted');
      error.name = 'AbortError';
      throw error;
    }
  };

  while (true) {
    throwIfAborted(options.signal);
    if (pageCount >= maxPages) throw new RangeError('maxPages exceeded');
    const page = await fetchPage({ cursor, signal: options.signal });
    pageCount++;
    throwIfAborted(options.signal);

    if (page === null || typeof page !== 'object' || Array.isArray(page) || !Array.isArray(page.items)) {
      throw new TypeError('fetchPage must return a page with an items array');
    }
    const nextCursor = page.nextCursor;
    if (!isCursor(nextCursor)) throw new TypeError('nextCursor must be a string, finite number, or terminal');
    for (const item of page.items) items.push(item);

    if (nextCursor === null || nextCursor === undefined) break;
    const key = cursorKey(nextCursor);
    if (seen.has(key)) throw new Error('Repeated cursor');
    seen.add(key);
    cursor = nextCursor;
  }
  return items;
}
