export async function collectPages(fetchPage, options = {}) {
  let cursor = options.cursor; const items = [];
  do { const page = await fetchPage({ cursor, signal: options.signal }); items.push(...page.items); cursor = page.nextCursor; } while (cursor);
  return items;
}
