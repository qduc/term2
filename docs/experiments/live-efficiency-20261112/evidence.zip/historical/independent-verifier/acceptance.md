Independent review: accept the frozen live-comparison harness for the approved campaign ledger, subject to its existing $10 total cap and stop on new unresolved usage. The verifier made no live inference calls and did not alter production or harness source. Reviewed script fingerprints are in reviewed-hashes.json.

The first proposals were rejected for unbudgeted price modifiers, duplicate-coordinator ledger races, in-process unbounded grading, and missing default-page-limit coverage. Free probes reproduced each issue. The author corrected them before this acceptance. Separately, the author reported an earlier preflight preload bypass; that incident is not represented as metered by the new gateway. The live campaign ledger durably retains a conservative $5.286 external exposure reservation. This acceptance requires using that same ledger and retaining that exposure.

Budget evidence:
- Eight concurrent unknown-usage OpenAI fixture requests under a $1.20 cap admitted exactly two, retaining $1.164 exposure; reopening the ledger refused another request with HTTP402.
- A duplicate coordinator initially admitted four requests with $2.328 exposure under that $1.20 cap and lost two ledger entries. After the lock fix, duplicate initialization fails before any send.
- Priority, fast-mode and regional price modifiers initially passed through; after the fix all three probe cases return HTTP400. Reviewed hosted-tool exclusions now include Anthropic code_execution and web_fetch.
- With $5.286 seeded external exposure, nine concurrent fixture requests admit eight and block the ninth, retaining total exposure $9.942. The fixture reads the saved reservation before every upstream send.
- A downstream close does not release the writer lock while its upstream handler remains pending. The lock is released after settlement. Retry-After, request-ID and Anthropic thread headers survive the gateway.
- Independent short-context and tier/cache-write arithmetic checks pass. The native model documentation corroborates whole-request Luna >272K input tiers and Haiku >100K tiers. The reservations cover 1.1M input tokens at the highest allowed write rates plus 32K output, including chained context absent from the current POST. Price modifiers and hosted tools are excluded.

Routing and rubric evidence:
- Independently inspected fixture-v3: all four provider/runner arms have the intended native model ID, a 32K output ceiling, exactly one captured metered request, and successful fixture output. Luna efforts are medium. Pi Haiku carries medium in messages[1].output_config; its top-level low matches the native SDK's stable-prefix mechanism.
- Independent reference implementations pass all 14 pagination, 26 classifier and 13 JSONL checks. Mutants changing pagination default100 to101, dropping quota-code handling, and using locale rather than code-unit sorting each fail a relevant check after the rubric changes.
- Executed all three references through the actual bwrap grader isolation: they pass. An infinite-loop candidate terminates under the finite timeout. Loopback network access is blocked and synthetic secret/API-key variables are absent in the isolated child.

Reproduction sources: probe.mjs, duplicate-coordinator.mjs, final-budget-controls.mjs, references.mjs, mutations.mjs and isolation.mjs. Results for reference and mutation controls are retained as JSON alongside these files. Isolation was run outside the nested agent sandbox so bwrap could create its intended namespaces; the grader's own network/PID isolation remained enabled.

Limits: these controls establish scoped budget, transport and rubric behavior, not live provider acceptance, an invoice, exhaustive contract coverage, or completed-task equivalence to Pi. No live quality or cost conclusion follows before running the frozen paired tasks. Keep failed, cancelled and partial runs and their reservations in total-cost reporting; classify the earlier uncaptured preflight separately from metered comparison requests. The cap requires the existing approved campaign ledger, not a fresh ledger/root that discards earlier exposure.

Primary pricing sources checked during review:
- https://developers.openai.com/api/docs/models/gpt-6-luna
- https://developers.openai.com/api/docs/pricing
- https://platform.claude.com/docs/en/models/haiku-5-5/overview
- https://platform.claude.com/docs/en/about-claude/pricing
