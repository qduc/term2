import assert from'node:assert/strict';import path from'node:path';import{pathToFileURL}from'node:url';
const[task,workspace]=process.argv.slice(2),checks=[];async function check(label,fn){try{await fn();checks.push({label,pass:true});}catch(e){checks.push({label,pass:false,error:e.message});}}
const load=async file=>import(pathToFileURL(path.join(workspace,'src',file)));
if(task==='classifier'){
 const{classifyApiError:c}=await load('errors.mjs'),{withRetry}=await load('retry.mjs');
 await check('top-level-quota-code-over-auth',()=>assert.deepEqual(c({status:401,code:'billing_not_active'}),{kind:'quota',retryable:false}));
 await check('network-fallback-after-unrecognized-status',()=>assert.deepEqual(c({status:418,code:'ECONNRESET'}),{kind:'transient',retryable:true}));
 await check('zero-ms-hint-precedence',()=>assert.equal(c({status:429,headers:{'retry-after-ms':'0','retry-after':'9'}}).retryAfterMs,0));
 await check('invalid-ms-hint-falls-back',()=>assert.equal(c({status:429,headers:{'retry-after-ms':'-1','retry-after':'1.5'}}).retryAfterMs,1500));
 await check('retry-delay-60000-inclusive',()=>assert.deepEqual(c({status:429,headers:{'retry-after':'60'}}),{kind:'rate_limit',retryable:true,retryAfterMs:60000}));
 await check('past-http-date-clamped',()=>assert.equal(c({status:503,headers:{'retry-after':'Thu, 01 Jan 2026 00:00:00 GMT'}},{nowMs:Date.parse('2026-01-01T00:00:01Z')}).retryAfterMs,0));
 await check('frozen-error-not-mutated',()=>{const e=Object.freeze({status:503,headers:Object.freeze({'retry-after':'1'})});assert.deepEqual(c(e),{kind:'transient',retryable:true,retryAfterMs:1000});});
 await check('default-attempt-limit-exact',async()=>{const e={status:503};let n=0;await assert.rejects(()=>withRetry(async()=>{n++;throw e;},{sleep:async()=>{}}),x=>x===e);assert.equal(n,3);});
 await check('null-attempt-limit-invalid-before-operation',async()=>{let n=0;await assert.rejects(()=>withRetry(async()=>{n++;return 1;},{maxAttempts:null}));assert.equal(n,0);});
 await check('clock-controls-http-date-delay',async()=>{const delays=[];let n=0;const result=await withRetry(async()=>{if(++n===1)throw{status:503,headers:{'retry-after':'Thu, 01 Jan 2026 00:00:02 GMT'}};return'done';},{now:()=>Date.parse('2026-01-01T00:00:00Z'),sleep:async ms=>delays.push(ms)});assert.equal(result,'done');assert.deepEqual(delays,[2000]);});
 await check('all-falsy-abort-reasons',async()=>{for(const reason of[0,'',false,null]){let n=0;await assert.rejects(()=>withRetry(async()=>{n++;},{signal:{aborted:true,reason}}),x=>Object.is(x,reason));assert.equal(n,0);}});
}else if(task==='jsonl'){
 const{summarizeEvents:s}=await load('summary.mjs');const line=(id,account,amountCents,revision=0)=>JSON.stringify({id,account,amountCents,revision});
 await check('revision-required',async()=>assert.deepEqual(await s([JSON.stringify({id:'a',account:'A',amountCents:1})]),{accounts:[],invalidLines:1,duplicateEvents:0}));
 await check('whitespace-id-invalid',async()=>assert.deepEqual(await s([line('  ','A',1)]),{accounts:[],invalidLines:1,duplicateEvents:0}));
 await check('unsafe-amount-invalid',async()=>assert.deepEqual(await s([line('a','A',Number.MAX_SAFE_INTEGER+1)]),{accounts:[],invalidLines:1,duplicateEvents:0}));
 await check('nonnegative-integer-revision-not-safe-integer',async()=>assert.deepEqual(await s([line('a','A',1,1e20)]),{accounts:[{account:'A',netCents:1,count:1}],invalidLines:0,duplicateEvents:0}));
 await check('negative-overflow-range-error',async()=>assert.rejects(()=>s([line('a','A',-Number.MAX_SAFE_INTEGER),line('b','A',-1)]),RangeError));
 await check('only-winners-can-overflow',async()=>assert.deepEqual(await s([line('a','A',Number.MAX_SAFE_INTEGER),line('b','A',1),line('a','A',0,1)]),{accounts:[{account:'A',netCents:1,count:2}],invalidLines:0,duplicateEvents:1}));
 await check('invalid-repeat-does-not-count-as-duplicate',async()=>assert.deepEqual(await s([line('a','A',1),line('a','A',1,-1)]),{accounts:[{account:'A',netCents:1,count:1}],invalidLines:1,duplicateEvents:0}));
 await check('iterator-error-identity',async()=>{const e={original:true};async function* rows(){yield line('a','A',1);throw e;}await assert.rejects(()=>s(rows()),x=>x===e);});
}
console.log(JSON.stringify({task,pass:checks.every(x=>x.pass),passed:checks.filter(x=>x.pass).length,total:checks.length,checks}));
