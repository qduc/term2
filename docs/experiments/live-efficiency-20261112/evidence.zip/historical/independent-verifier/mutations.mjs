import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import{gradeWorkload}from '../../docs/experiments/live-efficiency-20261112/workloads.mjs';
const {root}=JSON.parse(fs.readFileSync(new URL('./reference-results.json',import.meta.url)));
const cases=[
 ['pagination','pages.mjs','const max=options.maxPages===undefined?100:options.maxPages;','const max=options.maxPages===undefined?101:options.maxPages;','missing-default-page-limit'],
 ['classifier','errors.mjs',"const quotas=['insufficient_quota','billing_hard_limit_reached','billing_not_active'];","const quotas=[];",'dropped-quota-codes'],
 ['jsonl','summary.mjs',"a.account<b.account?-1:a.account>b.account?1:0","a.account.localeCompare(b.account)",'locale-sort-instead-of-code-unit'],
];const result=[];
for(const[name,file,before,after,mutation]of cases){const target=path.join(root,name,'src',file),original=fs.readFileSync(target,'utf8');assert.ok(original.includes(before));try{fs.writeFileSync(target,original.replace(before,after));const grade=await gradeWorkload(name,path.join(root,name));result.push({name,mutation,pass:grade.pass,failed:grade.checks.filter(c=>!c.pass)});}finally{fs.writeFileSync(target,original);}}
fs.writeFileSync(new URL('./mutation-results.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
