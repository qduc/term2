import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { prepareWorkload, gradeWorkload } from '../../docs/experiments/live-efficiency-20261112/workloads.mjs';
const root=fs.mkdtempSync(path.join(os.tmpdir(),'term2-oracle-verifier-'));
const files={
pagination:{
'pages.mjs':`export async function collectPages(fetchPage,options={}) {
 if(typeof fetchPage!=='function')throw new TypeError('function required');
 const max=options.maxPages===undefined?100:options.maxPages;
 if(!Number.isInteger(max)||max<=0)throw new TypeError('maxPages');
 const validate=c=>{if(c!=null && typeof c!=='string' && !(typeof c==='number'&&Number.isFinite(c)))throw new TypeError('cursor')};
 let cursor=options.cursor;validate(cursor);const seen=new Set(cursor==null?[]:[cursor]),items=[];
 const abort=()=>{if(options.signal?.aborted)throw options.signal.reason!==undefined?options.signal.reason:new DOMException('Aborted','AbortError')};
 for(let n=0;;n++) {abort();if(n>=max)throw new RangeError('maxPages');const p=await fetchPage({cursor,signal:options.signal});abort();
 if(!p||typeof p!=='object'||Array.isArray(p)||!Array.isArray(p.items))throw new TypeError('page');validate(p.nextCursor);items.push(...p.items);
 if(p.nextCursor==null)return items;if(seen.has(p.nextCursor))throw new Error('cursor repeated');seen.add(p.nextCursor);cursor=p.nextCursor;
 }
}`,
'cli.mjs':`import fs from 'node:fs';import {collectPages}from './pages.mjs';try{const pages=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));const r=await collectPages(async({cursor})=>pages.find(p=>p.cursor===(cursor??null)));console.log(JSON.stringify(r));}catch(e){console.error(e.message);process.exitCode=1;}`
},
classifier:{
'errors.mjs':`export function classifyApiError(e,{nowMs=Date.now()}={}) {
 const valid=v=>{if(!['string','number'].includes(typeof v)||v==='')return;const n=Number(v);if(Number.isInteger(n)&&n>=100&&n<=599)return n};
 let status;for(const v of[e?.status,e?.response?.status,e?.error?.status,e?.statusCode,e?.code]){status=valid(v);if(status!==undefined)break;}
 if(status===undefined){const m=(typeof e==='string'?e:e?.message??'').match(/^(?:HTTP\\s+)?(\\d{3})(?=[:\\s]|$)/i);if(m)status=valid(m[1]);}
 const quotas=['insufficient_quota','billing_hard_limit_reached','billing_not_active'];
 let kind='unknown',retryable=false;
 if(status===402||quotas.includes(e?.code)||quotas.includes(e?.error?.code))kind='quota';
 else if([401,403].includes(status))kind='authentication';else if(status===429){kind='rate_limit';retryable=true;}
 else if([408,409].includes(status)||status>=500){kind='transient';retryable=true;}
 else if([400,404,413,422].includes(status))kind='invalid_request';
 else if(['ECONNRESET','ETIMEDOUT','EAI_AGAIN'].includes(e?.code)){kind='transient';retryable=true;}
 const headers=e?.headers??e?.response?.headers;
 const get=name=>headers?.get?headers.get(name):Object.entries(headers??{}).find(([k])=>k.toLowerCase()===name)?.[1];
 const ms=get('retry-after-ms'),seconds=get('retry-after');let delay;
 const numeric=v=>['string','number'].includes(typeof v)&&String(v).trim()!==''&&Number.isFinite(Number(v))&&Number(v)>=0;
 if(numeric(ms))delay=Number(ms);else if(seconds!==undefined&&seconds!==null){const s=String(seconds).trim();if(/^(?:\\d+\\.?\\d*|\\.\\d+)$/.test(s)&&numeric(s))delay=Number(s)*1000;else if(/^[A-Za-z]{3},/.test(s)&&Number.isFinite(Date.parse(s)))delay=Math.max(0,Date.parse(s)-nowMs);}
 if(!Number.isFinite(delay))delay=undefined;if(delay>60000&&['rate_limit','transient'].includes(kind))retryable=false;
 return {kind,retryable,...(delay!==undefined?{retryAfterMs:delay}:{})};
}`,
'retry.mjs':`import{classifyApiError}from './errors.mjs';
export async function withRetry(operation,{maxAttempts=3,sleep=delay,now=Date.now,signal}={}) {
 if(typeof operation!=='function'||!Number.isInteger(maxAttempts)||maxAttempts<=0)throw new TypeError('options');
 const abort=()=>{if(signal?.aborted)throw signal.reason!==undefined?signal.reason:new DOMException('Aborted','AbortError')};
 for(let n=1;;n++){abort();try{return await operation();}catch(e){const c=classifyApiError(e,{nowMs:now()});if(n>=maxAttempts||!c.retryable)throw e;await sleep(c.retryAfterMs??0,signal);abort();}}
}
function delay(ms,signal){return new Promise((resolve,reject)=>{if(signal?.aborted){reject(signal.reason);return;}const cancel=()=>{clearTimeout(timer);reject(signal.reason??new DOMException('Aborted','AbortError'))};const timer=setTimeout(()=>{signal?.removeEventListener('abort',cancel);resolve();},ms);signal?.addEventListener('abort',cancel,{once:true});});}`
},
jsonl:{
'summary.mjs':`export async function summarizeEvents(lines){const winners=new Map();let invalidLines=0,duplicateEvents=0;for await(const line of lines){if(!line.trim())continue;let e;try{e=JSON.parse(line);}catch{invalidLines++;continue;}if(!e||Array.isArray(e)||typeof e!=='object'||typeof e.id!=='string'||!e.id.trim()||typeof e.account!=='string'||!e.account.trim()||!Number.isSafeInteger(e.amountCents)||!Number.isInteger(e.revision)||e.revision<0){invalidLines++;continue;}const prev=winners.get(e.id);if(prev)duplicateEvents++;if(!prev||e.revision>=prev.revision)winners.set(e.id,e);}
 const map=new Map();for(const e of winners.values()){const a=map.get(e.account)??{account:e.account,netCents:0,count:0};a.netCents+=e.amountCents;if(!Number.isSafeInteger(a.netCents))throw new RangeError('overflow');a.count++;map.set(e.account,a);}return {accounts:[...map.values()].sort((a,b)=>a.account<b.account?-1:a.account>b.account?1:0),invalidLines,duplicateEvents};}`,
'cli.mjs':`import fs from 'node:fs';import readline from 'node:readline';import{summarizeEvents}from './summary.mjs';async function* lines(args){for(const file of args){const input=file==='-'?process.stdin:fs.createReadStream(file,{encoding:'utf8'});const rl=readline.createInterface({input,crlfDelay:Infinity});try{for await(const line of rl)yield line;}finally{rl.close();if(file!=='-')input.destroy();}}}try{const args=process.argv.slice(2);if(!args.length||args.filter(x=>x==='-').length>1)throw new Error('arguments');const report=await summarizeEvents(lines(args));console.log(JSON.stringify(report));process.exitCode=report.invalidLines?2:0;}catch(e){console.error(e.message);process.exitCode=1;}`
}};
const result=[];
for(const name of Object.keys(files)){const dir=path.join(root,name);prepareWorkload(name,dir);for(const[file,code]of Object.entries(files[name]))fs.writeFileSync(path.join(dir,'src',file),code);const grade=await gradeWorkload(name,dir);result.push({name,...grade});}
fs.writeFileSync(new URL('./reference-results.json',import.meta.url),JSON.stringify({root,result},null,2)+'\n');
console.log(JSON.stringify({root,grades:result.map(({name,pass,passed,total,checks})=>({name,pass,passed,total,failures:checks.filter(x=>!x.pass)}))},null,2));
assert.ok(result.every(r=>r.pass));
