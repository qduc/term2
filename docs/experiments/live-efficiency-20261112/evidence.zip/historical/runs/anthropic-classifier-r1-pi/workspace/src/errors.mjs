const QUOTA_CODES = new Set(['insufficient_quota', 'billing_hard_limit_reached', 'billing_not_active']);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);
const MAX_RETRY_AFTER_MS = 60000;

const isObject = (v) => (typeof v === 'object' && v !== null) || typeof v === 'function';
const field = (v, key) => (isObject(v) ? v[key] : undefined);

// Accepts integer statuses or 3-digit numeric strings in 100..599.
function parseStatus(v) {
  if (typeof v === 'number') return Number.isInteger(v) && v >= 100 && v <= 599 ? v : undefined;
  if (typeof v === 'string' && /^\d{3}$/.test(v)) {
    const n = Number(v);
    return n >= 100 && n <= 599 ? n : undefined;
  }
  return undefined;
}

// Strings such as '429: ...' or 'HTTP 402 ...'.
function statusFromMessage(error) {
  const candidates = [error, field(error, 'message'), field(error, 'error')];
  for (const c of candidates) {
    if (typeof c !== 'string') continue;
    const m = /^\s*(?:HTTP\s+)?(\d{3})(?=$|[\s:])/i.exec(c);
    if (m) {
      const s = parseStatus(m[1]);
      if (s !== undefined) return s;
    }
  }
  return undefined;
}

function structuredStatus(error) {
  const nested = field(error, 'error');
  const candidates = [
    field(error, 'status'),
    field(field(error, 'response'), 'status'),
    field(nested, 'status'),
    field(error, 'statusCode'),
    field(error, 'code'),
  ];
  for (const c of candidates) {
    const s = parseStatus(c);
    if (s !== undefined) return s;
  }
  return undefined;
}

function resolveStatus(error) {
  return structuredStatus(error) ?? statusFromMessage(error);
}

// Returns the header container: top-level headers, else response.headers.
function headerContainer(error) {
  if (isObject(field(error, 'headers'))) return error.headers;
  const h = field(field(error, 'response'), 'headers');
  return isObject(h) ? h : undefined;
}

function readHeader(container, name) {
  if (!container) return undefined;
  if (container instanceof Map) {
    for (const [k, v] of container) {
      if (typeof k === 'string' && k.toLowerCase() === name) return v;
    }
    return undefined;
  }
  if (typeof container.get === 'function') {
    const v = container.get(name);
    return v === null ? undefined : v;
  }
  const key = Object.keys(container).find((k) => k.toLowerCase() === name);
  return key === undefined ? undefined : container[key];
}

function toText(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'string') return v.trim();
  return undefined;
}

const DECIMAL = /^\d+(?:\.\d+)?$/;

function parseRetryAfterMs(container, nowMs) {
  const rawMs = toText(readHeader(container, 'retry-after-ms'));
  if (typeof rawMs === 'number') {
    if (Number.isFinite(rawMs) && rawMs >= 0) return rawMs;
  } else if (rawMs !== undefined && DECIMAL.test(rawMs)) {
    return Number(rawMs);
  }

  const raw = toText(readHeader(container, 'retry-after'));
  if (raw === undefined) return undefined;
  if (typeof raw === 'number') {
    return Number.isFinite(raw) && raw >= 0 ? Math.round(raw * 1000) : undefined;
  }
  if (DECIMAL.test(raw)) return Math.round(Number(raw) * 1000);
  if (raw === '' || typeof nowMs !== 'number' || !Number.isFinite(nowMs)) return undefined;
  const at = Date.parse(raw);
  if (!Number.isFinite(at)) return undefined;
  return Math.max(0, at - nowMs);
}

function networkCode(error) {
  const codes = [field(error, 'code'), field(field(error, 'error'), 'code')];
  return codes.some((c) => typeof c === 'string' && NETWORK_CODES.has(c));
}

function hasQuotaCode(error) {
  const codes = [field(error, 'code'), field(field(error, 'error'), 'code')];
  return codes.some((c) => typeof c === 'string' && QUOTA_CODES.has(c));
}

function kindForStatus(status) {
  if (status === 401 || status === 403) return { kind: 'authentication', retryable: false };
  if (status === 429) return { kind: 'rate_limit', retryable: true };
  if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    return { kind: 'transient', retryable: true };
  }
  if ([400, 404, 413, 422].includes(status)) return { kind: 'invalid_request', retryable: false };
  return undefined;
}

export function classifyApiError(error, { nowMs = Date.now() } = {}) {
  const status = resolveStatus(error);
  let result;
  if (status === 402 || hasQuotaCode(error)) {
    result = { kind: 'quota', retryable: false };
  } else {
    result = (status !== undefined && kindForStatus(status)) || undefined;
    if (!result && networkCode(error)) result = { kind: 'transient', retryable: true };
    if (!result) result = { kind: 'unknown', retryable: false };
  }

  const hint = parseRetryAfterMs(headerContainer(error), nowMs);
  if (hint !== undefined) {
    result.retryAfterMs = hint;
    if (hint > MAX_RETRY_AFTER_MS && (result.kind === 'rate_limit' || result.kind === 'transient')) {
      result.retryable = false;
    }
  }
  return result;
}
