const QUOTA_CODES = new Set(['insufficient_quota', 'billing_hard_limit_reached', 'billing_not_active']);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);
const MAX_RETRY_DELAY_MS = 60000;
const DECIMAL = /^[0-9]+(?:\.[0-9]+)?$/;

function isObject(value) {
  return value !== null && (typeof value === 'object' || typeof value === 'function');
}

function parseStatus(value) {
  if (typeof value === 'number') {
    return Number.isInteger(value) && value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^(?:0|[1-9][0-9]*)$/.test(value)) {
    const n = Number(value);
    return n >= 100 && n <= 599 ? n : undefined;
  }
  return undefined;
}

function structuredStatus(error) {
  const candidates = [
    error.status,
    isObject(error.response) ? error.response.status : undefined,
    isObject(error.error) ? error.error.status : undefined,
    error.statusCode,
    error.code,
  ];
  for (const candidate of candidates) {
    const status = parseStatus(candidate);
    if (status !== undefined) return status;
  }
  return undefined;
}

function prefixStatus(error) {
  const text = typeof error === 'string' ? error : (isObject(error) && typeof error.message === 'string' ? error.message : undefined);
  if (text === undefined) return undefined;
  const match = /^\s*(?:HTTP\s+)?([0-9]{3})(?![0-9])/i.exec(text);
  return match ? parseStatus(match[1]) : undefined;
}

function hasQuotaCode(error) {
  if (QUOTA_CODES.has(error.code)) return true;
  return isObject(error.error) && QUOTA_CODES.has(error.error.code);
}

function readHeader(headers, name) {
  if (!isObject(headers)) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    return value === null ? undefined : value;
  }
  const wanted = name.toLowerCase();
  for (const key of Object.keys(headers)) {
    if (key.toLowerCase() === wanted) {
      const value = headers[key];
      return Array.isArray(value) ? value[0] : value;
    }
  }
  return undefined;
}

function headerSources(error) {
  const sources = [];
  if (isObject(error.headers)) sources.push(error.headers);
  if (isObject(error.response) && isObject(error.response.headers)) sources.push(error.response.headers);
  return sources;
}

function readHeaderFromSources(sources, name) {
  for (const source of sources) {
    const value = readHeader(source, name);
    if (value !== undefined) return value;
  }
  return undefined;
}

function parseRetryAfterMs(value) {
  if (typeof value === 'number') {
    return Number.isFinite(value) && value >= 0 ? value : undefined;
  }
  return undefined;
}

function parseRetryAfterMsHeader(value) {
  if (typeof value === 'number') return parseRetryAfterMs(value);
  if (typeof value === 'string' && DECIMAL.test(value.trim())) return Number(value.trim());
  return undefined;
}

function parseRetryAfterHeader(value, nowMs) {
  if (typeof value === 'number') {
    return Number.isFinite(value) && value >= 0 ? value * 1000 : undefined;
  }
  if (typeof value !== 'string') return undefined;
  const text = value.trim();
  if (DECIMAL.test(text)) return Number(text) * 1000;
  if (/^[-+]?[0-9.]+$/.test(text)) return undefined;
  const date = Date.parse(text);
  if (!Number.isFinite(date)) return undefined;
  return Math.max(0, date - nowMs);
}

function retryAfterHint(error, nowMs) {
  const sources = headerSources(error);
  const ms = parseRetryAfterMsHeader(readHeaderFromSources(sources, 'retry-after-ms'));
  if (ms !== undefined) return ms;
  return parseRetryAfterHeader(readHeaderFromSources(sources, 'retry-after'), nowMs);
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const result = classify(error);
  const delay = isObject(error) || typeof error === 'string' ? retryAfterHint(isObject(error) ? error : {}, nowMs) : undefined;
  if (delay === undefined) return result;
  const retryable = result.retryable && delay <= MAX_RETRY_DELAY_MS;
  return {...result, retryable, retryAfterMs: delay};
}

function classify(error) {
  if (!isObject(error)) {
    const status = prefixStatus(error);
    return statusResult(status, false);
  }
  if (hasQuotaCode(error)) return {kind: 'quota', retryable: false};
  const status = structuredStatus(error) ?? prefixStatus(error);
  if (status === 402) return {kind: 'quota', retryable: false};
  if (status !== undefined) {
    const result = statusResult(status, true);
    if (result !== undefined) return result;
  }
  if (NETWORK_CODES.has(error.code)) return {kind: 'transient', retryable: true};
  return {kind: 'unknown', retryable: false};
}

function statusResult(status, _structured) {
  if (status === 402) return {kind: 'quota', retryable: false};
  if (status === 401 || status === 403) return {kind: 'authentication', retryable: false};
  if (status === 429) return {kind: 'rate_limit', retryable: true};
  if (status === 408 || status === 409 || (status >= 500 && status <= 599)) return {kind: 'transient', retryable: true};
  if ([400, 404, 413, 422].includes(status)) return {kind: 'invalid_request', retryable: false};
  return undefined;
}
