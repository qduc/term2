const QUOTA_CODES = new Set(['insufficient_quota', 'billing_hard_limit_reached', 'billing_not_active']);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);
const MAX_IMMEDIATE_RETRY_MS = 60000;

function isObject(value) {
  return value !== null && (typeof value === 'object' || typeof value === 'function');
}

function field(value, key) {
  return isObject(value) ? value[key] : undefined;
}

// Accepts integers or numeric strings (3 digits) in 100..599.
function parseStatus(value) {
  let n;
  if (typeof value === 'number') {
    if (!Number.isInteger(value)) return undefined;
    n = value;
  } else if (typeof value === 'string' && /^\d{3}$/.test(value)) {
    n = Number(value);
  } else {
    return undefined;
  }
  return n >= 100 && n <= 599 ? n : undefined;
}

function statusFromMessage(error) {
  const text = typeof error === 'string' ? error : field(error, 'message');
  if (typeof text !== 'string') return undefined;
  const match = /^\s*(?:HTTP\s+)?(\d{3})(?![\dA-Za-z])/i.exec(text);
  return match ? parseStatus(match[1]) : undefined;
}

function structuredStatus(error) {
  const candidates = [
    field(error, 'status'),
    field(field(error, 'response'), 'status'),
    field(field(error, 'error'), 'status'),
    field(error, 'statusCode'),
    field(error, 'code'),
  ];
  for (const candidate of candidates) {
    const status = parseStatus(candidate);
    if (status !== undefined) return status;
  }
  return undefined;
}

function hasQuotaCode(error) {
  return QUOTA_CODES.has(field(error, 'code')) || QUOTA_CODES.has(field(field(error, 'error'), 'code'));
}

function headerValue(headers, name) {
  if (!isObject(headers)) return undefined;
  let value;
  if (typeof headers.get === 'function') {
    value = headers.get(name);
  } else {
    const key = Object.keys(headers).find((k) => k.toLowerCase() === name);
    value = key === undefined ? undefined : headers[key];
  }
  return typeof value === 'string' || typeof value === 'number' ? value : undefined;
}

function parseDecimal(value) {
  if (typeof value === 'number') return Number.isFinite(value) && value >= 0 ? value : undefined;
  if (typeof value !== 'string') return undefined;
  const text = value.trim();
  return /^\d+(?:\.\d+)?$/.test(text) ? Number(text) : undefined;
}

function retryAfterHint(error, nowMs) {
  const headers = field(error, 'headers') ?? field(field(error, 'response'), 'headers');

  const ms = parseDecimal(headerValue(headers, 'retry-after-ms'));
  if (ms !== undefined) return ms;

  const raw = headerValue(headers, 'retry-after');
  const seconds = parseDecimal(raw);
  if (seconds !== undefined) return seconds * 1000;
  if (typeof raw !== 'string' || !/[A-Za-z]/.test(raw) || !Number.isFinite(nowMs)) return undefined;
  const at = Date.parse(raw.trim());
  return Number.isFinite(at) ? Math.max(0, at - nowMs) : undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const status = structuredStatus(error) ?? statusFromMessage(error);
  let result;

  if (status === 402 || hasQuotaCode(error)) {
    result = {kind: 'quota', retryable: false};
  } else if (status === 401 || status === 403) {
    result = {kind: 'authentication', retryable: false};
  } else if (status === 429) {
    result = {kind: 'rate_limit', retryable: true};
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    result = {kind: 'transient', retryable: true};
  } else if ([400, 404, 413, 422].includes(status)) {
    result = {kind: 'invalid_request', retryable: false};
  } else if (NETWORK_CODES.has(field(error, 'code'))) {
    result = {kind: 'transient', retryable: true};
  } else {
    result = {kind: 'unknown', retryable: false};
  }

  const hint = retryAfterHint(error, nowMs);
  if (hint !== undefined) {
    result.retryAfterMs = hint;
    if (hint > MAX_IMMEDIATE_RETRY_MS && (result.kind === 'rate_limit' || result.kind === 'transient')) {
      result.retryable = false;
    }
  }
  return result;
}
