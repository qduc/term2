const QUOTA_CODES = new Set(['insufficient_quota', 'billing_hard_limit_reached', 'billing_not_active']);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);
const LONG_DELAY_MS = 60000;

function parseStatus(value) {
  let n;
  if (typeof value === 'number') {
    if (!Number.isInteger(value)) return undefined;
    n = value;
  } else if (typeof value === 'string' && /^\d{3}$/.test(value)) {
    n = Number(value);
  } else {
    return undefined;
  }
  return n >= 100 && n <= 599 ? n : undefined;
}

function structuredStatus(error) {
  const candidates = [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ];
  for (const candidate of candidates) {
    const status = parseStatus(candidate);
    if (status !== undefined) return status;
  }
  return undefined;
}

function messageStatus(error) {
  const message = typeof error === 'string' ? error : error?.message;
  if (typeof message !== 'string') return undefined;
  const match = /^(?:HTTP\s+)?([1-5]\d{2})(?!\d)/i.exec(message);
  return match ? parseStatus(Number(match[1])) : undefined;
}

function hasQuotaCode(error) {
  return QUOTA_CODES.has(error?.code) || QUOTA_CODES.has(error?.error?.code);
}

function kindForStatus(status) {
  if (status === 401 || status === 403) return { kind: 'authentication', retryable: false };
  if (status === 429) return { kind: 'rate_limit', retryable: true };
  if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    return { kind: 'transient', retryable: true };
  }
  if ([400, 404, 413, 422].includes(status)) return { kind: 'invalid_request', retryable: false };
  return undefined;
}

function readHeader(headers, name) {
  if (headers === undefined || headers === null) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    return value === null ? undefined : value;
  }
  if (typeof headers !== 'object') return undefined;
  const wanted = name.toLowerCase();
  for (const key of Object.keys(headers)) {
    if (key.toLowerCase() === wanted) return headers[key];
  }
  return undefined;
}

function pickHeaders(error) {
  if (error?.headers !== undefined && error?.headers !== null) return error.headers;
  return error?.response?.headers;
}

function headerText(value) {
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number') return value;
  return undefined;
}

function retryAfterMs(error, nowMs) {
  const headers = pickHeaders(error);
  if (headers === undefined || headers === null) return undefined;

  const ms = headerText(readHeader(headers, 'retry-after-ms'));
  if (typeof ms === 'number' && Number.isFinite(ms) && ms >= 0) return ms;
  if (typeof ms === 'string' && /^\d+(\.\d+)?$/.test(ms)) return Number(ms);

  const after = headerText(readHeader(headers, 'retry-after'));
  if (typeof after === 'number') {
    return Number.isFinite(after) && after >= 0 ? after * 1000 : undefined;
  }
  if (typeof after !== 'string' || after === '') return undefined;
  if (/^\d+(\.\d+)?$/.test(after)) return Number(after) * 1000;
  if (!/[A-Za-z]/.test(after) || !Number.isFinite(nowMs)) return undefined;
  const when = Date.parse(after);
  return Number.isFinite(when) ? Math.max(0, when - nowMs) : undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const status = structuredStatus(error) ?? messageStatus(error);
  let result;

  if (status === 402 || hasQuotaCode(error)) {
    result = { kind: 'quota', retryable: false };
  } else {
    result = kindForStatus(status);
    if (result === undefined) {
      const code = error?.code ?? error?.cause?.code;
      result = NETWORK_CODES.has(code)
        ? { kind: 'transient', retryable: true }
        : { kind: 'unknown', retryable: false };
    }
  }

  const delay = retryAfterMs(error, nowMs);
  if (delay === undefined) return result;

  if ((result.kind === 'rate_limit' || result.kind === 'transient') && delay > LONG_DELAY_MS) {
    return { kind: result.kind, retryable: false, retryAfterMs: delay };
  }
  return { ...result, retryAfterMs: delay };
}
