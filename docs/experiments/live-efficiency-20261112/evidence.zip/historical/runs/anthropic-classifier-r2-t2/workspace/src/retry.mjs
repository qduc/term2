import {classifyApiError} from './errors.mjs';

function abortReason(signal) {
  return signal.reason === undefined
    ? Object.assign(new Error('The operation was aborted'), {name: 'AbortError'})
    : signal.reason;
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortReason(signal);
}

function defaultSleep(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortReason(signal));
      return;
    }
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortReason(signal));
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    signal?.addEventListener('abort', onAbort, {once: true});
  });
}

export async function withRetry(operation, options = {}) {
  if (typeof operation !== 'function') throw new TypeError('operation must be a function');
  const {maxAttempts = 3, sleep = defaultSleep, now = Date.now, signal} = options;
  if (!Number.isInteger(maxAttempts) || maxAttempts < 1) {
    throw new TypeError('maxAttempts must be a positive integer');
  }
  if (typeof sleep !== 'function') throw new TypeError('sleep must be a function');
  if (typeof now !== 'function') throw new TypeError('now must be a function');

  for (let attempt = 1; ; attempt++) {
    throwIfAborted(signal);
    try {
      return await operation();
    } catch (error) {
      if (attempt >= maxAttempts) throw error;
      const classification = classifyApiError(error, {nowMs: now()});
      if (!classification.retryable) throw error;
      const delayMs = classification.retryAfterMs ?? 0;
      throwIfAborted(signal);
      await sleep(delayMs, signal);
      throwIfAborted(signal);
    }
  }
}
