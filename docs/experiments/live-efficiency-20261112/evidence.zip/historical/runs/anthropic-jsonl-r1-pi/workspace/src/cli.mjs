import fs from 'node:fs';
import { summarizeEvents } from './summary.mjs';

// Yields the lines of one source (a file path or stdin) without loading it whole.
async function* linesOf(source) {
  const stream = source === '-'
    ? process.stdin
    : fs.createReadStream(source);
  stream.setEncoding('utf8');
  let carry = '';
  for await (const chunk of stream) {
    const parts = (carry + chunk).split('\n');
    carry = parts.pop();
    yield* parts;
  }
  if (carry !== '') yield carry;
}

// Yields lines from every file in argument order.
async function* allLines(sources) {
  for (const source of sources) {
    yield* linesOf(source);
  }
}

function fail(message) {
  process.stderr.write(`${message}\n`);
  process.exitCode = 1;
}

async function main(argv) {
  if (argv.length === 0) {
    return fail('usage: node src/cli.mjs file1.jsonl [file2.jsonl ...] (use - for stdin, at most once)');
  }
  const stdinCount = argv.filter((a) => a === '-').length;
  if (stdinCount > 1) {
    return fail('invalid arguments: "-" (stdin) may appear at most once');
  }
  const badArg = argv.find((a) => a.startsWith('-') && a !== '-');
  if (badArg !== undefined) {
    return fail(`invalid arguments: unknown option ${JSON.stringify(badArg)}`);
  }

  let report;
  try {
    report = await summarizeEvents(allLines(argv));
  } catch (err) {
    return fail(`error: ${err instanceof Error ? err.message : String(err)}`);
  }

  process.stdout.write(`${JSON.stringify(report)}\n`);
  process.exitCode = report.invalidLines > 0 ? 2 : 0;
}

await main(process.argv.slice(2));
