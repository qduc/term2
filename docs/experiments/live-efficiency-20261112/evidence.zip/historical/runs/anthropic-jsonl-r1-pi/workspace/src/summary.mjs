const MAX_SAFE = BigInt(Number.MAX_SAFE_INTEGER);
const MIN_SAFE = BigInt(Number.MIN_SAFE_INTEGER);

const isNonBlankString = (v) => typeof v === 'string' && v.trim() !== '';

// Returns a normalized event copy, or null when the line is invalid.
function parseEvent(line) {
  if (typeof line !== 'string') return null;
  let e;
  try {
    e = JSON.parse(line);
  } catch {
    return null;
  }
  if (e === null || typeof e !== 'object' || Array.isArray(e)) return null;
  const { id, account, amountCents, revision } = e;
  if (!isNonBlankString(id) || !isNonBlankString(account)) return null;
  if (!Number.isSafeInteger(amountCents)) return null;
  if (!Number.isSafeInteger(revision) || revision < 0) return null;
  return { id, account, amountCents, revision };
}

export async function summarizeEvents(lines) {
  const winners = new Map(); // id -> winning event
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line === 'string' && line.trim() === '') continue;
    const ev = parseEvent(line);
    if (ev === null) {
      invalidLines++;
      continue;
    }
    const prev = winners.get(ev.id);
    if (prev === undefined) {
      winners.set(ev.id, ev);
    } else {
      duplicateEvents++;
      // Higher revision wins; on a tie the later line wins.
      if (ev.revision >= prev.revision) winners.set(ev.id, ev);
    }
  }

  // Exact aggregation with BigInt; only the final per-account sum must be safe.
  const totals = new Map(); // account -> {sum: bigint, count: number}
  for (const ev of winners.values()) {
    const cents = BigInt(ev.amountCents);
    const t = totals.get(ev.account);
    if (t === undefined) {
      totals.set(ev.account, { sum: cents, count: 1 });
    } else {
      t.sum += cents;
      t.count++;
    }
  }

  const accounts = [];
  for (const [account, t] of totals) {
    if (t.sum > MAX_SAFE || t.sum < MIN_SAFE) {
      throw new RangeError(`netCents for account ${JSON.stringify(account)} is outside the safe integer range`);
    }
    accounts.push({ account, netCents: Number(t.sum), count: t.count });
  }
  accounts.sort((a, b) => (a.account < b.account ? -1 : a.account > b.account ? 1 : 0));

  return { accounts, invalidLines, duplicateEvents };
}
