import fs from 'node:fs';
import { StringDecoder } from 'node:string_decoder';
import { summarizeEvents } from './summary.mjs';

// Yields lines from a readable stream without buffering the whole input.
async function* linesOf(input) {
  const decoder = new StringDecoder('utf8');
  let pending = '';
  for await (const chunk of input) {
    pending += decoder.write(chunk);
    let start = 0;
    let end;
    while ((end = pending.indexOf('\n', start)) !== -1) {
      yield pending.slice(start, end);
      start = end + 1;
    }
    pending = pending.slice(start);
  }
  pending += decoder.end();
  if (pending !== '') yield pending;
}

async function* allLines(args) {
  for (const arg of args) {
    if (arg === '-') {
      yield* linesOf(process.stdin);
    } else {
      const input = fs.createReadStream(arg);
      try {
        yield* linesOf(input);
      } finally {
        input.destroy();
      }
    }
  }
}

function fail(message) {
  process.stderr.write(`error: ${message}\n`);
  process.exitCode = 1;
}

async function main(args) {
  if (args.length === 0) {
    fail('usage: node src/cli.mjs <file.jsonl|-> [more files...]');
    return;
  }
  if (args.filter((arg) => arg === '-').length > 1) {
    fail("'-' (stdin) may appear at most once");
    return;
  }
  let report;
  try {
    report = await summarizeEvents(allLines(args));
  } catch (err) {
    fail(err instanceof Error ? err.message : String(err));
    return;
  }
  process.stdout.write(`${JSON.stringify(report)}\n`);
  process.exitCode = report.invalidLines > 0 ? 2 : 0;
}

await main(process.argv.slice(2));
