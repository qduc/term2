function isNonBlankString(value) {
  return typeof value === 'string' && value.trim() !== '';
}

// Returns the parsed event, or null when the line is invalid.
function parseEvent(line) {
  if (typeof line !== 'string') return null;
  let event;
  try {
    event = JSON.parse(line);
  } catch {
    return null;
  }
  if (typeof event !== 'object' || event === null || Array.isArray(event)) return null;
  if (!isNonBlankString(event.id) || !isNonBlankString(event.account)) return null;
  if (!Number.isSafeInteger(event.amountCents)) return null;
  if (!Number.isSafeInteger(event.revision) || event.revision < 0) return null;
  return event;
}

export async function summarizeEvents(lines) {
  let invalidLines = 0;
  let duplicateEvents = 0;
  const winners = new Map();

  for await (const line of lines) {
    if (typeof line === 'string' && line.trim() === '') continue;
    const event = parseEvent(line);
    if (event === null) {
      invalidLines++;
      continue;
    }
    const current = winners.get(event.id);
    if (current === undefined) {
      winners.set(event.id, event);
      continue;
    }
    duplicateEvents++;
    // Highest revision wins; on a tie the later valid line wins.
    if (event.revision >= current.revision) winners.set(event.id, event);
  }

  const byAccount = new Map();
  for (const event of winners.values()) {
    let entry = byAccount.get(event.account);
    if (entry === undefined) {
      entry = { account: event.account, netCents: 0, count: 0 };
      byAccount.set(event.account, entry);
    }
    const netCents = entry.netCents + event.amountCents;
    if (!Number.isSafeInteger(netCents)) {
      throw new RangeError(`aggregate netCents for account overflows safe integer range`);
    }
    entry.netCents = netCents;
    entry.count++;
  }

  const accounts = [...byAccount.values()].sort((a, b) =>
    a.account < b.account ? -1 : a.account > b.account ? 1 : 0,
  );
  return { accounts, invalidLines, duplicateEvents };
}
