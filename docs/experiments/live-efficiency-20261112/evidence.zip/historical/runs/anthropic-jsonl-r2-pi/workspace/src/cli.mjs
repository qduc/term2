import fs from 'node:fs';
import { summarizeEvents } from './summary.mjs';

const USAGE = 'usage: node src/cli.mjs file1.jsonl [file2.jsonl ...] (use - for stdin, at most once)';

// Yields the lines of a readable stream, splitting on LF. Stream errors reject.
async function* linesOf(stream) {
  let carry = '';
  for await (const chunk of stream) {
    const parts = String(chunk).split('\n');
    parts[0] = carry + parts[0];
    carry = parts.pop();
    for (const part of parts) yield part;
  }
  if (carry !== '') yield carry;
}

// Yields lines from each source in argument order, streaming, one file at a time.
async function* allLines(sources) {
  for (const source of sources) {
    const stream = source === '-'
      ? process.stdin
      : fs.createReadStream(source, { encoding: 'utf8' });
    try {
      yield* linesOf(stream);
    } finally {
      if (stream !== process.stdin) stream.destroy();
    }
  }
}

async function main(argv) {
  if (argv.length === 0) {
    throw new UsageError('at least one argument is required');
  }
  if (argv.filter((arg) => arg === '-').length > 1) {
    throw new UsageError("'-' (stdin) may appear at most once");
  }
  const report = await summarizeEvents(allLines(argv));
  process.stdout.write(`${JSON.stringify(report)}\n`);
  return report.invalidLines > 0 ? 2 : 0;
}

class UsageError extends Error {}

main(process.argv.slice(2)).then(
  (code) => {
    process.exitCode = code;
  },
  (err) => {
    const message = err instanceof UsageError
      ? `${err.message}\n${USAGE}`
      : `${err?.message ?? String(err)}`;
    process.stderr.write(`error: ${message}\n`);
    process.exitCode = 1;
  },
);
