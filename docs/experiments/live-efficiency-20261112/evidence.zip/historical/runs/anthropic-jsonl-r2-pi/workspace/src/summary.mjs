const MAX_SAFE = BigInt(Number.MAX_SAFE_INTEGER);
const MIN_SAFE = BigInt(Number.MIN_SAFE_INTEGER);

// Returns a validated event object, or null when the line is invalid.
// Blank lines are handled by the caller before this is reached.
function parseEvent(line) {
  if (typeof line !== 'string') return null;
  let value;
  try {
    value = JSON.parse(line);
  } catch {
    return null;
  }
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return null;
  const { id, account, amountCents, revision } = value;
  if (typeof id !== 'string' || id.trim() === '') return null;
  if (typeof account !== 'string' || account.trim() === '') return null;
  if (!Number.isSafeInteger(amountCents)) return null;
  if (!Number.isSafeInteger(revision) || revision < 0) return null;
  return { id, account, amountCents, revision };
}

function isBlank(line) {
  return typeof line === 'string' && line.trim() === '';
}

export async function summarizeEvents(lines) {
  const winners = new Map(); // id -> winning event
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (isBlank(line)) continue;
    const event = parseEvent(line);
    if (event === null) {
      invalidLines++;
      continue;
    }
    const current = winners.get(event.id);
    if (current === undefined) {
      winners.set(event.id, event);
      continue;
    }
    duplicateEvents++;
    // Higher revision wins; equal revision lets the later line win.
    if (event.revision >= current.revision) winners.set(event.id, event);
  }

  const totals = new Map(); // account -> { net: bigint, count: number }
  for (const event of winners.values()) {
    let total = totals.get(event.account);
    if (total === undefined) {
      total = { net: 0n, count: 0 };
      totals.set(event.account, total);
    }
    total.net += BigInt(event.amountCents);
    total.count++;
  }

  const accounts = [];
  for (const [account, { net, count }] of totals) {
    if (net > MAX_SAFE || net < MIN_SAFE) {
      throw new RangeError(`aggregate netCents for account ${JSON.stringify(account)} is outside the safe integer range`);
    }
    accounts.push({ account, netCents: Number(net), count });
  }
  accounts.sort((a, b) => (a.account < b.account ? -1 : a.account > b.account ? 1 : 0));

  return { accounts, invalidLines, duplicateEvents };
}
