import fs from 'node:fs';
import {StringDecoder} from 'node:string_decoder';
import {summarizeEvents} from './summary.mjs';

// Yields the lines of one readable source, splitting on LF while streaming.
async function* linesOf(source) {
  const decoder = new StringDecoder('utf8');
  let pending = '';
  try {
    for await (const chunk of source) {
      pending += typeof chunk === 'string' ? chunk : decoder.write(chunk);
      let start = 0;
      let newline;
      while ((newline = pending.indexOf('\n', start)) !== -1) {
        const line = pending.slice(start, newline);
        start = newline + 1;
        yield line;
      }
      pending = pending.slice(start);
    }
    pending += decoder.end();
    if (pending !== '') yield pending;
  } finally {
    if (!source.destroyed) source.destroy();
  }
}

// Yields lines from every argument in order; '-' means stdin.
async function* allLines(args) {
  for (const arg of args) {
    if (arg === '-') {
      yield* linesOf(process.stdin);
    } else {
      yield* linesOf(fs.createReadStream(arg));
    }
  }
}

function fail(message) {
  process.stderr.write(`error: ${message}\n`);
  process.exitCode = 1;
}

const args = process.argv.slice(2);
const badOption = args.find((a) => a.startsWith('-') && a !== '-');

if (args.length === 0) {
  fail('usage: node src/cli.mjs file1.jsonl [file2.jsonl ...] (use - for stdin)');
} else if (args.includes('')) {
  fail('empty file argument');
} else if (badOption !== undefined) {
  fail(`invalid argument: ${badOption}`);
} else if (args.filter((a) => a === '-').length > 1) {
  fail("'-' (stdin) may appear at most once");
} else {
  try {
    const report = await summarizeEvents(allLines(args));
    console.log(JSON.stringify(report));
    process.exitCode = report.invalidLines > 0 ? 2 : 0;
  } catch (error) {
    fail(error instanceof Error ? error.message : String(error));
  }
}
