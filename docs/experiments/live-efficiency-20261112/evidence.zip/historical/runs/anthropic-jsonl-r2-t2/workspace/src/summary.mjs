const MAX_SAFE = BigInt(Number.MAX_SAFE_INTEGER);

const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const isNonBlankString = (v) => typeof v === 'string' && v.trim() !== '';

// Returns the validated event fields, or null when the line is invalid.
function parseEvent(line) {
  if (typeof line !== 'string') return null;
  let value;
  try {
    value = JSON.parse(line);
  } catch {
    return null;
  }
  if (!isPlainObject(value)) return null;
  const {id, account, amountCents, revision} = value;
  if (!isNonBlankString(id) || !isNonBlankString(account)) return null;
  if (!Number.isSafeInteger(amountCents)) return null;
  if (!Number.isSafeInteger(revision) || revision < 0) return null;
  return {id, account, amountCents, revision};
}

export async function summarizeEvents(lines) {
  const winners = new Map(); // id -> winning event
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line === 'string' && line.trim() === '') continue;
    const event = parseEvent(line);
    if (event === null) {
      invalidLines++;
      continue;
    }
    const previous = winners.get(event.id);
    if (previous !== undefined) {
      duplicateEvents++;
      if (event.revision < previous.revision) continue;
    }
    winners.set(event.id, event);
  }

  // Exact (BigInt) per-account sums so the result does not depend on order.
  const totals = new Map(); // account -> {total: bigint, count: number}
  for (const event of winners.values()) {
    let entry = totals.get(event.account);
    if (entry === undefined) {
      entry = {total: 0n, count: 0};
      totals.set(event.account, entry);
    }
    entry.total += BigInt(event.amountCents);
    entry.count++;
  }

  const accounts = [];
  for (const [account, {total, count}] of totals) {
    if (total > MAX_SAFE || total < -MAX_SAFE) {
      throw new RangeError(`aggregate netCents for account is outside the safe integer range`);
    }
    accounts.push({account, netCents: Number(total), count});
  }
  accounts.sort((x, y) => (x.account < y.account ? -1 : x.account > y.account ? 1 : 0));

  return {accounts, invalidLines, duplicateEvents};
}
