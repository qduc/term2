import fs from 'node:fs';
import { collectPages } from './pages.mjs';

function fail(message) {
  process.stderr.write(`error: ${message}\n`);
  process.exitCode = 1;
}

async function main() {
  const file = process.argv[2];
  if (typeof file !== 'string') {
    throw new Error('usage: node src/cli.mjs pages.json');
  }
  const pages = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!Array.isArray(pages)) {
    throw new TypeError('pages file must contain an array');
  }
  const fetchPage = async ({ cursor }) => {
    // JSON null denotes the initial (undefined) cursor.
    const key = cursor === undefined ? null : cursor;
    const page = pages.find((p) => p !== null && typeof p === 'object' && p.cursor === key);
    if (page === undefined) {
      throw new Error(`no page for cursor ${JSON.stringify(key)}`);
    }
    return page;
  };
  const items = await collectPages(fetchPage);
  process.stdout.write(`${JSON.stringify(items)}\n`);
}

try {
  await main();
} catch (error) {
  fail(error instanceof Error ? error.message : String(error));
}
