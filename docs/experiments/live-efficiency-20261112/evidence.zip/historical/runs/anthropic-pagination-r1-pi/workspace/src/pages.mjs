const DEFAULT_MAX_PAGES = 100;

function isCursor(value) {
  return typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));
}

function isTerminal(cursor) {
  return cursor === null || cursor === undefined;
}

function throwIfAborted(signal) {
  if (signal === undefined || signal === null || signal.aborted !== true) return;
  if (signal.reason !== undefined) throw signal.reason;
  const error = new Error('This operation was aborted');
  error.name = 'AbortError';
  throw error;
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }
  if (options === null || typeof options !== 'object') {
    throw new TypeError('options must be an object');
  }
  const maxPages = options.maxPages === undefined ? DEFAULT_MAX_PAGES : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }
  const signal = options.signal;
  if (signal !== undefined && (signal === null || typeof signal !== 'object')) {
    throw new TypeError('signal must be an AbortSignal-like object');
  }
  const startCursor = options.cursor;
  if (!isTerminal(startCursor) && !isCursor(startCursor)) {
    throw new TypeError('cursor must be a string, finite number, null or undefined');
  }

  let cursor = isTerminal(startCursor) ? undefined : startCursor;
  const seen = new Set();
  if (cursor !== undefined) seen.add(cursor);
  const items = [];
  let fetched = 0;

  for (;;) {
    throwIfAborted(signal);
    const page = await fetchPage({ cursor, signal });
    fetched += 1;
    throwIfAborted(signal);

    if (page === null || typeof page !== 'object') {
      throw new TypeError('page must be an object');
    }
    if (!Array.isArray(page.items)) {
      throw new TypeError('page.items must be an array');
    }
    const pageItems = page.items;
    for (let i = 0; i < pageItems.length; i += 1) {
      items.push(pageItems[i]);
    }

    const next = page.nextCursor;
    if (isTerminal(next)) return items;
    if (!isCursor(next)) {
      throw new TypeError('nextCursor must be a string, finite number, null or undefined');
    }
    if (seen.has(next)) {
      throw new Error(`repeated cursor detected: ${JSON.stringify(next)}`);
    }
    if (fetched >= maxPages) {
      throw new RangeError(`collectPages would exceed maxPages (${maxPages})`);
    }
    seen.add(next);
    cursor = next;
  }
}
