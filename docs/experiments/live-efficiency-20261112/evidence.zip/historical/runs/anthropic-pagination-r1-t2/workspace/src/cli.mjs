import fs from 'node:fs';
import { collectPages } from './pages.mjs';

try {
  const file = process.argv[2];
  if (typeof file !== 'string') throw new TypeError('usage: node src/cli.mjs pages.json');
  const entries = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!Array.isArray(entries)) throw new TypeError('pages file must contain an array');

  const items = await collectPages(async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    const entry = entries.find((p) => p !== null && typeof p === 'object' && p.cursor === key);
    if (entry === undefined) throw new Error(`no page for cursor ${JSON.stringify(key)}`);
    return entry;
  });
  process.stdout.write(`${JSON.stringify(items)}\n`);
} catch (err) {
  process.stderr.write(`error: ${err instanceof Error ? err.message : String(err)}\n`);
  process.exitCode = 1;
}
