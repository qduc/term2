const DEFAULT_MAX_PAGES = 100;

function isValidCursor(cursor) {
  return typeof cursor === 'string' || (typeof cursor === 'number' && Number.isFinite(cursor));
}

function checkAborted(signal) {
  if (signal === undefined || signal === null || !signal.aborted) return;
  if (signal.reason !== undefined) throw signal.reason;
  const error = new Error('The operation was aborted');
  error.name = 'AbortError';
  throw error;
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object') throw new TypeError('options must be an object');

  const { signal } = options;
  if (signal !== undefined && signal !== null && typeof signal !== 'object') {
    throw new TypeError('signal must be an AbortSignal-like object');
  }

  const maxPages = options.maxPages === undefined ? DEFAULT_MAX_PAGES : options.maxPages;
  if (!Number.isInteger(maxPages)) throw new TypeError('maxPages must be an integer');
  if (maxPages < 1) throw new RangeError('maxPages must be a positive integer');

  const start = options.cursor;
  if (start !== undefined && start !== null && !isValidCursor(start)) {
    throw new TypeError('cursor must be a string or finite number');
  }

  let cursor = start === null ? undefined : start;
  const seen = new Set();
  if (cursor !== undefined) seen.add(cursor);

  const items = [];
  let fetched = 0;
  for (;;) {
    if (fetched >= maxPages) throw new RangeError(`collectPages would exceed maxPages (${maxPages})`);

    checkAborted(signal);
    const page = await fetchPage({ cursor, signal });
    fetched += 1;
    checkAborted(signal);

    if (page === null || typeof page !== 'object') throw new TypeError('page must be an object');
    if (!Array.isArray(page.items)) throw new TypeError('page.items must be an array');
    for (let i = 0; i < page.items.length; i += 1) items.push(page.items[i]);

    const next = page.nextCursor;
    if (next === undefined || next === null) return items;
    if (!isValidCursor(next)) throw new TypeError('nextCursor must be a string, finite number, null, or undefined');
    if (seen.has(next)) throw new Error('repeated cursor detected; refusing to fetch it twice');
    seen.add(next);
    cursor = next;
  }
}
