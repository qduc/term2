import fs from 'node:fs';
import { collectPages } from './pages.mjs';

function describe(err) {
  if (err instanceof Error) return err.message;
  try {
    return String(err);
  } catch {
    return 'unknown error';
  }
}

async function main(argv) {
  const file = argv[2];
  if (file === undefined) {
    throw new TypeError('usage: node src/cli.mjs pages.json');
  }

  let pages;
  try {
    pages = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (err) {
    throw new Error(`cannot read ${file}: ${describe(err)}`);
  }
  if (!Array.isArray(pages)) {
    throw new TypeError(`${file} must contain an array of pages`);
  }

  const items = await collectPages(async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    const page = pages.find(
      (p) => p !== null && typeof p === 'object' && p.cursor === key,
    );
    if (page === undefined) throw new Error(`no page for cursor ${JSON.stringify(key)}`);
    return page;
  });

  process.stdout.write(`${JSON.stringify(items)}\n`);
}

try {
  await main(process.argv);
} catch (err) {
  process.stderr.write(`error: ${describe(err)}\n`);
  process.exitCode = 1;
}
