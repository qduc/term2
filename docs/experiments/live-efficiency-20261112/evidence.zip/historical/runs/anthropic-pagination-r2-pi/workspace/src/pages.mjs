const DEFAULT_MAX_PAGES = 100;

function isCursor(value) {
  return typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));
}

// Distinguishes numeric cursors from string cursors with the same spelling.
function cursorKey(cursor) {
  return `${typeof cursor}:${String(cursor)}`;
}

function checkAborted(signal) {
  if (signal === undefined || !signal.aborted) return;
  if (signal.reason !== undefined) throw signal.reason;
  const err = new Error('This operation was aborted');
  err.name = 'AbortError';
  throw err;
}

// Returns { items, nextCursor } where nextCursor is undefined for a terminal page.
function readPage(page) {
  if (page === null || typeof page !== 'object' || Array.isArray(page)) {
    throw new TypeError('page must be an object');
  }
  if (!Array.isArray(page.items)) {
    throw new TypeError('page.items must be an array');
  }
  const next = page.nextCursor;
  if (next === undefined || next === null) return { items: page.items, nextCursor: undefined };
  if (!isCursor(next)) {
    throw new TypeError('page.nextCursor must be a string, finite number, null, or undefined');
  }
  return { items: page.items, nextCursor: next };
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object') throw new TypeError('options must be an object');

  const maxPages = options.maxPages === undefined ? DEFAULT_MAX_PAGES : options.maxPages;
  if (!Number.isSafeInteger(maxPages) || maxPages < 1) {
    throw new TypeError('maxPages must be a positive integer');
  }

  const signal = options.signal;
  if (signal !== undefined && (signal === null || typeof signal !== 'object')) {
    throw new TypeError('signal must be an AbortSignal');
  }

  // A null starting cursor denotes the initial undefined cursor.
  let cursor = options.cursor === null ? undefined : options.cursor;
  if (cursor !== undefined && !isCursor(cursor)) {
    throw new TypeError('cursor must be a string, finite number, null, or undefined');
  }

  const seen = new Set();
  if (cursor !== undefined) seen.add(cursorKey(cursor));

  const items = [];
  let fetched = 0;
  for (;;) {
    checkAborted(signal);
    const raw = await fetchPage({ cursor, signal });
    fetched += 1;
    checkAborted(signal);

    const page = readPage(raw);
    for (let i = 0; i < page.items.length; i += 1) items.push(page.items[i]);

    const next = page.nextCursor;
    if (next === undefined) return items;

    const key = cursorKey(next);
    if (seen.has(key)) {
      throw new Error(`repeated cursor ${JSON.stringify(next)}; refusing to fetch it again`);
    }
    if (fetched >= maxPages) {
      throw new RangeError(`collection would exceed maxPages (${maxPages})`);
    }
    seen.add(key);
    cursor = next;
  }
}
