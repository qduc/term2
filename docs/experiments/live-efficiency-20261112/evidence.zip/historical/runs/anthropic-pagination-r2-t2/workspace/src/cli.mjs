import fs from 'node:fs';
import { collectPages } from './pages.mjs';

function fail(error) {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(`error: ${message}\n`);
  process.exitCode = 1;
}

async function main(argv) {
  const file = argv[2];
  if (typeof file !== 'string' || file.length === 0) {
    throw new TypeError('usage: node src/cli.mjs pages.json');
  }
  const pages = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!Array.isArray(pages)) throw new TypeError('pages file must contain an array');

  // Cursor null denotes the initial (undefined) cursor.
  const items = await collectPages(async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    const entry = pages.find((p) => p !== null && typeof p === 'object' && p.cursor === key);
    if (entry === undefined) throw new Error(`no page for cursor ${JSON.stringify(key)}`);
    return entry;
  });
  process.stdout.write(`${JSON.stringify(items)}\n`);
}

try {
  await main(process.argv);
} catch (error) {
  fail(error);
}
