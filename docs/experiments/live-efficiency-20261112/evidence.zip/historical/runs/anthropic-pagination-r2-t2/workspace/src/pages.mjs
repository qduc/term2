const DEFAULT_MAX_PAGES = 100;

function isCursor(value) {
  return typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));
}

// Distinguishes types so that '1', 1 and '' / 0 remain distinct cursors.
function cursorKey(cursor) {
  return `${typeof cursor}:${String(cursor)}`;
}

function checkAbort(signal) {
  if (signal === undefined || !signal.aborted) return;
  if (signal.reason !== undefined) throw signal.reason;
  const error = new Error('This operation was aborted');
  error.name = 'AbortError';
  throw error;
}

function validateSignal(signal) {
  if (signal === undefined) return;
  if (signal === null || typeof signal !== 'object' || typeof signal.aborted !== 'boolean') {
    throw new TypeError('options.signal must be an AbortSignal');
  }
}

function validateMaxPages(maxPages) {
  if (typeof maxPages !== 'number' || !Number.isSafeInteger(maxPages)) {
    throw new TypeError('maxPages must be a positive integer');
  }
  if (maxPages < 1) {
    throw new RangeError('maxPages must be a positive integer');
  }
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object') throw new TypeError('options must be an object');

  const maxPages = options.maxPages === undefined ? DEFAULT_MAX_PAGES : options.maxPages;
  validateMaxPages(maxPages);
  const signal = options.signal;
  validateSignal(signal);

  let startCursor = options.cursor;
  if (startCursor === null) startCursor = undefined;
  if (startCursor !== undefined && !isCursor(startCursor)) {
    throw new TypeError('options.cursor must be a string, finite number, null or undefined');
  }

  const seen = new Set();
  if (startCursor !== undefined) seen.add(cursorKey(startCursor));

  const items = [];
  let cursor = startCursor;
  let fetched = 0;

  for (;;) {
    checkAbort(signal);
    if (fetched >= maxPages) {
      throw new RangeError(`collectPages would exceed maxPages (${maxPages})`);
    }
    fetched += 1;

    const page = await fetchPage({ cursor, signal });
    checkAbort(signal);

    if (page === null || typeof page !== 'object') throw new TypeError('page must be an object');
    if (!Array.isArray(page.items)) throw new TypeError('page.items must be an array');
    const next = page.nextCursor;
    if (next !== null && next !== undefined && !isCursor(next)) {
      throw new TypeError('page.nextCursor must be a string, finite number, null or undefined');
    }

    for (let i = 0; i < page.items.length; i += 1) items.push(page.items[i]);

    if (next === null || next === undefined) break;

    const key = cursorKey(next);
    if (seen.has(key)) throw new Error(`repeated cursor detected: ${String(next)}`);
    seen.add(key);
    cursor = next;
  }

  return items;
}
