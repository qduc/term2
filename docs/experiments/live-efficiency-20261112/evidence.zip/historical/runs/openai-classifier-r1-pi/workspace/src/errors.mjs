const QUOTA_CODES = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);

function parseStatus(value) {
  if (typeof value === 'number') {
    return Number.isInteger(value) && value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^\d+$/.test(value)) {
    const status = Number(value);
    return status >= 100 && status <= 599 ? status : undefined;
  }
  return undefined;
}

function statusFromPrefix(value) {
  if (typeof value !== 'string') return undefined;
  const match = /^\s*(?:HTTP\s+)?(\d{3})(?=$|[\s:])/i.exec(value);
  return match ? parseStatus(match[1]) : undefined;
}

function getStatus(error) {
  const candidates = [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ];
  for (const candidate of candidates) {
    const status = parseStatus(candidate);
    if (status !== undefined) return status;
  }
  return statusFromPrefix(error) ?? statusFromPrefix(error?.error) ?? statusFromPrefix(error?.message);
}

function isQuota(error, status) {
  return status === 402 || [
    error?.code,
    error?.error?.code,
    error?.error?.error?.code,
  ].some((code) => QUOTA_CODES.has(code));
}

function headerValue(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    return value == null ? undefined : value;
  }
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function parseRetryAfterMs(value) {
  if (typeof value === 'number') {
    return Number.isFinite(value) && value >= 0 ? value : undefined;
  }
  if (typeof value === 'string' && value.trim() !== '') {
    const trimmed = value.trim();
    if (/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(trimmed)) {
      const milliseconds = Number(trimmed);
      return Number.isFinite(milliseconds) && milliseconds >= 0 ? milliseconds : undefined;
    }
  }
  return undefined;
}

function getRetryAfterMs(error, nowMs) {
  const headers = error?.headers ?? error?.response?.headers;
  const milliseconds = parseRetryAfterMs(headerValue(headers, 'retry-after-ms'));
  if (milliseconds !== undefined) return milliseconds;

  const value = headerValue(headers, 'retry-after');
  if (typeof value !== 'string' && typeof value !== 'number') return undefined;
  const text = String(value).trim();
  if (/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)) {
    const seconds = Number(text);
    return Number.isFinite(seconds) && seconds >= 0 ? seconds * 1000 : undefined;
  }
  const dateMs = Date.parse(text);
  if (!Number.isFinite(dateMs)) return undefined;
  return Math.max(0, dateMs - nowMs);
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const status = getStatus(error);
  let kind = 'unknown';
  let retryable = false;

  if (isQuota(error, status)) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if (status === 400 || status === 404 || status === 413 || status === 422) {
    kind = 'invalid_request';
  } else if (NETWORK_CODES.has(error?.code)) {
    kind = 'transient';
    retryable = true;
  }

  const retryAfterMs = getRetryAfterMs(error, nowMs);
  const result = {kind, retryable};
  if (retryAfterMs !== undefined) {
    result.retryAfterMs = retryAfterMs;
    if ((kind === 'rate_limit' || kind === 'transient') && retryAfterMs > 60000) {
      result.retryable = false;
    }
  }
  return result;
}
