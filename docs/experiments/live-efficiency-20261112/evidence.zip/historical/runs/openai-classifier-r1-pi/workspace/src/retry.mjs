import {classifyApiError} from './errors.mjs';

function abortError() {
  if (typeof DOMException === 'function') return new DOMException('The operation was aborted', 'AbortError');
  const error = new Error('The operation was aborted');
  error.name = 'AbortError';
  return error;
}

function throwIfAborted(signal) {
  if (signal?.aborted) {
    throw signal.reason !== undefined ? signal.reason : abortError();
  }
}

function delay(delayMs, signal) {
  return new Promise((resolve, reject) => {
    try {
      throwIfAborted(signal);
    } catch (error) {
      reject(error);
      return;
    }

    let timer;
    const cleanup = () => {
      if (timer !== undefined) clearTimeout(timer);
      signal?.removeEventListener?.('abort', onAbort);
    };
    const onAbort = () => {
      cleanup();
      try {
        throwIfAborted(signal);
      } catch (error) {
        reject(error);
      }
    };

    timer = setTimeout(() => {
      cleanup();
      resolve();
    }, delayMs);
    signal?.addEventListener?.('abort', onAbort, {once: true});
    // Cover an abort occurring between the initial check and listener setup.
    if (signal?.aborted) onAbort();
  });
}

export async function withRetry(operation, {maxAttempts = 3, sleep = delay, now = Date.now, signal} = {}) {
  if (typeof operation !== 'function') throw new TypeError('operation must be a function');
  if (!Number.isInteger(maxAttempts) || maxAttempts <= 0) {
    throw new RangeError('maxAttempts must be a positive integer');
  }

  for (let attempt = 1; ; attempt++) {
    throwIfAborted(signal);
    try {
      return await operation();
    } catch (error) {
      const classification = classifyApiError(error, {nowMs: now()});
      if (!classification.retryable || attempt >= maxAttempts) throw error;
      await sleep(classification.retryAfterMs ?? 0, signal);
      throwIfAborted(signal);
    }
  }
}
