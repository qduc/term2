const quotaCodes = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

function statusNumber(value) {
  if (typeof value === 'number' && Number.isInteger(value)) {
    return value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^\d+$/.test(value.trim())) {
    const number = Number(value.trim());
    return number >= 100 && number <= 599 ? number : undefined;
  }
  return undefined;
}

function getStatus(error) {
  for (const value of [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ]) {
    const status = statusNumber(value);
    if (status !== undefined) return status;
  }

  for (const value of [error?.error, error?.message]) {
    if (typeof value !== 'string') continue;
    const match = /^(?:\s*(\d{3})\s*:|\s*HTTP\s+(\d{3})\b)/i.exec(value);
    if (match) return statusNumber(match[1] ?? match[2]);
  }
  return undefined;
}

function getHeader(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    if (value !== null && value !== undefined) return value;
  }
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function finiteNonnegative(value) {
  if (typeof value === 'number') {
    return Number.isFinite(value) && value >= 0 ? value : undefined;
  }
  if (typeof value !== 'string' || value.trim() === '') return undefined;
  const number = Number(value.trim());
  return Number.isFinite(number) && number >= 0 ? number : undefined;
}

function getRetryAfterMs(error, nowMs) {
  const headers = error?.headers ?? error?.response?.headers;
  const ms = finiteNonnegative(getHeader(headers, 'retry-after-ms'));
  if (ms !== undefined) return ms;

  const value = getHeader(headers, 'retry-after');
  if (typeof value !== 'string') return undefined;
  const input = value.trim();
  if (/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(input)) {
    const seconds = Number(input);
    const delay = seconds * 1000;
    return Number.isFinite(delay) ? delay : undefined;
  }
  const date = Date.parse(input);
  if (!Number.isFinite(date)) return undefined;
  const delay = date - nowMs;
  return Number.isFinite(delay) ? Math.max(0, delay) : undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const status = getStatus(error);
  const codes = [error?.code, error?.error?.code];
  const isQuotaCode = codes.some((code) => typeof code === 'string' && quotaCodes.has(code));

  let kind = 'unknown';
  let retryable = false;
  if (status === 402 || isQuotaCode) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if (status === 400 || status === 404 || status === 413 || status === 422) {
    kind = 'invalid_request';
  } else if (status === undefined && ['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN'].includes(error?.code)) {
    kind = 'transient';
    retryable = true;
  }

  const retryAfterMs = getRetryAfterMs(error, nowMs);
  if (retryAfterMs === undefined) return {kind, retryable};
  if (retryAfterMs > 60000 && (kind === 'rate_limit' || kind === 'transient')) {
    retryable = false;
  }
  return {kind, retryable, retryAfterMs};
}
