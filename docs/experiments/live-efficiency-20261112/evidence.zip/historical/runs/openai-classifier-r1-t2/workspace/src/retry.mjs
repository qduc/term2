import {classifyApiError} from './errors.mjs';

function abortReason(signal) {
  if (signal != null && 'reason' in signal && signal.reason !== undefined) return signal.reason;
  return new DOMException('The operation was aborted', 'AbortError');
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortReason(signal);
}

function abortableDelay(delayMs, signal) {
  if (signal == null) return new Promise((resolve) => setTimeout(resolve, delayMs));
  if (signal.aborted) return Promise.reject(abortReason(signal));

  return new Promise((resolve, reject) => {
    const cleanup = () => signal.removeEventListener('abort', onAbort);
    const timer = setTimeout(() => {
      cleanup();
      resolve();
    }, delayMs);
    const onAbort = () => {
      clearTimeout(timer);
      cleanup();
      reject(abortReason(signal));
    };
    signal.addEventListener('abort', onAbort, {once: true});
  });
}

export async function withRetry(operation, options = {}) {
  const {
    maxAttempts = 3,
    sleep = abortableDelay,
    now = Date.now,
    signal,
  } = options;
  if (typeof operation !== 'function') throw new TypeError('operation must be a function');
  if (!Number.isInteger(maxAttempts) || maxAttempts <= 0) {
    throw new RangeError('maxAttempts must be a positive integer');
  }

  for (let attempt = 1; ; attempt += 1) {
    throwIfAborted(signal);
    try {
      return await operation();
    } catch (error) {
      const classification = classifyApiError(error, {nowMs: now()});
      if (!classification.retryable || attempt >= maxAttempts) throw error;
      await sleep(classification.retryAfterMs ?? 0, signal);
      throwIfAborted(signal);
    }
  }
}
