const QUOTA_CODES = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);

function statusValue(value) {
  if (typeof value === 'number' && Number.isInteger(value)) {
    return value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^\d+$/.test(value.trim())) {
    const status = Number(value.trim());
    return status >= 100 && status <= 599 ? status : undefined;
  }
  return undefined;
}

function statusFromPrefix(value) {
  if (typeof value !== 'string') return undefined;
  const match = value.match(/^\s*(?:HTTP\s+)?(\d{3})(?=\s|:|$)/i);
  return match ? statusValue(match[1]) : undefined;
}

function headerValue(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    if (value !== null && value !== undefined) return value;
    return undefined;
  }
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function retryDelay(error, nowMs) {
  const headers = error?.headers ?? error?.response?.headers;
  const milliseconds = headerValue(headers, 'retry-after-ms');
  if (typeof milliseconds === 'number' && Number.isFinite(milliseconds) && milliseconds >= 0) {
    return milliseconds;
  }
  if (typeof milliseconds === 'string' && milliseconds.trim() !== '') {
    const parsed = Number(milliseconds.trim());
    if (Number.isFinite(parsed) && parsed >= 0) return parsed;
  }

  const retryAfter = headerValue(headers, 'retry-after');
  if (typeof retryAfter !== 'string' && typeof retryAfter !== 'number') return undefined;
  const value = String(retryAfter).trim();
  if (/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(value)) {
    const delay = Number(value) * 1000;
    return Number.isFinite(delay) ? delay : undefined;
  }
  if (!/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), \d{2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4} \d{2}:\d{2}:\d{2} GMT$/.test(value)) {
    return undefined;
  }
  const date = Date.parse(value);
  if (!Number.isFinite(date) || !Number.isFinite(nowMs)) return undefined;
  return Math.max(0, date - nowMs);
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const nestedError = error?.error;
  const quotaCode = [error?.code, nestedError?.code].some(
    (code) => typeof code === 'string' && QUOTA_CODES.has(code),
  );

  const candidates = [
    error?.status,
    error?.response?.status,
    nestedError?.status,
    error?.statusCode,
    typeof error?.code === 'number' || (typeof error?.code === 'string' && /^\s*\d+\s*$/.test(error.code))
      ? error.code
      : undefined,
  ];
  let status;
  for (const candidate of candidates) {
    status = statusValue(candidate);
    if (status !== undefined) break;
  }
  if (status === undefined) {
    status = statusFromPrefix(typeof error === 'string' ? error : nestedError)
      ?? statusFromPrefix(nestedError?.message)
      ?? statusFromPrefix(error?.message);
  }

  let kind = 'unknown';
  let retryable = false;
  if (status === 402 || quotaCode) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if ([400, 404, 413, 422].includes(status)) {
    kind = 'invalid_request';
  } else if (status === undefined && NETWORK_CODES.has(error?.code)) {
    kind = 'transient';
    retryable = true;
  }

  const delay = retryDelay(error, nowMs);
  const result = {kind, retryable};
  if (delay !== undefined) {
    result.retryAfterMs = delay;
    if (delay > 60000 && (kind === 'rate_limit' || kind === 'transient')) result.retryable = false;
  }
  return result;
}
