const QUOTA_CODES = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

function parseStatus(value) {
  if (typeof value === 'number' && Number.isInteger(value)) {
    return value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^\d+$/.test(value)) {
    const status = Number(value);
    return status >= 100 && status <= 599 ? status : undefined;
  }
  return undefined;
}

function statusFromPrefix(value) {
  if (typeof value !== 'string') return undefined;
  const match = /^(?:HTTP\s+)?(\d{3})(?:\s*:\s*|\s+|$)/i.exec(value);
  return match ? parseStatus(match[1]) : undefined;
}

function getStatus(error) {
  const structured = [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ];
  for (const value of structured) {
    const status = parseStatus(value);
    if (status !== undefined) return status;
  }
  return statusFromPrefix(error?.error)
    ?? statusFromPrefix(error?.error?.message)
    ?? statusFromPrefix(error?.message);
}

function getHeader(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    return value == null ? undefined : value;
  }
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function parseDecimal(value) {
  if (typeof value === 'number') return Number.isFinite(value) && value >= 0 ? value : undefined;
  if (typeof value !== 'string' || !/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(value.trim())) return undefined;
  const number = Number(value.trim());
  return Number.isFinite(number) ? number : undefined;
}

function getRetryAfterMs(error, nowMs) {
  const headers = error?.headers ?? error?.response?.headers;
  const milliseconds = parseDecimal(getHeader(headers, 'retry-after-ms'));
  if (milliseconds !== undefined) return milliseconds;

  const retryAfter = getHeader(headers, 'retry-after');
  const seconds = parseDecimal(retryAfter);
  if (seconds !== undefined) {
    const millisecondsFromSeconds = seconds * 1000;
    return Number.isFinite(millisecondsFromSeconds) ? millisecondsFromSeconds : undefined;
  }
  if (typeof retryAfter === 'string') {
    const date = Date.parse(retryAfter);
    const delay = date - nowMs;
    if (Number.isFinite(date) && Number.isFinite(delay)) return Math.max(0, delay);
  }
  return undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const status = getStatus(error);
  const codes = [error?.code, error?.error?.code];
  const isQuota = status === 402 || codes.some((code) => QUOTA_CODES.has(code));

  let kind = 'unknown';
  let retryable = false;
  if (isQuota) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if (status === 400 || status === 404 || status === 413 || status === 422) {
    kind = 'invalid_request';
  } else if (['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN'].includes(error?.code)) {
    kind = 'transient';
    retryable = true;
  }

  const retryAfterMs = getRetryAfterMs(error, nowMs);
  if (retryable && retryAfterMs !== undefined && retryAfterMs > 60000) retryable = false;
  return retryAfterMs === undefined
    ? {kind, retryable}
    : {kind, retryable, retryAfterMs};
}
