import fs from 'node:fs';
import readline from 'node:readline';
import { summarizeEvents } from './summary.mjs';

async function* readInputs(paths) {
  for (const path of paths) {
    const input = path === '-' ? process.stdin : fs.createReadStream(path, { encoding: 'utf8' });
    const lines = readline.createInterface({ input, crlfDelay: Infinity });
    try {
      for await (const line of lines) yield line;
    } finally {
      lines.close();
      if (path !== '-') input.destroy();
    }
  }
}

async function main() {
  const paths = process.argv.slice(2);
  if (paths.length === 0) throw new TypeError('At least one input file is required');
  if (paths.filter(path => path === '-').length > 1) {
    throw new TypeError("Standard input ('-') may be specified only once");
  }

  const report = await summarizeEvents(readInputs(paths));
  process.stdout.write(`${JSON.stringify(report)}\n`);
  if (report.invalidLines > 0) process.exitCode = 2;
}

main().catch(error => {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(`Error: ${message}\n`);
  process.exitCode = 1;
});
