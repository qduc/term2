export async function summarizeEvents(lines) {
  const winners = new Map();
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line === 'string' && line.trim() === '') continue;

    let event;
    try {
      if (typeof line !== 'string') throw new TypeError('JSONL line must be a string');
      event = JSON.parse(line);
    } catch {
      invalidLines++;
      continue;
    }

    if (
      event === null ||
      typeof event !== 'object' ||
      Array.isArray(event) ||
      typeof event.id !== 'string' ||
      event.id.trim() === '' ||
      typeof event.account !== 'string' ||
      event.account.trim() === '' ||
      !Number.isSafeInteger(event.amountCents) ||
      !Number.isInteger(event.revision) ||
      event.revision < 0
    ) {
      invalidLines++;
      continue;
    }

    const previous = winners.get(event.id);
    if (previous !== undefined) {
      duplicateEvents++;
      if (event.revision >= previous.revision) winners.set(event.id, event);
    } else {
      winners.set(event.id, event);
    }
  }

  const totals = new Map();
  for (const event of winners.values()) {
    let total = totals.get(event.account);
    if (total === undefined) total = { account: event.account, netCents: 0n, count: 0 };
    total.netCents += BigInt(event.amountCents);
    total.count++;
    totals.set(event.account, total);
  }

  const accounts = [...totals.values()].map(({ account, netCents, count }) => {
    if (netCents < BigInt(Number.MIN_SAFE_INTEGER) || netCents > BigInt(Number.MAX_SAFE_INTEGER)) {
      throw new RangeError('Aggregate netCents is outside the safe-integer range');
    }
    return { account, netCents: Number(netCents), count };
  });
  accounts.sort((left, right) => left.account < right.account ? -1 : left.account > right.account ? 1 : 0);

  return { accounts, invalidLines, duplicateEvents };
}
