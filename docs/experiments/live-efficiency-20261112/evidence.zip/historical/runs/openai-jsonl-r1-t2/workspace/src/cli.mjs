import fs from 'node:fs';
import readline from 'node:readline';
import { summarizeEvents } from './summary.mjs';

async function* readLines(path) {
  const input = path === '-' ? process.stdin : fs.createReadStream(path);
  const reader = readline.createInterface({ input, crlfDelay: Infinity });
  let inputError;
  const rememberError = (error) => { inputError = error; };
  input.on('error', rememberError);

  try {
    for await (const line of reader) yield line;
    if (inputError) throw inputError;
  } finally {
    reader.close();
    input.removeListener('error', rememberError);
  }
}

async function* readArguments(paths) {
  for (const path of paths) {
    yield* readLines(path);
  }
}

async function main() {
  const paths = process.argv.slice(2);
  if (paths.length === 0 || paths.some((path) => path === '') || paths.filter((path) => path === '-').length > 1) {
    throw new Error('provide one or more file paths; stdin may be specified once with -');
  }

  const report = await summarizeEvents(readArguments(paths));
  process.stdout.write(`${JSON.stringify(report)}\n`);
  if (report.invalidLines > 0) process.exitCode = 2;
}

main().catch((error) => {
  process.stderr.write(`Error: ${error.message}\n`);
  process.exitCode = 1;
});
