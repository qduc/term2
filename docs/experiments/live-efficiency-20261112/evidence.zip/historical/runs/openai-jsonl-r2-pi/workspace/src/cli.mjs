import { createReadStream } from 'node:fs';
import { createInterface } from 'node:readline';
import { summarizeEvents } from './summary.mjs';

async function* readLines(paths) {
  for (const path of paths) {
    const input = path === '-' ? process.stdin : createReadStream(path);
    const reader = createInterface({ input, crlfDelay: Infinity });
    try {
      for await (const line of reader) {
        yield line;
      }
    } finally {
      reader.close();
      if (path !== '-') input.destroy();
    }
  }
}

async function main() {
  const paths = process.argv.slice(2);
  if (paths.length === 0) {
    throw new Error('usage: node src/cli.mjs file1.jsonl [file2.jsonl ...]');
  }
  if (paths.filter((path) => path === '-').length > 1) {
    throw new Error("'-' may be specified at most once");
  }

  const report = await summarizeEvents(readLines(paths));
  process.stdout.write(`${JSON.stringify(report)}\n`);
  if (report.invalidLines > 0) process.exitCode = 2;
}

try {
  await main();
} catch (error) {
  process.stderr.write(`${error?.message ?? String(error)}\n`);
  process.exitCode = 1;
}
