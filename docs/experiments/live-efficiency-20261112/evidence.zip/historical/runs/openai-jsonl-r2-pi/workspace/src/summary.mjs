export async function summarizeEvents(lines) {
  const winners = new Map();
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line === 'string' && line.trim() === '') continue;

    let event;
    try {
      if (typeof line !== 'string') throw new TypeError('line must be a string');
      event = JSON.parse(line);
    } catch {
      invalidLines++;
      continue;
    }

    if (
      event === null ||
      typeof event !== 'object' ||
      Array.isArray(event) ||
      typeof event.id !== 'string' ||
      event.id.trim() === '' ||
      typeof event.account !== 'string' ||
      event.account.trim() === '' ||
      !Number.isSafeInteger(event.amountCents) ||
      !Number.isInteger(event.revision) ||
      event.revision < 0
    ) {
      invalidLines++;
      continue;
    }

    const previous = winners.get(event.id);
    if (previous !== undefined) duplicateEvents++;
    if (previous === undefined || event.revision >= previous.revision) {
      winners.set(event.id, {
        id: event.id,
        account: event.account,
        amountCents: event.amountCents,
        revision: event.revision,
      });
    }
  }

  const accountTotals = new Map();
  for (const event of winners.values()) {
    const total = accountTotals.get(event.account) ?? {
      account: event.account,
      netCents: 0n,
      count: 0,
    };
    total.netCents += BigInt(event.amountCents);
    total.count++;
    accountTotals.set(event.account, total);
  }

  const maxSafe = BigInt(Number.MAX_SAFE_INTEGER);
  const accounts = [...accountTotals.values()].map((total) => {
    if (total.netCents > maxSafe || total.netCents < -maxSafe) {
      throw new RangeError('aggregate netCents exceeds the safe integer range');
    }
    return { ...total, netCents: Number(total.netCents) };
  });
  accounts.sort((a, b) => (a.account < b.account ? -1 : a.account > b.account ? 1 : 0));
  return { accounts, invalidLines, duplicateEvents };
}
