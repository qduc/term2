import { createReadStream } from 'node:fs';
import { createInterface } from 'node:readline';
import { summarizeEvents } from './summary.mjs';

const files = process.argv.slice(2);

async function* readLines(file) {
  const input = file === '-' ? process.stdin : createReadStream(file, { encoding: 'utf8' });
  const reader = createInterface({ input, crlfDelay: Infinity });
  try {
    for await (const line of reader) yield line;
  } finally {
    reader.close();
    if (file !== '-' && !input.destroyed) input.destroy();
  }
}

async function* readAllFiles() {
  for (const file of files) {
    yield* readLines(file);
  }
}

try {
  if (files.length === 0) throw new Error('At least one input file is required');
  if (files.filter((file) => file === '-').length > 1) {
    throw new Error("Standard input ('-') may be specified only once");
  }

  const report = await summarizeEvents(readAllFiles());
  process.stdout.write(`${JSON.stringify(report)}\n`);
  if (report.invalidLines > 0) process.exitCode = 2;
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
}
