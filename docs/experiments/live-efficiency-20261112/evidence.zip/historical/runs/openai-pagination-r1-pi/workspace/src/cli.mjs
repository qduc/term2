import fs from 'node:fs';
import { collectPages } from './pages.mjs';

try {
  const file = process.argv[2];
  if (file === undefined) throw new TypeError('Usage: node src/cli.mjs pages.json');

  const pages = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!Array.isArray(pages)) throw new TypeError('pages.json must contain an array');

  const items = await collectPages(async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    return pages.find((page) => page !== null && typeof page === 'object' && page.cursor === key);
  });
  console.log(JSON.stringify(items));
} catch (error) {
  console.error(error?.message ?? String(error));
  process.exitCode = 1;
}
