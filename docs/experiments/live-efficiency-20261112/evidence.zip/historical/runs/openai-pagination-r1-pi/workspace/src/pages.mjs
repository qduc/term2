export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }
  if (options === null || typeof options !== 'object') {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  if (cursor !== undefined && cursor !== null &&
      !(typeof cursor === 'string' || (typeof cursor === 'number' && Number.isFinite(cursor)))) {
    throw new TypeError('cursor must be a string or finite number');
  }

  const signal = options.signal;
  const collected = [];
  const fetchedCursors = new Set();
  let pageCount = 0;

  const throwIfAborted = () => {
    if (signal?.aborted) {
      if (signal.reason !== undefined) throw signal.reason;
      const error = new Error('The operation was aborted');
      error.name = 'AbortError';
      throw error;
    }
  };

  while (true) {
    throwIfAborted();
    if (pageCount >= maxPages) {
      throw new RangeError(`Pagination exceeded maxPages (${maxPages})`);
    }
    if (cursor !== undefined && cursor !== null) {
      if (fetchedCursors.has(cursor)) {
        throw new Error('Repeated pagination cursor');
      }
      fetchedCursors.add(cursor);
    }

    const page = await fetchPage({ cursor, signal });
    throwIfAborted();
    pageCount += 1;

    if (page === null || typeof page !== 'object' || Array.isArray(page)) {
      throw new TypeError('fetchPage must return a page object');
    }
    if (!Array.isArray(page.items)) {
      throw new TypeError('page.items must be an array');
    }
    const nextCursor = page.nextCursor;
    if (nextCursor !== undefined && nextCursor !== null &&
        !(typeof nextCursor === 'string' || (typeof nextCursor === 'number' && Number.isFinite(nextCursor)))) {
      throw new TypeError('page.nextCursor must be a string or finite number');
    }

    for (const item of page.items) collected.push(item);
    if (nextCursor === undefined || nextCursor === null) return collected;
    cursor = nextCursor;
  }
}
