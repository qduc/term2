export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }
  if (options === null || typeof options !== 'object') {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  const signal = options.signal;
  let cursor = options.cursor;
  if (cursor === null) cursor = undefined;
  const items = [];
  const seenCursors = new Set();
  let pagesFetched = 0;

  const checkAborted = () => {
    if (signal?.aborted) {
      if (signal.reason !== undefined) throw signal.reason;
      throw new DOMException('The operation was aborted', 'AbortError');
    }
  };
  const validateCursor = value => {
    if (value !== null && value !== undefined &&
        typeof value !== 'string' &&
        !(typeof value === 'number' && Number.isFinite(value))) {
      throw new TypeError('cursor must be a string or finite number');
    }
  };

  validateCursor(cursor);
  while (true) {
    checkAborted();
    if (pagesFetched >= maxPages) {
      throw new RangeError('maxPages exceeded');
    }
    if (seenCursors.has(cursor)) {
      throw new Error('repeated cursor');
    }
    seenCursors.add(cursor);

    const page = await fetchPage({ cursor, signal });
    checkAborted();
    pagesFetched += 1;
    if (page === null || typeof page !== 'object' || Array.isArray(page) || !Array.isArray(page.items)) {
      throw new TypeError('page must be an object with an items array');
    }
    validateCursor(page.nextCursor);
    for (const item of page.items) items.push(item);
    if (page.nextCursor === null || page.nextCursor === undefined) break;
    cursor = page.nextCursor;
  }
  return items;
}
