import fs from 'node:fs';
import { collectPages } from './pages.mjs';

try {
  const pages = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  if (!Array.isArray(pages)) throw new TypeError('Input must be an array of pages');

  const items = await collectPages(async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    return pages.find((page) => page !== null && typeof page === 'object' && page.cursor === key);
  });
  console.log(JSON.stringify(items));
} catch (error) {
  console.error(error?.message ?? String(error));
  process.exitCode = 1;
}
