function throwIfAborted(signal) {
  if (!signal?.aborted) return;
  if (signal.reason !== undefined) throw signal.reason;
  const error = new Error('The operation was aborted');
  error.name = 'AbortError';
  throw error;
}

function isCursor(value) {
  return typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));
}

function validateCursor(cursor) {
  if (cursor !== null && cursor !== undefined && !isCursor(cursor)) {
    throw new TypeError('Cursor must be a string, a finite number, null, or undefined');
  }
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object') throw new TypeError('options must be an object');

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  validateCursor(cursor);
  const signal = options.signal;
  const seen = new Set();
  if (cursor !== null && cursor !== undefined) seen.add(cursor);

  const items = [];
  let pagesFetched = 0;
  while (true) {
    throwIfAborted(signal);
    const page = await fetchPage({ cursor, signal });
    throwIfAborted(signal);

    if (page === null || typeof page !== 'object' || !Array.isArray(page.items)) {
      throw new TypeError('fetchPage must return a page with an items array');
    }
    const nextCursor = page.nextCursor;
    validateCursor(nextCursor);
    for (const item of page.items) items.push(item);
    pagesFetched++;

    if (nextCursor === null || nextCursor === undefined) break;
    if (seen.has(nextCursor)) throw new Error('Repeated pagination cursor');
    if (pagesFetched >= maxPages) throw new RangeError('maxPages limit exceeded');

    seen.add(nextCursor);
    cursor = nextCursor;
  }

  return items;
}
