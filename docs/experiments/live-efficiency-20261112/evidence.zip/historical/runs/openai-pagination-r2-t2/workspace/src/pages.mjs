function validCursor(cursor) {
  return typeof cursor === 'string' || (typeof cursor === 'number' && Number.isFinite(cursor));
}

function throwIfAborted(signal) {
  if (signal?.aborted) {
    if (signal.reason !== undefined) throw signal.reason;
    const error = new Error('The operation was aborted');
    error.name = 'AbortError';
    throw error;
  }
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object') throw new TypeError('options must be an object');

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  if (cursor === null || cursor === undefined) cursor = undefined;
  else if (!validCursor(cursor)) throw new TypeError('cursor must be a string or finite number');

  const signal = options.signal;
  const visited = new Set();
  const items = [];
  let pageCount = 0;

  while (true) {
    throwIfAborted(signal);
    if (cursor !== undefined) {
      if (visited.has(cursor)) throw new Error('Repeated cursor');
      visited.add(cursor);
    }
    if (pageCount >= maxPages) throw new RangeError('Maximum page count exceeded');

    const page = await fetchPage({ cursor, signal });
    throwIfAborted(signal);
    if (page === null || typeof page !== 'object' || Array.isArray(page)) {
      throw new TypeError('Page must be an object');
    }
    if (!Array.isArray(page.items)) throw new TypeError('Page items must be an array');
    const nextCursor = page.nextCursor;
    if (nextCursor !== null && nextCursor !== undefined && !validCursor(nextCursor)) {
      throw new TypeError('nextCursor must be a string, finite number, null, or undefined');
    }

    items.push(...page.items);
    pageCount += 1;
    if (nextCursor === null || nextCursor === undefined) return items;
    cursor = nextCursor;
  }
}
