import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { AnthropicShellSandboxRunner } from '../src/tools/shell/sandbox/shell-sandbox-runner.js';
import { createSandboxRuntimeConfig } from '../src/tools/shell/sandbox/sandbox-policy.js';
import { createSandboxEnvironment } from '../src/tools/shell/sandbox/sandbox-env.js';
import { SandboxManager } from '@anthropic-ai/sandbox-runtime';
const cwd='/workspace/scratch/term2-pi-workspaces/fixture-openai-t2';
const runner=new AnthropicShellSandboxRunner();
const availability=await runner.availability();
console.log(JSON.stringify({availability}));
if(availability.type!=='available')throw new Error('Product sandbox is unavailable');
try {
  const wrapped=await runner.wrap('node --version',{cwd,config:createSandboxRuntimeConfig({cwd})});
  const result=await promisify(execFile)('bash',['-c',wrapped.command],{cwd,env:createSandboxEnvironment(process.env),timeout:10000});
  if(result.stdout.trim()!==process.version)throw new Error('Unexpected sandbox result');
  console.log(JSON.stringify({sandboxEnabled:true,nodeVersion:result.stdout.trim(),exitCode:0}));
} finally { await SandboxManager.reset(); }
