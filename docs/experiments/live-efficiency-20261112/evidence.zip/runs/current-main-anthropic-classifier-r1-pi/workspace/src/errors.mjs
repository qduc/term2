const QUOTA_CODES = new Set(['insufficient_quota', 'billing_hard_limit_reached', 'billing_not_active']);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);
const MAX_RETRY_MS = 60000;
const DECIMAL = /^\d+(?:\.\d+)?$/;

function isObject(value) {
  return (typeof value === 'object' && value !== null) || typeof value === 'function';
}

function parseStatus(value) {
  if (typeof value === 'number') {
    return Number.isInteger(value) && value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^\d+$/.test(value)) {
    const n = Number(value);
    return n >= 100 && n <= 599 ? n : undefined;
  }
  return undefined;
}

function structuredStatus(error) {
  const response = isObject(error.response) ? error.response : undefined;
  const nested = isObject(error.error) ? error.error : undefined;
  const candidates = [
    error.status,
    response?.status,
    nested?.status,
    error.statusCode,
    error.code,
  ];
  for (const candidate of candidates) {
    const status = parseStatus(candidate);
    if (status !== undefined) return status;
  }
  return undefined;
}

function prefixStatus(error) {
  const texts = [
    typeof error === 'string' ? error : undefined,
    isObject(error) ? error.message : undefined,
    isObject(error) ? error.error : undefined,
  ];
  for (const text of texts) {
    if (typeof text !== 'string') continue;
    const match = /^\s*(?:HTTP\s+)?(\d{3})(?=:|\s|$)/i.exec(text);
    if (match) {
      const status = parseStatus(match[1]);
      if (status !== undefined) return status;
    }
  }
  return undefined;
}

function httpStatus(error) {
  return structuredStatus(error) ?? prefixStatus(error);
}

function hasQuotaCode(error) {
  if (!isObject(error)) return false;
  if (typeof error.code === 'string' && QUOTA_CODES.has(error.code)) return true;
  const nested = isObject(error.error) ? error.error : undefined;
  return typeof nested?.code === 'string' && QUOTA_CODES.has(nested.code);
}

function readHeader(source, name) {
  if (!isObject(source)) return undefined;
  let raw;
  if (typeof source.get === 'function') {
    raw = source.get(name);
  } else {
    const key = Object.keys(source).find((k) => k.toLowerCase() === name);
    raw = key === undefined ? undefined : source[key];
  }
  if (Array.isArray(raw)) raw = raw[0];
  if (typeof raw === 'string') return raw.trim();
  if (typeof raw === 'number' && Number.isFinite(raw)) return String(raw);
  return undefined;
}

function headerValue(error, name) {
  const response = isObject(error.response) ? error.response : undefined;
  for (const source of [error.headers, response?.headers]) {
    const value = readHeader(source, name);
    if (value !== undefined) return value;
  }
  return undefined;
}

function retryAfterMsHint(error, nowMs) {
  const ms = headerValue(error, 'retry-after-ms');
  if (ms !== undefined && DECIMAL.test(ms)) {
    const n = Number(ms);
    if (Number.isFinite(n) && n >= 0) return n;
  }
  const after = headerValue(error, 'retry-after');
  if (after === undefined) return undefined;
  if (DECIMAL.test(after)) {
    const seconds = Number(after);
    return Number.isFinite(seconds) && seconds >= 0 ? seconds * 1000 : undefined;
  }
  if (/^[A-Za-z]/.test(after)) {
    const when = Date.parse(after);
    if (!Number.isFinite(when) || !Number.isFinite(nowMs)) return undefined;
    return Math.max(0, when - nowMs);
  }
  return undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const status = isObject(error) ? httpStatus(error) : prefixStatus(error);
  const code = isObject(error) ? error.code : undefined;

  let kind;
  let retryable;
  if (status === 402 || hasQuotaCode(error)) {
    kind = 'quota';
    retryable = false;
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
    retryable = false;
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if (status === 400 || status === 404 || status === 413 || status === 422) {
    kind = 'invalid_request';
    retryable = false;
  } else if (typeof code === 'string' && NETWORK_CODES.has(code)) {
    kind = 'transient';
    retryable = true;
  } else {
    kind = 'unknown';
    retryable = false;
  }

  const result = {kind, retryable};
  const delay = isObject(error) ? retryAfterMsHint(error, nowMs) : undefined;
  if (delay !== undefined) {
    result.retryAfterMs = delay;
    if (delay > MAX_RETRY_MS && (kind === 'rate_limit' || kind === 'transient')) {
      result.retryable = false;
    }
  }
  return result;
}
