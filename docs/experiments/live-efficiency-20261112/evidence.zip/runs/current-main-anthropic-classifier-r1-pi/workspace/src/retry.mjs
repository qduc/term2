import {classifyApiError} from './errors.mjs';

function abortError(signal) {
  const reason = signal.reason;
  if (reason !== undefined) return reason;
  const error = new Error('The operation was aborted');
  error.name = 'AbortError';
  return error;
}

function defaultSleep(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortError(signal));
      return;
    }
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortError(signal));
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener?.('abort', onAbort);
      resolve();
    }, ms);
    signal?.addEventListener?.('abort', onAbort, {once: true});
  });
}

export async function withRetry(operation, options = {}) {
  const {maxAttempts = 3, sleep = defaultSleep, now = Date.now, signal} = options;
  if (typeof operation !== 'function') throw new TypeError('operation must be a function');
  if (!Number.isInteger(maxAttempts) || maxAttempts < 1) {
    throw new TypeError('maxAttempts must be a positive integer');
  }

  if (signal?.aborted) throw abortError(signal);

  for (let attempt = 1; ; attempt++) {
    try {
      return await operation();
    } catch (error) {
      if (attempt >= maxAttempts) throw error;
      const classification = classifyApiError(error, {nowMs: now()});
      if (!classification.retryable) throw error;
      await sleep(classification.retryAfterMs ?? 0, signal);
      if (signal?.aborted) throw abortError(signal);
    }
  }
}
