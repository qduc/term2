const QUOTA_CODES = new Set(['insufficient_quota', 'billing_hard_limit_reached', 'billing_not_active']);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);
const MAX_RETRY_AFTER_MS = 60000;
const DECIMAL = /^(?:\d+\.?\d*|\.\d+)$/;

function toStatus(value) {
  if (typeof value === 'number') {
    return Number.isInteger(value) && value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^\d{3}$/.test(value.trim())) {
    const n = Number(value.trim());
    return n >= 100 && n <= 599 ? n : undefined;
  }
  return undefined;
}

function structuredStatus(error) {
  const candidates = [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ];
  for (const candidate of candidates) {
    const status = toStatus(candidate);
    if (status !== undefined) return status;
  }
  return undefined;
}

function prefixStatus(error) {
  const messages = [
    typeof error === 'string' ? error : undefined,
    typeof error?.error === 'string' ? error.error : undefined,
    typeof error?.message === 'string' ? error.message : undefined,
  ];
  for (const message of messages) {
    if (message === undefined) continue;
    const match = /^\s*(?:HTTP\s+)?([1-5]\d{2})(?=$|[\s:])/i.exec(message);
    const status = match ? toStatus(match[1]) : undefined;
    if (status !== undefined) return status;
  }
  return undefined;
}

function readHeader(headers, name) {
  if (headers == null || typeof headers !== 'object') return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    return value === null ? undefined : value;
  }
  const key = Object.keys(headers).find((k) => k.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function pickHeaders(error) {
  if (error?.headers != null && typeof error.headers === 'object') return error.headers;
  if (error?.response?.headers != null && typeof error.response.headers === 'object') {
    return error.response.headers;
  }
  return undefined;
}

function parseRetryAfterMs(headers, nowMs) {
  const ms = readHeader(headers, 'retry-after-ms');
  if (typeof ms === 'number' && Number.isFinite(ms) && ms >= 0) return ms;
  if (typeof ms === 'string' && DECIMAL.test(ms.trim())) return Number(ms.trim());

  const after = readHeader(headers, 'retry-after');
  if (typeof after === 'number' && Number.isFinite(after) && after >= 0) return after * 1000;
  if (typeof after !== 'string') return undefined;
  const text = after.trim();
  if (DECIMAL.test(text)) return Number(text) * 1000;
  if (!/[a-zA-Z]/.test(text)) return undefined;
  const dateMs = Date.parse(text);
  if (!Number.isFinite(dateMs)) return undefined;
  return Math.max(0, dateMs - nowMs);
}

function classify(error) {
  const quotaCode = QUOTA_CODES.has(error?.code) || QUOTA_CODES.has(error?.error?.code);
  const status = structuredStatus(error) ?? prefixStatus(error);

  if (status === 402 || quotaCode) return { kind: 'quota', retryable: false };
  if (status === 401 || status === 403) return { kind: 'authentication', retryable: false };
  if (status === 429) return { kind: 'rate_limit', retryable: true };
  if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    return { kind: 'transient', retryable: true };
  }
  if ([400, 404, 413, 422].includes(status)) return { kind: 'invalid_request', retryable: false };
  if (NETWORK_CODES.has(error?.code)) return { kind: 'transient', retryable: true };
  return { kind: 'unknown', retryable: false };
}

export function classifyApiError(error, { nowMs = Date.now() } = {}) {
  const result = classify(error);
  const retryAfterMs = parseRetryAfterMs(pickHeaders(error), nowMs);
  if (retryAfterMs !== undefined) {
    result.retryAfterMs = retryAfterMs;
    if (retryAfterMs > MAX_RETRY_AFTER_MS && (result.kind === 'rate_limit' || result.kind === 'transient')) {
      result.retryable = false;
    }
  }
  return result;
}
