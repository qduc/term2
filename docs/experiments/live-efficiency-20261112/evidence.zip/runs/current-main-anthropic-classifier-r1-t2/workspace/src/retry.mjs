import {classifyApiError} from './errors.mjs';

function abortReason(signal) {
  return signal.reason !== undefined ? signal.reason : new DOMException('This operation was aborted', 'AbortError');
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortReason(signal);
}

function defaultSleep(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortReason(signal));
      return;
    }
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortReason(signal));
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    signal?.addEventListener('abort', onAbort, {once: true});
  });
}

export async function withRetry(operation, {maxAttempts = 3, sleep = defaultSleep, now = Date.now, signal} = {}) {
  if (typeof operation !== 'function') throw new TypeError('operation must be a function');
  if (!Number.isInteger(maxAttempts) || maxAttempts <= 0) {
    throw new TypeError('maxAttempts must be a positive integer');
  }

  throwIfAborted(signal);
  for (let attempt = 1; ; attempt++) {
    try {
      return await operation();
    } catch (error) {
      const {retryable, retryAfterMs} = classifyApiError(error, {nowMs: now()});
      if (attempt >= maxAttempts || !retryable) throw error;
      await sleep(retryAfterMs ?? 0, signal);
      throwIfAborted(signal);
    }
  }
}
