const QUOTA_CODES = new Set(['insufficient_quota', 'billing_hard_limit_reached', 'billing_not_active']);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);
const MAX_RETRYABLE_DELAY_MS = 60000;
const PREFIX_STATUS = /^\s*(?:HTTP\s+)?([1-5]\d\d)(?=$|[\s:])/i;

function isObject(value) {
  return value !== null && (typeof value === 'object' || typeof value === 'function');
}

// Integers 100..599 or canonical numeric strings with the same range; anything else is ignored.
function parseStatus(value) {
  if (typeof value === 'number') {
    return Number.isInteger(value) && value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^[1-9]\d*$/.test(value)) {
    const n = Number(value);
    return n >= 100 && n <= 599 ? n : undefined;
  }
  return undefined;
}

function statusFromPrefix(error) {
  const texts = typeof error === 'string' ? [error] : [error?.message, error?.error];
  for (const text of texts) {
    if (typeof text !== 'string') continue;
    const match = PREFIX_STATUS.exec(text);
    if (match) return Number(match[1]);
  }
  return undefined;
}

function resolveStatus(error) {
  const response = isObject(error?.response) ? error.response : undefined;
  const nested = isObject(error?.error) ? error.error : undefined;
  const candidates = [error?.status, response?.status, nested?.status, error?.statusCode, error?.code];
  for (const candidate of candidates) {
    const status = parseStatus(candidate);
    if (status !== undefined) return status;
  }
  return statusFromPrefix(error);
}

function classifyByStatus(status) {
  if (status === 401 || status === 403) return {kind: 'authentication', retryable: false};
  if (status === 429) return {kind: 'rate_limit', retryable: true};
  if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    return {kind: 'transient', retryable: true};
  }
  if (status === 400 || status === 404 || status === 413 || status === 422) {
    return {kind: 'invalid_request', retryable: false};
  }
  return undefined;
}

function isQuota(error, status) {
  const nested = isObject(error?.error) ? error.error : undefined;
  return status === 402 || QUOTA_CODES.has(error?.code) || QUOTA_CODES.has(nested?.code);
}

function headerSource(error) {
  if (error?.headers != null) return error.headers;
  return error?.response?.headers;
}

function readHeader(headers, name) {
  if (!isObject(headers)) return undefined;
  let raw;
  if (typeof Headers === 'function' && headers instanceof Headers) {
    raw = headers.get(name) ?? undefined;
  } else {
    const key = Object.keys(headers).find((k) => k.toLowerCase() === name);
    raw = key === undefined ? undefined : headers[key];
  }
  if (Array.isArray(raw)) raw = raw[0];
  return typeof raw === 'string' || typeof raw === 'number' ? raw : undefined;
}

function parseRetryAfterMs(raw) {
  if (typeof raw === 'number') return Number.isFinite(raw) && raw >= 0 ? raw : undefined;
  if (typeof raw !== 'string') return undefined;
  return /^\d+(\.\d+)?$/.test(raw) ? Number(raw) : undefined;
}

function parseRetryAfter(raw, nowMs) {
  if (typeof raw === 'number') {
    return Number.isFinite(raw) && raw >= 0 ? Number((raw * 1000).toFixed(6)) : undefined;
  }
  if (typeof raw !== 'string') return undefined;
  const text = raw.trim();
  if (/^\d+(\.\d+)?$/.test(text)) return Number((Number(text) * 1000).toFixed(6));
  // Purely numeric-looking values are malformed seconds, not dates.
  if (/^[-+]?[\d.]+$/.test(text) || !Number.isFinite(nowMs)) return undefined;
  const at = Date.parse(text);
  return Number.isFinite(at) ? Math.max(0, at - nowMs) : undefined;
}

function retryAfterHint(error, nowMs) {
  const headers = headerSource(error);
  const ms = parseRetryAfterMs(readHeader(headers, 'retry-after-ms'));
  if (ms !== undefined) return ms;
  return parseRetryAfter(readHeader(headers, 'retry-after'), nowMs);
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  let result;
  const status = resolveStatus(error);
  if (isQuota(error, status)) {
    result = {kind: 'quota', retryable: false};
  } else {
    result = (status !== undefined && classifyByStatus(status))
      || (NETWORK_CODES.has(error?.code) ? {kind: 'transient', retryable: true } : undefined)
      || {kind: 'unknown', retryable: false};
  }

  const delayMs = retryAfterHint(error, nowMs);
  if (delayMs === undefined) return result;

  const retryable = result.retryable
    && !(delayMs > MAX_RETRYABLE_DELAY_MS && (result.kind === 'rate_limit' || result.kind === 'transient'));
  return {kind: result.kind, retryable, retryAfterMs: delayMs};
}
