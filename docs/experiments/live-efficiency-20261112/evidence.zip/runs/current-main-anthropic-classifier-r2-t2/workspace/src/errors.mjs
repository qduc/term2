const QUOTA_CODES = new Set(['insufficient_quota', 'billing_hard_limit_reached', 'billing_not_active']);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);
const MAX_RETRY_DELAY_MS = 60000;

function field(object, name) {
  return object !== null && (typeof object === 'object' || typeof object === 'function') ? object[name] : undefined;
}

// Integers or numeric strings in 100..599; anything else is not a status.
function parseStatus(value) {
  let n;
  if (typeof value === 'number') n = value;
  else if (typeof value === 'string' && /^\s*\d+\s*$/.test(value)) n = Number(value);
  else return undefined;
  return Number.isInteger(n) && n >= 100 && n <= 599 ? n : undefined;
}

function prefixStatus(error) {
  const texts = [
    typeof error === 'string' ? error : undefined,
    field(error, 'message'),
    field(error, 'error'),
  ];
  for (const text of texts) {
    if (typeof text !== 'string') continue;
    const match = /^\s*(?:HTTP\s+)?(\d{3})(?!\d)/i.exec(text);
    const status = match ? parseStatus(match[1]) : undefined;
    if (status !== undefined) return status;
  }
  return undefined;
}

function extractStatus(error) {
  const candidates = [
    field(error, 'status'),
    field(field(error, 'response'), 'status'),
    field(field(error, 'error'), 'status'),
    field(error, 'statusCode'),
    field(error, 'code'),
  ];
  for (const candidate of candidates) {
    const status = parseStatus(candidate);
    if (status !== undefined) return status;
  }
  return prefixStatus(error);
}

function headerFrom(headers, name) {
  if (headers === null || typeof headers !== 'object') return undefined;
  let value;
  if (typeof headers.get === 'function') {
    value = headers.get(name);
  } else {
    const key = Object.keys(headers).find((k) => k.toLowerCase() === name);
    value = key === undefined ? undefined : headers[key];
  }
  if (Array.isArray(value)) value = value[0];
  return value === null || value === undefined ? undefined : value;
}

function readHeader(error, name) {
  const sources = [field(error, 'headers'), field(field(error, 'response'), 'headers')];
  for (const source of sources) {
    const value = headerFrom(source, name);
    if (value !== undefined) return value;
  }
  return undefined;
}

const DECIMAL = /^(?:\d+(?:\.\d*)?|\.\d+)$/;

function parseDecimal(value) {
  if (typeof value === 'number') return Number.isFinite(value) && value >= 0 ? value : undefined;
  if (typeof value === 'string' && DECIMAL.test(value.trim())) return Number(value.trim());
  return undefined;
}

function parseRetryAfter(value, nowMs) {
  const seconds = parseDecimal(value);
  if (seconds !== undefined) return seconds * 1000;
  if (typeof value !== 'string') return undefined;
  const text = value.trim();
  if (/^[-+]?[\d.]/.test(text)) return undefined; // numeric-looking but not a valid non-negative number
  const at = Date.parse(text);
  if (!Number.isFinite(at) || !Number.isFinite(nowMs)) return undefined;
  return Math.max(0, at - nowMs);
}

function extractRetryAfterMs(error, nowMs) {
  const ms = parseDecimal(readHeader(error, 'retry-after-ms'));
  if (ms !== undefined) return ms;
  return parseRetryAfter(readHeader(error, 'retry-after'), nowMs);
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const status = extractStatus(error);
  const codes = [field(error, 'code'), field(field(error, 'error'), 'code')];

  let result;
  if (status === 402 || codes.some((code) => QUOTA_CODES.has(code))) {
    result = {kind: 'quota', retryable: false};
  } else if (status === 401 || status === 403) {
    result = {kind: 'authentication', retryable: false};
  } else if (status === 429) {
    result = {kind: 'rate_limit', retryable: true};
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    result = {kind: 'transient', retryable: true};
  } else if ([400, 404, 413, 422].includes(status)) {
    result = {kind: 'invalid_request', retryable: false};
  } else if (NETWORK_CODES.has(field(error, 'code'))) {
    result = {kind: 'transient', retryable: true};
  } else {
    result = {kind: 'unknown', retryable: false};
  }

  const retryAfterMs = extractRetryAfterMs(error, nowMs);
  if (retryAfterMs !== undefined) {
    result.retryAfterMs = retryAfterMs;
    if (retryAfterMs > MAX_RETRY_DELAY_MS && (result.kind === 'rate_limit' || result.kind === 'transient')) {
      result.retryable = false;
    }
  }
  return result;
}
