#!/usr/bin/env node
// CLI: node src/cli.mjs file1.jsonl [file2.jsonl ...]   ('-' = stdin, at most once)
// Prints one JSON report line on stdout.
// Exit 0: clean input. Exit 2: invalidLines > 0. Exit 1: usage, I/O or overflow error
// (diagnostic on stderr only, no report).
import fs from 'node:fs';
import { summarizeEvents } from './summary.mjs';

const USAGE = 'usage: node src/cli.mjs file1.jsonl [file2.jsonl ...]  (use - for stdin, at most once)';

function validateArgs(args) {
  if (args.length === 0) throw new UsageError('at least one argument is required');
  let stdinCount = 0;
  for (const arg of args) {
    if (arg === '-') {
      stdinCount++;
    } else if (arg === '' || arg.startsWith('-')) {
      throw new UsageError(`invalid argument: ${JSON.stringify(arg)}`);
    }
  }
  if (stdinCount > 1) throw new UsageError("'-' may appear at most once");
}

class UsageError extends Error {}

// Yields lines from each source in argument order, streaming chunk by chunk.
async function* linesOf(args) {
  for (const arg of args) {
    const stream = arg === '-' ? process.stdin : fs.createReadStream(arg, { encoding: 'utf8' });
    if (arg === '-') stream.setEncoding('utf8');
    let rest = '';
    for await (const chunk of stream) {
      const parts = chunk.split('\n');
      parts[0] = rest + parts[0];
      rest = parts.pop();
      for (const part of parts) yield part;
    }
    if (rest !== '') yield rest;
  }
}

async function main(args) {
  try {
    validateArgs(args);
  } catch (err) {
    process.stderr.write(`error: ${err.message}\n${USAGE}\n`);
    return 1;
  }
  let report;
  try {
    report = await summarizeEvents(linesOf(args));
  } catch (err) {
    process.stderr.write(`error: ${err instanceof RangeError ? 'overflow: ' : ''}${err.message}\n`);
    return 1;
  }
  process.stdout.write(`${JSON.stringify(report)}\n`);
  return report.invalidLines > 0 ? 2 : 0;
}

process.exitCode = await main(process.argv.slice(2));
