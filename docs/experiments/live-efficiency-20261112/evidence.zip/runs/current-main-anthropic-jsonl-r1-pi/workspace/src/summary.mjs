// Streaming JSONL event summary.
//
// Each nonblank line must be a JSON non-array object with:
//   id, account      – nonempty strings (whitespace-only is invalid; value kept as-is)
//   amountCents      – safe integer (negative/zero allowed)
//   revision         – nonnegative safe integer
// Unknown fields are ignored. Invalid lines are counted in invalidLines.
// Per id, the winning event is the highest revision; on a tie the last valid
// line wins. Every valid line whose id was already seen counts as a duplicate.
// Only winning events are aggregated per account. Sums are computed exactly
// (BigInt) and a RangeError is thrown if an account total is not a safe integer.

const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const isNonBlankString = (v) => typeof v === 'string' && v.trim() !== '';

function parseEvent(line) {
  if (typeof line !== 'string') return undefined;
  let value;
  try {
    value = JSON.parse(line);
  } catch {
    return undefined; // invalid JSON
  }
  if (!isPlainObject(value)) return undefined;
  if (!isNonBlankString(value.id) || !isNonBlankString(value.account)) return undefined;
  if (!Number.isSafeInteger(value.amountCents)) return undefined;
  if (!Number.isSafeInteger(value.revision) || value.revision < 0) return undefined;
  return { id: value.id, account: value.account, amountCents: value.amountCents, revision: value.revision };
}

export async function summarizeEvents(lines) {
  const winners = new Map(); // id -> winning event
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line === 'string' && line.trim() === '') continue;
    const event = parseEvent(line);
    if (event === undefined) {
      invalidLines++;
      continue;
    }
    const current = winners.get(event.id);
    if (current === undefined) {
      winners.set(event.id, event);
      continue;
    }
    duplicateEvents++;
    if (event.revision >= current.revision) winners.set(event.id, event);
  }

  const totals = new Map(); // account -> { sum: BigInt, count: number }
  for (const event of winners.values()) {
    const t = totals.get(event.account) ?? { sum: 0n, count: 0 };
    t.sum += BigInt(event.amountCents);
    t.count++;
    totals.set(event.account, t);
  }

  const accounts = [];
  for (const [account, t] of totals) {
    if (t.sum > BigInt(Number.MAX_SAFE_INTEGER) || t.sum < BigInt(Number.MIN_SAFE_INTEGER)) {
      throw new RangeError(`aggregate netCents for account ${JSON.stringify(account)} is not a safe integer`);
    }
    accounts.push({ account, netCents: Number(t.sum), count: t.count });
  }
  accounts.sort((a, b) => (a.account < b.account ? -1 : a.account > b.account ? 1 : 0));

  return { accounts, invalidLines, duplicateEvents };
}
