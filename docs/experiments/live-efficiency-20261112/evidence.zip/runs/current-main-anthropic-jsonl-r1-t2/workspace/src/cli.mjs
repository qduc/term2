import fs from 'node:fs';
import {summarizeEvents} from './summary.mjs';

// Yields the lines of a readable stream, streaming chunk by chunk.
async function* linesOf(stream) {
  let pending = '';
  for await (const chunk of stream) {
    pending += chunk;
    let start = 0;
    let idx;
    while ((idx = pending.indexOf('\n', start)) !== -1) {
      yield pending.slice(start, idx);
      start = idx + 1;
    }
    pending = pending.slice(start);
  }
  if (pending.length > 0) yield pending;
}

// Yields lines from each source in argument order, opening each lazily.
async function* allLines(sources) {
  for (const src of sources) {
    const stream = src === '-' ? process.stdin : fs.createReadStream(src, {encoding: 'utf8'});
    try {
      yield* linesOf(stream);
    } finally {
      if (stream !== process.stdin) stream.destroy();
    }
  }
}

async function main(argv) {
  if (argv.length === 0) {
    process.stderr.write('usage: node src/cli.mjs <file.jsonl|-> [...]\n');
    return 1;
  }
  if (argv.filter((a) => a === '-').length > 1) {
    process.stderr.write('error: "-" (stdin) may appear at most once\n');
    return 1;
  }
  const report = await summarizeEvents(allLines(argv));
  process.stdout.write(JSON.stringify(report) + '\n');
  return report.invalidLines > 0 ? 2 : 0;
}

try {
  process.exitCode = await main(process.argv.slice(2));
} catch (err) {
  process.stderr.write(`error: ${err && err.message ? err.message : String(err)}\n`);
  process.exitCode = 1;
}
