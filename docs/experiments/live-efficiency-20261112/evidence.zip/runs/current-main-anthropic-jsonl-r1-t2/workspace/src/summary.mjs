const isNonBlankString = (v) => typeof v === 'string' && v.trim() !== '';

// Parses one line into a valid event, or returns null when it is invalid.
function parseEvent(line) {
  if (typeof line !== 'string') return null;
  let e;
  try {
    e = JSON.parse(line);
  } catch {
    return null;
  }
  if (e === null || typeof e !== 'object' || Array.isArray(e)) return null;
  if (!isNonBlankString(e.id) || !isNonBlankString(e.account)) return null;
  if (!Number.isSafeInteger(e.amountCents)) return null;
  if (!Number.isSafeInteger(e.revision) || e.revision < 0) return null;
  return { id: e.id, account: e.account, amountCents: e.amountCents, revision: e.revision };
}

export async function summarizeEvents(lines) {
  const winners = new Map(); // id -> winning event
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line === 'string' && line.trim() === '') continue;
    const ev = parseEvent(line);
    if (ev === null) {
      invalidLines++;
      continue;
    }
    const current = winners.get(ev.id);
    if (current === undefined) {
      winners.set(ev.id, ev);
      continue;
    }
    duplicateEvents++;
    // Highest revision wins; on ties the later valid line wins.
    if (ev.revision >= current.revision) winners.set(ev.id, ev);
  }

  // Aggregate with BigInt so the check applies to the final sum, not partial sums.
  const totals = new Map(); // account -> {sum: bigint, count: number}
  for (const ev of winners.values()) {
    let t = totals.get(ev.account);
    if (t === undefined) {
      t = { sum: 0n, count: 0 };
      totals.set(ev.account, t);
    }
    t.sum += BigInt(ev.amountCents);
    t.count++;
  }

  const accounts = [];
  for (const [account, t] of totals) {
    if (t.sum > BigInt(Number.MAX_SAFE_INTEGER) || t.sum < BigInt(Number.MIN_SAFE_INTEGER)) {
      throw new RangeError(`aggregate netCents for account is outside the safe integer range`);
    }
    accounts.push({ account, netCents: Number(t.sum), count: t.count });
  }
  accounts.sort((a, b) => (a.account < b.account ? -1 : a.account > b.account ? 1 : 0));

  return { accounts, invalidLines, duplicateEvents };
}
