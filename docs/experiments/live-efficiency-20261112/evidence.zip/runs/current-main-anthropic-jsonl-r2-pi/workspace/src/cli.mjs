#!/usr/bin/env node
// CLI: node src/cli.mjs file1.jsonl [file2.jsonl ...]   ('-' = stdin, at most once)
// Streams each input in argument order. Exit 0 clean, 2 if invalidLines>0, 1 on error.
import fs from 'node:fs';
import process from 'node:process';
import {summarizeEvents} from './summary.mjs';

const USAGE = 'usage: node src/cli.mjs <file.jsonl|-> [more...]  (\'-\' may appear at most once)';

// Yields the lines of one stream (chunks decoded as UTF-8, split on LF, trailing CR stripped).
async function* linesOf(stream) {
  const decoder = new TextDecoder('utf-8');
  let pending = '';
  for await (const chunk of stream) {
    pending += typeof chunk === 'string' ? chunk : decoder.decode(chunk, {stream: true});
    let idx;
    while ((idx = pending.indexOf('\n')) !== -1) {
      let line = pending.slice(0, idx);
      pending = pending.slice(idx + 1);
      if (line.endsWith('\r')) line = line.slice(0, -1);
      yield line;
    }
  }
  pending += decoder.decode();
  if (pending !== '') {
    yield pending.endsWith('\r') ? pending.slice(0, -1) : pending;
  }
}

// Yields lines across all inputs in argument order, streaming each file.
async function* allLines(args) {
  for (const arg of args) {
    if (arg === '-') {
      yield* linesOf(process.stdin);
    } else {
      const stream = fs.createReadStream(arg);
      try {
        yield* linesOf(stream);
      } finally {
        stream.destroy();
      }
    }
  }
}

async function main(args) {
  if (args.length === 0) {
    process.stderr.write(`${USAGE}\n`);
    return 1;
  }
  if (args.filter((a) => a === '-').length > 1) {
    process.stderr.write(`error: '-' may appear at most once\n${USAGE}\n`);
    return 1;
  }

  let report;
  try {
    report = await summarizeEvents(allLines(args));
  } catch (err) {
    process.stderr.write(`error: ${err && err.message ? err.message : String(err)}\n`);
    return 1;
  }

  process.stdout.write(`${JSON.stringify(report)}\n`);
  return report.invalidLines > 0 ? 2 : 0;
}

process.exitCode = await main(process.argv.slice(2));
