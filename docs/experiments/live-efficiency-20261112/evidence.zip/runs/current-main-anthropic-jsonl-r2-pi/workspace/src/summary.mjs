// Streaming JSONL event summary.
// Accepts Iterable<string> or AsyncIterable<string>; only winning events are retained.

function isValidId(value) {
  return typeof value === 'string' && value.trim() !== '';
}

function isNonNegativeSafeInteger(value) {
  return Number.isSafeInteger(value) && value >= 0;
}

// Returns the parsed event or null if the line is invalid.
function parseEvent(line) {
  if (typeof line !== 'string' || line.trim() === '') return undefined; // blank: ignored
  let parsed;
  try {
    parsed = JSON.parse(line);
  } catch {
    return null;
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
  if (!isValidId(parsed.id)) return null;
  if (!isValidId(parsed.account)) return null;
  if (!Number.isSafeInteger(parsed.amountCents)) return null;
  if (!isNonNegativeSafeInteger(parsed.revision)) return null;
  return {
    id: parsed.id,
    account: parsed.account,
    amountCents: parsed.amountCents,
    revision: parsed.revision,
  };
}

function compareCodeUnits(a, b) {
  return a < b ? -1 : a > b ? 1 : 0;
}

export async function summarizeEvents(lines) {
  // id -> winning event. Later lines win ties on revision.
  const winners = new Map();
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    const event = parseEvent(line);
    if (event === undefined) continue;
    if (event === null) {
      invalidLines++;
      continue;
    }
    const current = winners.get(event.id);
    if (current === undefined) {
      winners.set(event.id, event);
      continue;
    }
    duplicateEvents++;
    if (event.revision >= current.revision) {
      winners.set(event.id, event);
    }
  }

  const byAccount = new Map();
  for (const event of winners.values()) {
    let agg = byAccount.get(event.account);
    if (agg === undefined) {
      agg = { account: event.account, netCents: 0, count: 0 };
      byAccount.set(event.account, agg);
    }
    const next = agg.netCents + event.amountCents;
    if (!Number.isSafeInteger(next)) {
      throw new RangeError(`aggregate netCents for account is not a safe integer`);
    }
    agg.netCents = next;
    agg.count++;
  }

  const accounts = [...byAccount.values()].sort((x, y) => compareCodeUnits(x.account, y.account));
  return { accounts, invalidLines, duplicateEvents };
}
