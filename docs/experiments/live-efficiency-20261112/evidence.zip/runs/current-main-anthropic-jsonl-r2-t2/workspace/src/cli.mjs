import fs from 'node:fs';
import { StringDecoder } from 'node:string_decoder';
import { summarizeEvents } from './summary.mjs';

// Streams a file/stream as lines without reading it whole.
async function* readLines(stream) {
  const decoder = new StringDecoder('utf8');
  let rest = '';
  for await (const chunk of stream) {
    rest += typeof chunk === 'string' ? chunk : decoder.write(chunk);
    let start = 0;
    let idx;
    while ((idx = rest.indexOf('\n', start)) !== -1) {
      yield rest.slice(start, idx);
      start = idx + 1;
    }
    rest = rest.slice(start);
  }
  rest += decoder.end();
  if (rest !== '') yield rest;
}

async function* allLines(sources) {
  for (const source of sources) {
    if (source === '-') {
      yield* readLines(process.stdin);
    } else {
      const stream = fs.createReadStream(source);
      try {
        yield* readLines(stream);
      } finally {
        stream.destroy();
      }
    }
  }
}

function usageError(message) {
  process.stderr.write(`error: ${message}\n`);
  process.exitCode = 1;
}

async function main(args) {
  if (args.length === 0) {
    usageError('usage: node src/cli.mjs file1.jsonl [file2.jsonl ...] (use - for stdin)');
    return;
  }
  if (args.filter((a) => a === '-').length > 1) {
    usageError("'-' (stdin) may appear at most once");
    return;
  }
  let report;
  try {
    report = await summarizeEvents(allLines(args));
  } catch (err) {
    usageError(err && err.message ? err.message : String(err));
    return;
  }
  process.stdout.write(`${JSON.stringify(report)}\n`);
  process.exitCode = report.invalidLines > 0 ? 2 : 0;
}

await main(process.argv.slice(2));
