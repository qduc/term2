const isNonBlankString = (v) => typeof v === 'string' && v.trim() !== '';

// Returns a normalized event, or null when the line is not a valid event.
function parseEvent(line) {
  if (typeof line !== 'string') return null;
  let e;
  try {
    e = JSON.parse(line);
  } catch {
    return null;
  }
  if (e === null || typeof e !== 'object' || Array.isArray(e)) return null;
  const { id, account, amountCents, revision } = e;
  if (!isNonBlankString(id) || !isNonBlankString(account)) return null;
  if (!Number.isSafeInteger(amountCents)) return null;
  if (!Number.isSafeInteger(revision) || revision < 0) return null;
  return { id, account, amountCents, revision };
}

export async function summarizeEvents(lines) {
  const winners = new Map(); // id -> winning event
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line === 'string' && line.trim() === '') continue;
    const event = parseEvent(line);
    if (event === null) {
      invalidLines++;
      continue;
    }
    const previous = winners.get(event.id);
    if (previous === undefined) {
      winners.set(event.id, event);
    } else {
      duplicateEvents++;
      // Highest revision wins; on a tie the later valid line wins.
      if (event.revision >= previous.revision) winners.set(event.id, event);
    }
  }

  const totals = new Map(); // account -> { sum: BigInt, count }
  for (const event of winners.values()) {
    let t = totals.get(event.account);
    if (t === undefined) {
      t = { sum: 0n, count: 0 };
      totals.set(event.account, t);
    }
    t.sum += BigInt(event.amountCents);
    t.count++;
  }

  const accounts = [];
  for (const [account, t] of totals) {
    if (t.sum > BigInt(Number.MAX_SAFE_INTEGER) || t.sum < BigInt(Number.MIN_SAFE_INTEGER)) {
      throw new RangeError(`aggregate netCents for account ${JSON.stringify(account)} is not a safe integer`);
    }
    accounts.push({ account, netCents: Number(t.sum), count: t.count });
  }
  accounts.sort((a, b) => (a.account < b.account ? -1 : a.account > b.account ? 1 : 0));

  return { accounts, invalidLines, duplicateEvents };
}
