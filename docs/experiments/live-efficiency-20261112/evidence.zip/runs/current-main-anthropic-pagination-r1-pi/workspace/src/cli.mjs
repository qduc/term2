import fs from 'node:fs';
import { collectPages } from './pages.mjs';

function fail(message) {
  process.stderr.write(`error: ${message}\n`);
  process.exitCode = 1;
}

async function main(argv) {
  const file = argv[2];
  if (file === undefined) {
    fail('usage: node src/cli.mjs pages.json');
    return;
  }

  let pages;
  try {
    pages = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (err) {
    fail(`cannot read or parse ${file}: ${err && err.message}`);
    return;
  }
  if (!Array.isArray(pages)) {
    fail(`${file} must contain an array of pages`);
    return;
  }

  let items;
  try {
    items = await collectPages(async ({ cursor }) => {
      const key = cursor === undefined ? null : cursor;
      return pages.find((p) => p !== null && typeof p === 'object' && p.cursor === key);
    });
  } catch (err) {
    fail(`collection failed: ${err && err.message}`);
    return;
  }
  process.stdout.write(`${JSON.stringify(items)}\n`);
}

await main(process.argv);
