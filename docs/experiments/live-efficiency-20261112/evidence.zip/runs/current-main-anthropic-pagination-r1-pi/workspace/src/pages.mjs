const DEFAULT_MAX_PAGES = 100;

function isValidCursor(value) {
  return typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));
}

function assertNotAborted(signal) {
  if (signal === undefined || signal.aborted !== true) return;
  if (signal.reason !== undefined) throw signal.reason;
  const err = new Error('This operation was aborted');
  err.name = 'AbortError';
  throw err;
}

function validatePage(page) {
  if (page === null || typeof page !== 'object') {
    throw new TypeError('page must be an object');
  }
  if (!Array.isArray(page.items)) {
    throw new TypeError('page.items must be an array');
  }
  const next = page.nextCursor;
  if (next !== undefined && next !== null && !isValidCursor(next)) {
    throw new TypeError('page.nextCursor must be a string, finite number, null, or undefined');
  }
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }
  if (options === null || typeof options !== 'object') {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? DEFAULT_MAX_PAGES : options.maxPages;
  if (typeof maxPages !== 'number' || !Number.isInteger(maxPages)) {
    throw new TypeError('maxPages must be a positive integer');
  }
  if (maxPages < 1) {
    throw new RangeError('maxPages must be a positive integer');
  }

  const signal = options.signal;
  if (signal !== undefined && (signal === null || typeof signal !== 'object' || typeof signal.aborted !== 'boolean')) {
    throw new TypeError('signal must be an AbortSignal');
  }

  const startCursor = options.cursor;
  if (startCursor !== undefined && startCursor !== null && !isValidCursor(startCursor)) {
    throw new TypeError('options.cursor must be a string, finite number, null, or undefined');
  }

  let cursor = startCursor === null ? undefined : startCursor;
  // Set uses SameValueZero, so "0" and 0 stay distinct cursors.
  const seen = new Set();
  if (cursor !== undefined) seen.add(cursor);

  const items = [];
  let fetched = 0;

  for (;;) {
    assertNotAborted(signal);
    fetched += 1;
    const page = await fetchPage({ cursor, signal });
    assertNotAborted(signal);
    validatePage(page);

    const pageItems = page.items;
    for (let i = 0; i < pageItems.length; i += 1) {
      items.push(pageItems[i]);
    }

    const next = page.nextCursor;
    if (next === undefined || next === null) return items;

    if (fetched >= maxPages) {
      throw new RangeError(`collectPages would exceed maxPages (${maxPages})`);
    }
    if (seen.has(next)) {
      throw new Error('repeated cursor detected; refusing to fetch it again');
    }
    seen.add(next);
    cursor = next;
  }
}
