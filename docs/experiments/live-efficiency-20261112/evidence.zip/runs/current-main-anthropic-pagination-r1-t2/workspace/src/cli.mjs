import fs from 'node:fs';
import { collectPages } from './pages.mjs';

function fail(message) {
  process.stderr.write(`error: ${message}\n`);
  process.exitCode = 1;
}

async function main() {
  const file = process.argv[2];
  if (file === undefined) {
    fail('usage: node src/cli.mjs pages.json');
    return;
  }

  let pages;
  try {
    pages = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    fail(`cannot read ${file}: ${error.message}`);
    return;
  }
  if (!Array.isArray(pages)) {
    fail(`${file} must contain a JSON array of pages`);
    return;
  }

  // Pages are keyed by cursor; JSON null denotes the initial undefined cursor.
  const fetchPage = async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    const page = pages.find((p) => p !== null && typeof p === 'object' && p.cursor === key);
    if (page === undefined) {
      throw new Error(`no page for cursor ${JSON.stringify(key)}`);
    }
    return page;
  };

  let items;
  try {
    items = await collectPages(fetchPage);
  } catch (error) {
    fail(error && error.message ? error.message : String(error));
    return;
  }
  process.stdout.write(`${JSON.stringify(items)}\n`);
}

await main();
