const DEFAULT_MAX_PAGES = 100;

function isCursor(value) {
  return typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));
}

// Distinguishes number cursors from string cursors (e.g. 1 vs '1').
function cursorKey(cursor) {
  return `${typeof cursor}:${String(cursor)}`;
}

function abortError() {
  if (typeof DOMException === 'function') {
    return new DOMException('This operation was aborted', 'AbortError');
  }
  const error = new Error('This operation was aborted');
  error.name = 'AbortError';
  return error;
}

function throwIfAborted(signal) {
  if (signal !== undefined && signal.aborted) {
    // A present reason (including null) is propagated as-is.
    throw signal.reason !== undefined ? signal.reason : abortError();
  }
}

function validatePage(page) {
  if (page === null || typeof page !== 'object' || Array.isArray(page)) {
    throw new TypeError('page must be an object');
  }
  if (!Array.isArray(page.items)) {
    throw new TypeError('page.items must be an array');
  }
  const next = page.nextCursor;
  if (next !== undefined && next !== null && !isCursor(next)) {
    throw new TypeError('page.nextCursor must be a string, finite number, null, or undefined');
  }
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }
  if (options === null || typeof options !== 'object') {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? DEFAULT_MAX_PAGES : options.maxPages;
  if (!Number.isSafeInteger(maxPages) || maxPages < 1) {
    throw new TypeError('maxPages must be a positive integer');
  }

  const signal = options.signal;
  if (signal !== undefined && (signal === null || typeof signal !== 'object' || typeof signal.aborted !== 'boolean')) {
    throw new TypeError('signal must be an AbortSignal');
  }

  const start = options.cursor;
  if (start !== undefined && start !== null && !isCursor(start)) {
    throw new TypeError('options.cursor must be a string, finite number, null, or undefined');
  }

  let cursor = start === null ? undefined : start;
  const seen = new Set();
  if (cursor !== undefined) seen.add(cursorKey(cursor));

  const items = [];
  let fetched = 0;

  for (;;) {
    throwIfAborted(signal);

    if (fetched >= maxPages) {
      throw new RangeError(`collectPages would exceed maxPages (${maxPages})`);
    }
    fetched += 1;

    const page = await fetchPage({ cursor, signal });
    throwIfAborted(signal);
    validatePage(page);

    for (const item of page.items) items.push(item);

    const next = page.nextCursor;
    if (next === undefined || next === null) return items;

    const key = cursorKey(next);
    if (seen.has(key)) {
      throw new Error(`repeated cursor detected: ${String(next)}`);
    }
    seen.add(key);
    cursor = next;
  }
}
