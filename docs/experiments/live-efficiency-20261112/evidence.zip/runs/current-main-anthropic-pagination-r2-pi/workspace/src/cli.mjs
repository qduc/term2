import fs from 'node:fs';
import { collectPages } from './pages.mjs';

async function main(argv) {
  const file = argv[2];
  if (file === undefined) throw new Error('usage: node src/cli.mjs pages.json');

  const pages = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!Array.isArray(pages)) throw new TypeError('pages file must contain an array');

  const items = await collectPages(async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    const page = pages.find((p) => p !== null && typeof p === 'object' && p.cursor === key);
    if (page === undefined) throw new Error(`no page for cursor ${JSON.stringify(key)}`);
    return page;
  });
  return items;
}

try {
  const items = await main(process.argv);
  process.stdout.write(`${JSON.stringify(items)}\n`);
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(`error: ${message}\n`);
  process.exitCode = 1;
}
