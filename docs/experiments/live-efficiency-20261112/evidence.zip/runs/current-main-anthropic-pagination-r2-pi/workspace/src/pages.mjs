const isCursor = (value) =>
  typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));

function abortError(signal) {
  if (signal.reason !== undefined) return signal.reason;
  const error = new Error('The operation was aborted');
  error.name = 'AbortError';
  return error;
}

function assertNotAborted(signal) {
  if (signal !== undefined && signal.aborted === true) throw abortError(signal);
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object') throw new TypeError('options must be an object');

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages < 1) {
    throw new TypeError('maxPages must be a positive integer');
  }

  const signal = options.signal;
  if (signal !== undefined && (signal === null || typeof signal.aborted !== 'boolean')) {
    throw new TypeError('signal must be an AbortSignal-like object');
  }

  // null/undefined initial cursor both mean "start with undefined".
  let cursor = options.cursor === null ? undefined : options.cursor;
  if (cursor !== undefined && !isCursor(cursor)) {
    throw new TypeError('cursor must be a string or finite number');
  }

  const seen = new Set();
  const items = [];
  let fetched = 0;

  for (;;) {
    if (cursor !== undefined) {
      if (seen.has(cursor)) throw new Error(`repeated cursor: ${String(cursor)}`);
      seen.add(cursor);
    }
    if (fetched >= maxPages) {
      throw new RangeError(`collectPages would exceed maxPages (${maxPages})`);
    }
    assertNotAborted(signal);

    fetched += 1;
    const page = await fetchPage({ cursor, signal });
    assertNotAborted(signal);

    if (page === null || typeof page !== 'object') throw new TypeError('page must be an object');
    if (!Array.isArray(page.items)) throw new TypeError('page.items must be an array');
    const next = page.nextCursor;
    if (next !== undefined && next !== null && !isCursor(next)) {
      throw new TypeError('nextCursor must be a string, finite number, null or undefined');
    }

    for (let i = 0; i < page.items.length; i += 1) items.push(page.items[i]);

    if (next === undefined || next === null) return items;
    cursor = next;
  }
}
