import fs from 'node:fs';
import { collectPages } from './pages.mjs';

async function main(argv) {
  const file = argv[2];
  if (typeof file !== 'string' || file === '') {
    throw new TypeError('usage: node src/cli.mjs pages.json');
  }
  const pages = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (!Array.isArray(pages)) throw new TypeError('pages file must contain an array');

  const items = await collectPages(async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    return pages.find((p) => p !== null && typeof p === 'object' && p.cursor === key);
  });
  process.stdout.write(`${JSON.stringify(items)}\n`);
}

try {
  await main(process.argv);
} catch (error) {
  process.stderr.write(`error: ${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
}
