const DEFAULT_MAX_PAGES = 100;

function isCursor(value) {
  return typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));
}

// Distinguishes string cursors from numeric cursors with the same spelling.
function cursorKey(cursor) {
  return `${typeof cursor}:${String(cursor)}`;
}

function throwIfAborted(signal) {
  if (signal === undefined || !signal.aborted) return;
  if (signal.reason !== undefined) throw signal.reason;
  const error = new Error('The operation was aborted');
  error.name = 'AbortError';
  throw error;
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object') throw new TypeError('options must be an object');

  const maxPages = options.maxPages === undefined ? DEFAULT_MAX_PAGES : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages < 1) {
    throw new TypeError('maxPages must be a positive integer');
  }

  const signal = options.signal;
  if (signal !== undefined && (signal === null || typeof signal !== 'object')) {
    throw new TypeError('signal must be an AbortSignal-like object');
  }

  let cursor = options.cursor === null ? undefined : options.cursor;
  if (cursor !== undefined && !isCursor(cursor)) throw new TypeError('invalid cursor');

  const seen = new Set();
  if (cursor !== undefined) seen.add(cursorKey(cursor));

  const items = [];
  let fetched = 0;
  for (;;) {
    throwIfAborted(signal);
    if (fetched >= maxPages) {
      throw new RangeError(`collectPages would exceed maxPages (${maxPages})`);
    }
    fetched += 1;

    const page = await fetchPage({ cursor, signal });
    throwIfAborted(signal);

    if (page === null || typeof page !== 'object') throw new TypeError('page must be an object');
    if (!Array.isArray(page.items)) throw new TypeError('page.items must be an array');
    for (let i = 0; i < page.items.length; i += 1) items.push(page.items[i]);

    const next = page.nextCursor;
    if (next === undefined || next === null) return items;
    if (!isCursor(next)) throw new TypeError('nextCursor must be a string, finite number, null, or undefined');

    const key = cursorKey(next);
    if (seen.has(key)) throw new Error(`repeated cursor detected: ${String(next)}`);
    seen.add(key);
    cursor = next;
  }
}
