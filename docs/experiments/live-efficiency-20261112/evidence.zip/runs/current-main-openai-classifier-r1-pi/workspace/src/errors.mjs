const QUOTA_CODES = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);
const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);

function statusValue(value) {
  if (Number.isInteger(value) && value >= 100 && value <= 599) return value;
  if (typeof value === 'string' && /^\d+$/.test(value.trim())) {
    const parsed = Number(value.trim());
    if (Number.isInteger(parsed) && parsed >= 100 && parsed <= 599) return parsed;
  }
  return undefined;
}

function messageStatus(error) {
  for (const value of [error?.message, error?.error]) {
    if (typeof value !== 'string') continue;
    const match = value.match(/^\s*(?:HTTP\s+)?(\d{3})(?:\s*:?\s*|\b)/i);
    if (match) return statusValue(match[1]);
  }
  return undefined;
}

function headerValue(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    if (value !== null && value !== undefined) return value;
  }
  if (typeof headers === 'object') {
    const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
    if (key !== undefined) return headers[key];
  }
  return undefined;
}

function retryDelay(error, nowMs) {
  const top = error?.headers;
  const response = error?.response?.headers;
  const get = (name) => {
    const first = headerValue(top, name);
    return first === undefined || first === null ? headerValue(response, name) : first;
  };

  const milliseconds = get('retry-after-ms');
  if (milliseconds !== undefined && milliseconds !== null && String(milliseconds).trim() !== '') {
    const text = String(milliseconds).trim();
    const numeric = typeof milliseconds === 'number' || /^\d+(?:\.\d+)?$/.test(text);
    const value = typeof milliseconds === 'number' ? milliseconds : Number(text);
    if (numeric && Number.isFinite(value) && value >= 0) return value;
  }

  const retryAfter = get('retry-after');
  if (typeof retryAfter !== 'string' && typeof retryAfter !== 'number') return undefined;
  const text = String(retryAfter).trim();
  if (/^\d+(?:\.\d+)?$/.test(text)) {
    const delay = Number(text) * 1000;
    return Number.isFinite(delay) ? delay : undefined;
  }
  const httpDate = /^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), \d{2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4} \d{2}:\d{2}:\d{2} GMT$/i.test(text)
    || /^(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), \d{2}-(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-\d{2} \d{2}:\d{2}:\d{2} GMT$/i.test(text)
    || /^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun) (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) {1,2}\d{1,2} \d{2}:\d{2}:\d{2} \d{4}$/i.test(text);
  if (!httpDate) return undefined;
  const date = Date.parse(text);
  if (Number.isFinite(date)) {
    const delay = Math.max(0, date - nowMs);
    return Number.isFinite(delay) ? delay : undefined;
  }
  return undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const structuredStatus = [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ].map(statusValue).find((status) => status !== undefined);
  const status = structuredStatus ?? messageStatus(error);
  const codes = [error?.code, error?.error?.code];

  let kind = 'unknown';
  let retryable = false;
  if (status === 402 || codes.some((code) => QUOTA_CODES.has(code))) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if ([400, 404, 413, 422].includes(status)) {
    kind = 'invalid_request';
  } else if (codes.some((code) => NETWORK_CODES.has(code))) {
    kind = 'transient';
    retryable = true;
  }

  const delay = retryDelay(error, nowMs);
  if (delay !== undefined && (kind === 'rate_limit' || kind === 'transient') && delay > 60000) {
    retryable = false;
  }
  const result = {kind, retryable};
  if (delay !== undefined) result.retryAfterMs = delay;
  return result;
}
