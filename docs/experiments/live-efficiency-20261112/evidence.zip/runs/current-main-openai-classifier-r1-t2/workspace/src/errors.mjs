const quotaCodes = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

function validStatus(value) {
  let status = value;
  if (typeof status === 'string' && /^\d+$/.test(status)) status = Number(status);
  return Number.isInteger(status) && status >= 100 && status <= 599 ? status : undefined;
}

function statusFromMessage(error) {
  const messages = [error, error?.message];
  for (const message of messages) {
    if (typeof message !== 'string') continue;
    const match = /^(?:HTTP\s+)?(\d{3})(?:\s|:|$)/i.exec(message);
    const status = match && validStatus(match[1]);
    if (status !== undefined) return status;
  }
  return undefined;
}

function headerValue(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') return headers.get(name) ?? undefined;
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function retryDelay(error, nowMs) {
  const headers = error?.headers;
  const responseHeaders = error?.response?.headers;
  for (const milliseconds of [headerValue(headers, 'retry-after-ms'),
    headerValue(responseHeaders, 'retry-after-ms')]) {
    const isDecimal = typeof milliseconds === 'string' && /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(milliseconds.trim());
    const value = typeof milliseconds === 'number' ? milliseconds : isDecimal ? Number(milliseconds) : NaN;
    if (Number.isFinite(value) && value >= 0) return value;
  }

  for (const retryAfter of [headerValue(headers, 'retry-after'), headerValue(responseHeaders, 'retry-after')]) {
    if (typeof retryAfter !== 'string' && typeof retryAfter !== 'number') continue;
    const text = String(retryAfter).trim();
    if (/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)) {
      const seconds = Number(text);
      const delay = seconds * 1000;
      if (Number.isFinite(seconds) && Number.isFinite(delay)) return delay;
      continue;
    }
    if (!/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), \d{2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4} \d{2}:\d{2}:\d{2} GMT$/.test(text)) continue;
    const date = Date.parse(text);
    const now = typeof nowMs === 'number' ? nowMs : Number(nowMs);
    if (Number.isFinite(date) && Number.isFinite(now)) return Math.max(0, date - now);
  }
  return undefined;
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const topCode = error?.code;
  const nestedCode = error?.error?.code;
  const codes = [topCode, nestedCode];
  let kind;
  let retryable;

  if (validStatus(error?.status) === 402 || codes.some((code) => quotaCodes.has(code))) {
    kind = 'quota';
    retryable = false;
  } else {
    const statusValues = [error?.status, error?.response?.status, error?.error?.status,
      error?.statusCode, typeof topCode === 'number' || typeof topCode === 'string' ? topCode : undefined];
    let status;
    for (const value of statusValues) {
      status = validStatus(value);
      if (status !== undefined) break;
    }
    if (status === undefined) status = statusFromMessage(error);

    if (status === 401 || status === 403) {
      kind = 'authentication';
      retryable = false;
    } else if (status === 402) {
      kind = 'quota';
      retryable = false;
    } else if (status === 429) {
      kind = 'rate_limit';
      retryable = true;
    } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
      kind = 'transient';
      retryable = true;
    } else if ([400, 404, 413, 422].includes(status)) {
      kind = 'invalid_request';
      retryable = false;
    } else if (codes.some((code) => ['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN'].includes(code))) {
      kind = 'transient';
      retryable = true;
    } else {
      kind = 'unknown';
      retryable = false;
    }
  }

  const result = {kind, retryable};
  const delay = retryDelay(error, nowMs);
  if (delay !== undefined) {
    result.retryAfterMs = delay;
    if (delay > 60000 && (kind === 'rate_limit' || kind === 'transient')) result.retryable = false;
  }
  return result;
}
