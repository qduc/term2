import {classifyApiError} from './errors.mjs';

function abortError() {
  return new DOMException('The operation was aborted', 'AbortError');
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw signal.reason === undefined ? abortError() : signal.reason;
}

function delay(ms, signal) {
  return new Promise((resolve, reject) => {
    throwIfAborted(signal);
    const timer = setTimeout(finish, ms);
    function cleanup() {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
    }
    function finish() {
      cleanup();
      resolve();
    }
    function onAbort() {
      cleanup();
      reject(signal.reason === undefined ? abortError() : signal.reason);
    }
    signal?.addEventListener('abort', onAbort, {once: true});
    if (signal?.aborted) onAbort();
  });
}

export async function withRetry(operation, options = {}) {
  const {maxAttempts = 3, sleep = delay, now = Date.now, signal} = options;
  if (typeof operation !== 'function') throw new TypeError('operation must be a function');
  if (!Number.isInteger(maxAttempts) || maxAttempts <= 0) {
    throw new RangeError('maxAttempts must be a positive integer');
  }

  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    throwIfAborted(signal);
    try {
      return await operation();
    } catch (error) {
      const classification = classifyApiError(error, {nowMs: now()});
      if (!classification.retryable || attempt + 1 >= maxAttempts) throw error;
      await sleep(classification.retryAfterMs ?? 0, signal);
      throwIfAborted(signal);
    }
  }
}
