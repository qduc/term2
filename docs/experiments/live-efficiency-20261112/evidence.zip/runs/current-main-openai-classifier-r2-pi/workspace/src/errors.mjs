const QUOTA_CODES = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

const NETWORK_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN']);

function parseStatus(value) {
  if (typeof value === 'number') {
    return Number.isInteger(value) && value >= 100 && value <= 599 ? value : undefined;
  }
  if (typeof value === 'string' && /^\s*\d{3}\s*$/.test(value)) {
    const status = Number(value.trim());
    return status >= 100 && status <= 599 ? status : undefined;
  }
  return undefined;
}

function statusFromPrefix(value) {
  if (typeof value !== 'string') return undefined;
  const match = /^\s*(?:HTTP\s+)?(\d{3})(?=\s|:|$)/i.exec(value);
  if (!match) return undefined;
  return parseStatus(match[1]);
}

function statusOf(error) {
  const candidates = [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ];
  for (const candidate of candidates) {
    const status = parseStatus(candidate);
    if (status !== undefined) return status;
  }
  return statusFromPrefix(typeof error === 'string' ? error : error?.message)
    ?? statusFromPrefix(error?.error);
}

function hasQuotaCode(error) {
  return QUOTA_CODES.has(error?.code)
    || QUOTA_CODES.has(error?.error?.code);
}

function headerValue(headers, name) {
  if (headers == null) return undefined;
  if (typeof headers.get === 'function') {
    const value = headers.get(name);
    return value == null ? undefined : value;
  }
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function nonnegativeFinite(value) {
  if (typeof value === 'number') return Number.isFinite(value) && value >= 0 ? value : undefined;
  if (typeof value !== 'string' || value.trim() === '') return undefined;
  if (!/^\+?(?:\d+(?:\.\d*)?|\.\d+)$/.test(value.trim())) return undefined;
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? number : undefined;
}

function retryDelay(error, nowMs) {
  const primary = error?.headers;
  const fallback = error?.response?.headers;
  const get = (name) => headerValue(primary, name) ?? headerValue(fallback, name);
  const milliseconds = nonnegativeFinite(get('retry-after-ms'));
  if (milliseconds !== undefined) return milliseconds;

  const value = get('retry-after');
  if (typeof value !== 'string') return undefined;
  const seconds = nonnegativeFinite(value);
  if (seconds !== undefined) {
    const millisecondsFromSeconds = seconds * 1000;
    if (Number.isFinite(millisecondsFromSeconds)) return millisecondsFromSeconds;
  }
  const dateValue = value.trim();
  const isHttpDate = /^(?:[A-Za-z]{3}, \d{2} [A-Za-z]{3} \d{4} \d{2}:\d{2}:\d{2} GMT|[A-Za-z]+, \d{2}-[A-Za-z]{3}-\d{2} \d{2}:\d{2}:\d{2} GMT|[A-Za-z]{3} [A-Za-z]{3} [ \d]\d \d{2}:\d{2}:\d{2} \d{4})$/.test(dateValue);
  if (!isHttpDate) return undefined;
  const dateMs = Date.parse(dateValue);
  const delay = dateMs - nowMs;
  if (!Number.isFinite(dateMs) || !Number.isFinite(delay)) return undefined;
  return Math.max(0, delay);
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const status = statusOf(error);
  let kind = 'unknown';
  let retryable = false;

  if (status === 402 || hasQuotaCode(error)) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if (status === 400 || status === 404 || status === 413 || status === 422) {
    kind = 'invalid_request';
  } else if (NETWORK_CODES.has(error?.code)) {
    kind = 'transient';
    retryable = true;
  }

  const delay = retryDelay(error, nowMs);
  if (delay !== undefined && (kind === 'rate_limit' || kind === 'transient') && delay > 60000) {
    retryable = false;
  }
  return {
    kind,
    retryable,
    ...(delay === undefined ? {} : {retryAfterMs: delay}),
  };
}
