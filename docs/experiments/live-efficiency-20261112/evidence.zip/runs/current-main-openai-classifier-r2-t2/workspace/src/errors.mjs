const QUOTA_CODES = new Set([
  'insufficient_quota',
  'billing_hard_limit_reached',
  'billing_not_active',
]);

function statusValue(value) {
  if (typeof value === 'number' && Number.isInteger(value) && value >= 100 && value <= 599) {
    return value;
  }
  if (typeof value === 'string' && /^\d+$/.test(value)) {
    const status = Number(value);
    if (status >= 100 && status <= 599) return status;
  }
  return undefined;
}

function responseStatus(error) {
  for (const candidate of [
    error?.status,
    error?.response?.status,
    error?.error?.status,
    error?.statusCode,
    error?.code,
  ]) {
    const status = statusValue(candidate);
    if (status !== undefined) return status;
  }

  for (const value of [error?.error, error?.message]) {
    if (typeof value !== 'string') continue;
    const match = /^(?:HTTP\s+)?(\d{3})(?=\s|:|$)/i.exec(value);
    if (match) return Number(match[1]);
  }
  return undefined;
}

function header(headers, name) {
  if (!headers) return undefined;
  if (typeof headers.get === 'function') return headers.get(name) ?? undefined;
  if (typeof headers !== 'object') return undefined;
  const key = Object.keys(headers).find((candidate) => candidate.toLowerCase() === name);
  return key === undefined ? undefined : headers[key];
}

function retryDelay(error, nowMs) {
  const headers = error?.headers ?? error?.response?.headers;
  const milliseconds = header(headers, 'retry-after-ms');
  if (milliseconds !== undefined && milliseconds !== null && milliseconds !== '') {
    const text = typeof milliseconds === 'string' ? milliseconds.trim() : milliseconds;
    if (text !== '') {
      const delay = typeof text === 'number' ? text : Number(text);
      if (Number.isFinite(delay) && delay >= 0) return delay;
    }
  }

  const value = header(headers, 'retry-after');
  if (typeof value !== 'string' && typeof value !== 'number') return undefined;
  const text = String(value).trim();
  if (/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(text)) {
    const delay = Number(text) * 1000;
    return Number.isFinite(delay) ? delay : undefined;
  }
  const date = Date.parse(text);
  return Number.isNaN(date) ? undefined : Math.max(0, date - nowMs);
}

export function classifyApiError(error, {nowMs = Date.now()} = {}) {
  const nestedCode = error?.error && typeof error.error === 'object' ? error.error.code : undefined;
  const codes = [error?.code, nestedCode];
  const status = responseStatus(error);

  let kind = 'unknown';
  let retryable = false;
  if (status === 402 || codes.some((code) => QUOTA_CODES.has(code))) {
    kind = 'quota';
  } else if (status === 401 || status === 403) {
    kind = 'authentication';
  } else if (status === 429) {
    kind = 'rate_limit';
    retryable = true;
  } else if (status === 408 || status === 409 || (status >= 500 && status <= 599)) {
    kind = 'transient';
    retryable = true;
  } else if ([400, 404, 413, 422].includes(status)) {
    kind = 'invalid_request';
  } else if (codes.some((code) => ['ECONNRESET', 'ETIMEDOUT', 'EAI_AGAIN'].includes(code))) {
    kind = 'transient';
    retryable = true;
  }

  const result = {kind, retryable};
  const delay = retryDelay(error, nowMs);
  if (delay !== undefined) {
    result.retryAfterMs = delay;
    if (delay > 60000 && (kind === 'rate_limit' || kind === 'transient')) result.retryable = false;
  }
  return result;
}
