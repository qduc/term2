import {classifyApiError} from './errors.mjs';

function abortError() {
  return new DOMException('The operation was aborted', 'AbortError');
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw signal.reason === undefined ? abortError() : signal.reason;
}

function delay(ms, signal) {
  return new Promise((resolve, reject) => {
    throwIfAborted(signal);
    const timer = setTimeout(done, ms);
    function done() {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }
    function onAbort() {
      clearTimeout(timer);
      signal.removeEventListener('abort', onAbort);
      try {
        throwIfAborted(signal);
      } catch (error) {
        reject(error);
      }
    }
    signal?.addEventListener('abort', onAbort, {once: true});
    if (signal?.aborted) onAbort();
  });
}

export async function withRetry(operation, {maxAttempts = 3, sleep = delay, now = Date.now, signal} = {}) {
  if (typeof operation !== 'function') throw new TypeError('operation must be a function');
  if (!Number.isInteger(maxAttempts) || maxAttempts <= 0) {
    throw new RangeError('maxAttempts must be a positive integer');
  }

  for (let attempt = 0; ; attempt += 1) {
    throwIfAborted(signal);
    try {
      return await operation();
    } catch (error) {
      if (attempt + 1 >= maxAttempts) throw error;
      const classification = classifyApiError(error, {nowMs: now()});
      if (!classification.retryable) throw error;
      await sleep(classification.retryAfterMs ?? 0, signal);
      throwIfAborted(signal);
    }
  }
}
