import fs from 'node:fs';
import readline from 'node:readline';
import { summarizeEvents } from './summary.mjs';

async function* readLines(input) {
  const reader = readline.createInterface({ input, crlfDelay: Infinity });
  try {
    for await (const line of reader) yield line;
  } finally {
    reader.close();
  }
}

async function main() {
  const files = process.argv.slice(2);
  if (files.length === 0) throw new Error('At least one input file is required');
  if (files.filter((file) => file === '-').length > 1) {
    throw new Error("Standard input ('-') may be specified at most once");
  }

  async function* allLines() {
    for (const file of files) {
      const input = file === '-' ? process.stdin : fs.createReadStream(file, { encoding: 'utf8' });
      yield* readLines(input);
    }
  }

  const report = await summarizeEvents(allLines());
  process.stdout.write(`${JSON.stringify(report)}\n`);
  process.exitCode = report.invalidLines > 0 ? 2 : 0;
}

try {
  await main();
} catch (error) {
  process.stderr.write(`${error?.message ?? String(error)}\n`);
  process.exitCode = 1;
}
