const MAX_SAFE_BIGINT = BigInt(Number.MAX_SAFE_INTEGER);
const MIN_SAFE_BIGINT = BigInt(Number.MIN_SAFE_INTEGER);

function isValidEvent(value) {
  return value !== null &&
    typeof value === 'object' &&
    !Array.isArray(value) &&
    typeof value.id === 'string' && value.id.trim().length > 0 &&
    typeof value.account === 'string' && value.account.trim().length > 0 &&
    Number.isSafeInteger(value.amountCents) &&
    Number.isInteger(value.revision) && value.revision >= 0;
}

export async function summarizeEvents(lines) {
  const winners = new Map();
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line === 'string' && line.trim().length === 0) continue;

    let event;
    try {
      if (typeof line !== 'string') throw new SyntaxError('Line must be a string');
      event = JSON.parse(line);
    } catch {
      invalidLines++;
      continue;
    }

    if (!isValidEvent(event)) {
      invalidLines++;
      continue;
    }

    const previous = winners.get(event.id);
    if (previous !== undefined) {
      duplicateEvents++;
      if (event.revision < previous.revision) continue;
    }
    winners.set(event.id, event);
  }

  const totals = new Map();
  for (const event of winners.values()) {
    const total = totals.get(event.account) ?? { netCents: 0n, count: 0 };
    total.netCents += BigInt(event.amountCents);
    total.count++;
    totals.set(event.account, total);
  }

  const accounts = [...totals.entries()]
    .sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0)
    .map(([account, total]) => {
      if (total.netCents > MAX_SAFE_BIGINT || total.netCents < MIN_SAFE_BIGINT) {
        throw new RangeError(`Aggregate for account ${JSON.stringify(account)} is outside the safe integer range`);
      }
      return { account, netCents: Number(total.netCents), count: total.count };
    });

  return { accounts, invalidLines, duplicateEvents };
}
