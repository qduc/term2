import { createReadStream } from 'node:fs';
import { createInterface } from 'node:readline';
import { summarizeEvents } from './summary.mjs';

async function* readLines(input) {
  const reader = createInterface({ input, crlfDelay: Infinity });
  try {
    for await (const line of reader) yield line;
  } finally {
    reader.close();
  }
}

async function* inputLines(paths) {
  for (const path of paths) {
    const input = path === '-' ? process.stdin : createReadStream(path, { encoding: 'utf8' });
    yield* readLines(input);
  }
}

try {
  const paths = process.argv.slice(2);
  if (paths.length === 0) throw new Error('At least one input file is required');
  if (paths.filter(path => path === '-').length > 1) {
    throw new Error("Standard input ('-') may be specified at most once");
  }

  const report = await summarizeEvents(inputLines(paths));
  process.stdout.write(`${JSON.stringify(report)}\n`);
  process.exitCode = report.invalidLines > 0 ? 2 : 0;
} catch (error) {
  process.stderr.write(`${error?.message ?? String(error)}\n`);
  process.exitCode = 1;
}
