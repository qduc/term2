export async function summarizeEvents(lines) {
  const events = new Map();
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line !== 'string') {
      invalidLines++;
      continue;
    }
    if (line.trim() === '') continue;

    let event;
    try {
      event = JSON.parse(line);
    } catch {
      invalidLines++;
      continue;
    }

    if (
      event === null ||
      typeof event !== 'object' ||
      Array.isArray(event) ||
      typeof event.id !== 'string' || event.id.trim() === '' ||
      typeof event.account !== 'string' || event.account.trim() === '' ||
      !Number.isSafeInteger(event.amountCents) ||
      !Number.isInteger(event.revision) || event.revision < 0
    ) {
      invalidLines++;
      continue;
    }

    const previous = events.get(event.id);
    if (previous) {
      duplicateEvents++;
      if (event.revision >= previous.revision) events.set(event.id, event);
    } else {
      events.set(event.id, event);
    }
  }

  const totals = new Map();
  for (const event of events.values()) {
    const total = totals.get(event.account) ?? { account: event.account, net: 0n, count: 0 };
    total.net += BigInt(event.amountCents);
    total.count++;
    totals.set(event.account, total);
  }

  const accounts = [...totals.values()]
    .sort((left, right) => left.account < right.account ? -1 : left.account > right.account ? 1 : 0)
    .map(({ account, net, count }) => {
      if (net < BigInt(Number.MIN_SAFE_INTEGER) || net > BigInt(Number.MAX_SAFE_INTEGER)) {
        throw new RangeError(`Aggregate for account ${account} is outside the safe integer range`);
      }
      return { account, netCents: Number(net), count };
    });

  return { accounts, invalidLines, duplicateEvents };
}
