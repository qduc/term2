import fs from 'node:fs';
import readline from 'node:readline';
import { summarizeEvents } from './summary.mjs';

async function* readLines(path) {
  const input = path === '-' ? process.stdin : fs.createReadStream(path, { encoding: 'utf8' });
  const reader = readline.createInterface({ input, crlfDelay: Infinity });
  try {
    for await (const line of reader) yield line;
  } finally {
    reader.close();
    if (path !== '-' && !input.destroyed) input.destroy();
  }
}

async function* linesFromArguments(paths) {
  for (const path of paths) {
    yield* readLines(path);
  }
}

try {
  const paths = process.argv.slice(2);
  if (paths.length === 0) throw new Error('At least one input file is required');
  if (paths.some((path) => path.length === 0)) throw new Error('Input paths must not be empty');
  if (paths.filter((path) => path === '-').length > 1) {
    throw new Error("Stdin ('-') may be specified at most once");
  }

  const report = await summarizeEvents(linesFromArguments(paths));
  process.stdout.write(`${JSON.stringify(report)}\n`);
  if (report.invalidLines > 0) process.exitCode = 2;
} catch (error) {
  process.stderr.write(`${error?.message ?? String(error)}\n`);
  process.exitCode = 1;
}
