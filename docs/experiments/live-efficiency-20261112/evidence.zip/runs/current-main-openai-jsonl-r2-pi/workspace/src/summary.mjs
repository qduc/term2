export async function summarizeEvents(lines) {
  const winners = new Map();
  let invalidLines = 0;
  let duplicateEvents = 0;

  for await (const line of lines) {
    if (typeof line !== 'string') {
      invalidLines++;
      continue;
    }
    if (line.trim() === '') continue;

    let event;
    try {
      event = JSON.parse(line);
    } catch {
      invalidLines++;
      continue;
    }

    if (
      event === null ||
      typeof event !== 'object' ||
      Array.isArray(event) ||
      typeof event.id !== 'string' ||
      event.id.trim() === '' ||
      typeof event.account !== 'string' ||
      event.account.trim() === '' ||
      !Number.isSafeInteger(event.amountCents) ||
      !Number.isInteger(event.revision) ||
      event.revision < 0
    ) {
      invalidLines++;
      continue;
    }

    const previous = winners.get(event.id);
    if (previous !== undefined) {
      duplicateEvents++;
      if (event.revision < previous.revision) continue;
    }
    winners.set(event.id, event);
  }

  const totals = new Map();
  for (const event of winners.values()) {
    const total = totals.get(event.account) ?? {
      account: event.account,
      netCents: 0n,
      count: 0,
    };
    total.netCents += BigInt(event.amountCents);
    total.count++;
    totals.set(event.account, total);
  }

  const accounts = [...totals.values()]
    .map((total) => {
      if (total.netCents < BigInt(Number.MIN_SAFE_INTEGER) || total.netCents > BigInt(Number.MAX_SAFE_INTEGER)) {
        throw new RangeError('Account aggregate exceeds the safe integer range');
      }
      return { ...total, netCents: Number(total.netCents) };
    })
    .sort((a, b) =>
      a.account < b.account ? -1 : a.account > b.account ? 1 : 0,
    );
  return { accounts, invalidLines, duplicateEvents };
}
