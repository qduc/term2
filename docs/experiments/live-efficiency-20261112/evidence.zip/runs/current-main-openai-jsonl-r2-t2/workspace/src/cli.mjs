import {createReadStream} from 'node:fs';
import {createInterface} from 'node:readline';
import {summarizeEvents} from './summary.mjs';

async function* readLines(paths) {
  for (const path of paths) {
    const input = path === '-' ? process.stdin : createReadStream(path);
    const reader = createInterface({input, crlfDelay: Infinity});
    for await (const line of reader) yield line;
  }
}

async function main() {
  const paths = process.argv.slice(2);
  if (paths.length === 0) throw new Error('At least one input file is required');
  if (paths.filter(path => path === '-').length > 1) {
    throw new Error("Standard input ('-') may be specified only once");
  }

  const report = await summarizeEvents(readLines(paths));
  process.stdout.write(`${JSON.stringify(report)}\n`);
  if (report.invalidLines > 0) process.exitCode = 2;
}

main().catch(error => {
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
});
