import fs from 'node:fs';
import { collectPages } from './pages.mjs';

try {
  const pages = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  if (!Array.isArray(pages)) throw new TypeError('Input must be an array of pages');

  for (const page of pages) {
    if (page === null || typeof page !== 'object' || Array.isArray(page)) {
      throw new TypeError('Each page must be an object');
    }
    const key = page.cursor;
    if (key !== null && (typeof key !== 'string' && !(typeof key === 'number' && Number.isFinite(key)))) {
      throw new TypeError('Each page cursor must be null, a string, or a finite number');
    }
  }

  const result = await collectPages(async ({ cursor }) => {
    const key = cursor === undefined ? null : cursor;
    return pages.find((page) => page.cursor === key);
  });
  process.stdout.write(`${JSON.stringify(result)}\n`);
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(`${message}\n`);
  process.exitCode = 1;
}
