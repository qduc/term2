function isCursor(value) {
  return typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value));
}

function cursorKey(cursor) {
  return `${typeof cursor}:${cursor}`;
}

function throwIfAborted(signal) {
  if (signal?.aborted) {
    if (signal != null && 'reason' in Object(signal)) throw signal.reason;
    const error = new Error('The operation was aborted');
    error.name = 'AbortError';
    throw error;
  }
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }
  if (options === null || typeof options !== 'object' || Array.isArray(options)) {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  // A null starting cursor represents the same initial position as no cursor.
  if (cursor === null) cursor = undefined;
  if (cursor !== undefined && !isCursor(cursor)) {
    throw new TypeError('cursor must be a string or finite number');
  }

  const signal = options.signal;
  const seen = new Set();
  const items = [];
  let pagesFetched = 0;

  while (true) {
    throwIfAborted(signal);

    if (cursor !== undefined) {
      const key = cursorKey(cursor);
      if (seen.has(key)) throw new Error('Repeated page cursor');
      seen.add(key);
    }
    if (pagesFetched >= maxPages) {
      throw new RangeError('Maximum page count exceeded');
    }

    const page = await fetchPage({ cursor, signal });
    throwIfAborted(signal);

    if (page === null || typeof page !== 'object' || Array.isArray(page)) {
      throw new TypeError('fetchPage must return a page object');
    }
    if (!Array.isArray(page.items)) {
      throw new TypeError('page.items must be an array');
    }
    const nextCursor = page.nextCursor;
    if (nextCursor !== null && nextCursor !== undefined && !isCursor(nextCursor)) {
      throw new TypeError('page.nextCursor must be a string, finite number, null, or undefined');
    }

    for (const item of page.items) items.push(item);
    pagesFetched++;

    if (nextCursor === null || nextCursor === undefined) return items;

    const nextKey = cursorKey(nextCursor);
    if (seen.has(nextKey)) throw new Error('Repeated page cursor');
    if (pagesFetched >= maxPages) throw new RangeError('Maximum page count exceeded');
    cursor = nextCursor;
  }
}
