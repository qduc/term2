function validateCursor(cursor) {
  if (cursor === null || cursor === undefined) return;
  if (typeof cursor !== 'string' && !(typeof cursor === 'number' && Number.isFinite(cursor))) {
    throw new TypeError('cursor must be a string, finite number, null, or undefined');
  }
}

function abortError() {
  const error = new Error('The operation was aborted');
  error.name = 'AbortError';
  return error;
}

function throwIfAborted(signal) {
  if (!signal?.aborted) return;
  if (signal.reason !== undefined) throw signal.reason;
  throw abortError();
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object' || Array.isArray(options)) {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  validateCursor(cursor);
  const seen = new Set();
  if (cursor !== null && cursor !== undefined) seen.add(cursor);
  const collected = [];
  let fetched = 0;

  while (true) {
    throwIfAborted(options.signal);
    if (fetched >= maxPages) throw new RangeError('maximum page count exceeded');
    if (cursor !== null && cursor !== undefined) {
      if (seen.has(cursor) && fetched > 0) throw new Error('repeated cursor');
      seen.add(cursor);
    }

    const page = await fetchPage({ cursor, signal: options.signal });
    fetched += 1;
    throwIfAborted(options.signal);

    if (page === null || typeof page !== 'object' || Array.isArray(page)) {
      throw new TypeError('page must be an object');
    }
    if (!Array.isArray(page.items)) throw new TypeError('page.items must be an array');
    validateCursor(page.nextCursor);
    for (const item of page.items) collected.push(item);

    cursor = page.nextCursor;
    if (cursor === null || cursor === undefined) return collected;
    if (seen.has(cursor)) throw new Error('repeated cursor');
  }
}
