function validateCursor(cursor) {
  if (cursor === null || cursor === undefined) return;
  if (typeof cursor === 'string') return;
  if (typeof cursor === 'number' && Number.isFinite(cursor)) return;
  throw new TypeError('cursor must be a string, finite number, null, or undefined');
}

function throwIfAborted(signal) {
  if (signal?.aborted) {
    if (signal.reason !== undefined) throw signal.reason;
    const error = new Error('The operation was aborted');
    error.name = 'AbortError';
    throw error;
  }
}

export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') throw new TypeError('fetchPage must be a function');
  if (options === null || typeof options !== 'object') throw new TypeError('options must be an object');

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  // A null starting cursor denotes the initial request, just like the CLI format.
  if (cursor === null) cursor = undefined;
  validateCursor(cursor);

  const collected = [];
  const seenCursors = new Set();
  let pageCount = 0;

  while (true) {
    if (pageCount >= maxPages) throw new RangeError('maximum page count exceeded');
    validateCursor(cursor);
    if (cursor !== null && cursor !== undefined) {
      if (seenCursors.has(cursor)) throw new Error('repeated cursor');
      seenCursors.add(cursor);
    }

    throwIfAborted(options.signal);
    const page = await fetchPage({ cursor, signal: options.signal });
    throwIfAborted(options.signal);

    if (page === null || typeof page !== 'object' || Array.isArray(page) || !Array.isArray(page.items)) {
      throw new TypeError('page must be an object with an items array');
    }
    validateCursor(page.nextCursor);
    for (const item of page.items) collected.push(item);
    pageCount++;

    if (page.nextCursor === null || page.nextCursor === undefined) return collected;
    cursor = page.nextCursor;
  }
}
