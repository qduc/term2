export async function collectPages(fetchPage, options = {}) {
  if (typeof fetchPage !== 'function') {
    throw new TypeError('fetchPage must be a function');
  }
  if (options === null || typeof options !== 'object') {
    throw new TypeError('options must be an object');
  }

  const maxPages = options.maxPages === undefined ? 100 : options.maxPages;
  if (!Number.isInteger(maxPages) || maxPages <= 0) {
    throw new TypeError('maxPages must be a positive integer');
  }

  let cursor = options.cursor;
  const signal = options.signal;
  const items = [];
  const seenCursors = new Set();
  let pageCount = 0;

  const validateCursor = (value) => {
    if (value !== undefined && value !== null &&
        typeof value !== 'string' &&
        !(typeof value === 'number' && Number.isFinite(value))) {
      throw new TypeError('cursor must be a string or finite number');
    }
  };
  const throwIfAborted = () => {
    if (signal?.aborted) {
      if (signal.reason !== undefined) throw signal.reason;
      const error = new Error('The operation was aborted');
      error.name = 'AbortError';
      throw error;
    }
  };

  validateCursor(cursor);
  while (true) {
    throwIfAborted();
    if (cursor !== null && cursor !== undefined) {
      if (seenCursors.has(cursor)) throw new Error('Repeated pagination cursor');
      seenCursors.add(cursor);
    }

    const page = await fetchPage({ cursor, signal });
    throwIfAborted();
    if (page === null || typeof page !== 'object' || Array.isArray(page) ||
        !Array.isArray(page.items)) {
      throw new TypeError('page must be an object with an items array');
    }
    validateCursor(page.nextCursor);
    for (const item of page.items) items.push(item);
    pageCount += 1;

    cursor = page.nextCursor;
    if (cursor === null || cursor === undefined) break;
    validateCursor(cursor);
    if (seenCursors.has(cursor)) throw new Error('Repeated pagination cursor');
    if (pageCount >= maxPages) throw new RangeError('Maximum page count exceeded');
  }
  return items;
}
