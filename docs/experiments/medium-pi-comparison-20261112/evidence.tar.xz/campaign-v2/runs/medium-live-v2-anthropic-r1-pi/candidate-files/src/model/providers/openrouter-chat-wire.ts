/**
 * OpenRouter's wire conventions over the application-owned chat-completions
 * adapter (`openai-chat-completions-model.ts`). Replaces the former
 * `@openrouter/ai-sdk-provider` path; public surface:
 *
 * - `OpenRouterChatModel` — a `StreamedModelTurn` that translates each request
 *   (provider-option flattening, `reasoning: { effort }`, `tool_choice` gating)
 *   and delegates to the adapter configured with `OPENROUTER_DIALECT`.
 * - `createOpenRouterChatClient()` — an OpenAI client whose `create()` surfaces
 *   SDK-thrown in-band errors as stream error chunks and augments HTTP error
 *   messages with OpenRouter's routing detail.
 */
import OpenAI, { APIError } from 'openai';
import { isRecord } from './common/chat-completion-errors.js';
import type { ChatCompletionsDialect } from './openai-chat-completions-model.js';
import { OpenAIChatCompletionsModel } from './openai-chat-completions-model.js';
import type {
  StreamedModelProviderOptions,
  StreamedModelTurn,
  StreamedModelTurnEvent,
  StreamedModelTurnRequest,
} from '../streamed-model-turn.js';

/** Upstream provider metadata lives under `providerMetadata.openrouter.provider`. */
const OPENROUTER_NAMESPACE = 'openrouter';

/** Routing detail from OpenRouter's error object: `metadata.provider_name` and `metadata.raw`. */
export function describeOpenRouterErrorDetail(error: unknown): string | undefined {
  const record = isRecord(error) ? error : undefined;
  const nested = isRecord(record?.error) ? record.error : undefined;
  const metadata = isRecord(record?.metadata) ? record.metadata : isRecord(nested?.metadata) ? nested.metadata : undefined;
  const providerName =
    typeof metadata?.provider_name === 'string' && metadata.provider_name.trim().length > 0
      ? `upstream ${metadata.provider_name.trim()}`
      : undefined;
  // `raw` is the upstream body: a string as-is, a JSON object serialized; null means nothing to add.
  const raw = metadata?.raw;
  const rawText = raw == null ? undefined : typeof raw === 'string' ? raw : JSON.stringify(raw);
  const parts = [providerName, rawText && rawText.length > 0 ? rawText : undefined].filter(
    (part): part is string => part !== undefined,
  );
  return parts.length > 0 ? parts.join(': ') : undefined;
}

export const OPENROUTER_DIALECT: ChatCompletionsDialect = {
  upstreamProviderNamespace: OPENROUTER_NAMESPACE,
  describeErrorDetail: describeOpenRouterErrorDetail,
};

/** Flattens the three spellings of provider options; later namespaced values win, top-level `reasoning` wins. */
export function flattenOpenRouterProviderOptions(
  options: StreamedModelProviderOptions | undefined,
): Record<string, unknown> {
  if (!isRecord(options)) return {};
  const { openrouter, providerOptions, ...topLevel } = options;
  const nested = isRecord(providerOptions) ? providerOptions.openrouter : undefined;
  const flattened: Record<string, unknown> = {
    ...topLevel,
    ...(isRecord(openrouter) ? openrouter : {}),
    ...(isRecord(nested) ? nested : {}),
  };
  if (topLevel.reasoning !== undefined) flattened.reasoning = topLevel.reasoning;
  return flattened;
}

/**
 * Translates an application request into OpenRouter's chat-completions shape
 * before the generic adapter serializes it. The explicit `reasoning` option
 * replaces the selected effort; `default` selects no reasoning field.
 */
export function toOpenRouterChatRequest(request: StreamedModelTurnRequest): StreamedModelTurnRequest {
  const customTool = request.tools.find((tool) => tool.type === 'custom');
  if (customTool) throw new Error(`OpenRouter chat transport does not support custom tool '${customTool.name}'.`);
  const providerOptions = flattenOpenRouterProviderOptions(request.providerOptions);
  const effort = request.reasoning?.effort;
  if (providerOptions.reasoning === undefined && effort && effort !== 'default') {
    providerOptions.reasoning = { effort };
  }
  return {
    ...request,
    reasoning: undefined,
    providerOptions,
    // `tool_choice` without tools is a 400 on OpenRouter; send it only alongside tools.
    toolChoice: request.tools.length > 0 ? request.toolChoice : undefined,
  };
}

/** Streams OpenRouter turns through the owned chat-completions adapter. */
export class OpenRouterChatModel implements StreamedModelTurn {
  private readonly inner: OpenAIChatCompletionsModel;

  constructor(inner: OpenAIChatCompletionsModel) {
    this.inner = inner;
  }

  stream(request: StreamedModelTurnRequest): AsyncIterable<StreamedModelTurnEvent> {
    return this.inner.stream(toOpenRouterChatRequest(request));
  }
}

/**
 * Creates the OpenAI client for OpenRouter. The SDK's transport retries are
 * disabled so `RetryingModel` stays the single retry owner, as it was for the
 * AI SDK path.
 */
export function createOpenRouterChatClient(options: ConstructorParameters<typeof OpenAI>[0]): OpenAI {
  const client = new OpenAI({ ...options, maxRetries: 0 });
  const completions = client.chat.completions;
  const create = completions.create.bind(completions) as (...args: unknown[]) => Promise<unknown>;
  (completions as { create: unknown }).create = async (...args: unknown[]) => {
    let result: unknown;
    try {
      result = await create(...args);
    } catch (error) {
      throw withRoutingDetail(error);
    }
    return surfaceInBandErrors(result);
  };
  return client;
}

/** HTTP error bodies keep OpenRouter's routing detail in the message; the SDK error class and status are unchanged. */
function withRoutingDetail(error: unknown): unknown {
  if (error instanceof APIError && error.status !== undefined) {
    const detail = describeOpenRouterErrorDetail(error.error);
    if (detail) error.message = `${error.message} (${detail})`;
  }
  return error;
}

/**
 * The SDK throws an in-band `error` frame from inside its stream iterator as an
 * `APIError` without a status. Convert it to an error chunk so the adapter's
 * single in-band path normalizes it (status, message, retry class). Closing the
 * wrapper forwards `return()`, which lets the SDK abort the HTTP request when
 * the consumer stops early.
 */
function surfaceInBandErrors(result: unknown): unknown {
  if (!result || typeof (result as AsyncIterable<unknown>)[Symbol.asyncIterator] !== 'function') return result;
  const stream = result as AsyncIterable<unknown>;
  return {
    [Symbol.asyncIterator]() {
      const iterator = stream[Symbol.asyncIterator]();
      let finished = false;
      return {
        async next(): Promise<IteratorResult<unknown>> {
          if (finished) return { done: true, value: undefined };
          try {
            return await iterator.next();
          } catch (error) {
            if (!(error instanceof APIError) || error.status !== undefined || error.error == null) throw error;
            finished = true;
            return { done: false, value: { error: error.error } };
          }
        },
        async return(value?: unknown): Promise<IteratorResult<unknown>> {
          finished = true;
          return (await iterator.return?.(value)) ?? { done: true, value };
        },
      };
    },
  };
}
