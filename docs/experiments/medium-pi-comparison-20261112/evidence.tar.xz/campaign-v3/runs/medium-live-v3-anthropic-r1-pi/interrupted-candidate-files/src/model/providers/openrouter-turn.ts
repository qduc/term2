import type { StreamedModelTurn, StreamedModelTurnEvent, StreamedModelTurnRequest } from '../streamed-model-turn.js';
import { OpenAICompatibleError } from './common/provider-errors.js';

/**
 * OpenRouter dialect over the Chat Completions adapter, the public surface of
 * the built-in OpenRouter lane (see `openrouter.provider.ts`):
 *
 * - `toOpenRouterTurnRequest` translates the request before the adapter sees it:
 *   provider options are flattened, explicit `reasoning` overrides the selected
 *   effort, and `tool_choice` is dropped when no tools are sent.
 * - `OpenRouterStreamedTurn` attaches the upstream provider OpenRouter reports
 *   on each frame to the completion's provider metadata, and appends the
 *   upstream error detail OpenRouter returns to an in-band or HTTP error.
 */

const UPSTREAM_DETAIL_LIMIT = 500;

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

/** OpenRouter's option wrappers: their contents are flattened and the keys are never sent. */
type OpenRouterOptionBag = Record<string, unknown> & {
  openrouter?: Record<string, unknown>;
  providerOptions?: { openrouter?: Record<string, unknown> };
  reasoning?: unknown;
};

/** Reasoning as OpenRouter spells it. `default` means the provider's own choice. */
function reasoningFromEffort(effort: string | null | undefined): { effort: string } | undefined {
  return effort && effort !== 'default' ? { effort } : undefined;
}

/**
 * Translates a request for the Chat Completions adapter. Provider options may
 * arrive top-level, under `openrouter`, or under `providerOptions.openrouter`;
 * they are flattened in that order, so later namespaced values win. A top-level
 * `reasoning` wins over namespaced reasoning. The adapter receives no
 * `reasoning` of its own, so it cannot emit `reasoning_effort`.
 */
function toOpenRouterTurnRequest(request: StreamedModelTurnRequest): StreamedModelTurnRequest {
  const { reasoning: selected, providerOptions, ...rest } = request;
  const {
    openrouter,
    providerOptions: nested,
    reasoning: explicitReasoning,
    ...topLevel
  } = (providerOptions ?? {}) as OpenRouterOptionBag;
  const { reasoning: namespacedReasoning, ...flattened } = {
    ...topLevel,
    ...(openrouter ?? {}),
    ...(nested?.openrouter ?? {}),
  };
  const reasoning = explicitReasoning ?? namespacedReasoning ?? reasoningFromEffort(selected?.effort);
  return {
    ...rest,
    // A tool choice without tools is rejected upstream, so it is sent only alongside tools.
    toolChoice: rest.tools.length ? rest.toolChoice : undefined,
    providerOptions: { ...flattened, ...(reasoning != null ? { reasoning } : {}) },
  };
}

/** The upstream provider OpenRouter reports on its stream frames (top-level `provider`). */
export class OpenRouterUpstreamCapture {
  #provider: string | undefined;

  /** Starts a new turn; a previous turn's upstream never leaks into this one. */
  reset(): void {
    this.#provider = undefined;
  }

  /** Records the first non-empty upstream name seen on a received frame. */
  readonly observe = (chunk: unknown): void => {
    if (this.#provider !== undefined) return;
    const provider = (chunk as { provider?: unknown } | null | undefined)?.provider;
    if (typeof provider === 'string' && provider.trim()) this.#provider = provider.trim();
  };

  get provider(): string | undefined {
    return this.#provider;
  }
}

/** Wraps the adapter's turn with OpenRouter request translation and routing metadata. */
export class OpenRouterStreamedTurn implements StreamedModelTurn {
  readonly #adapter: StreamedModelTurn;
  readonly #upstream: OpenRouterUpstreamCapture;

  constructor(adapter: StreamedModelTurn, upstream: OpenRouterUpstreamCapture) {
    this.#adapter = adapter;
    this.#upstream = upstream;
  }

  async *stream(request: StreamedModelTurnRequest): AsyncIterable<StreamedModelTurnEvent> {
    this.#upstream.reset();
    try {
      for await (const event of this.#adapter.stream(toOpenRouterTurnRequest(request))) {
        const provider = this.#upstream.provider;
        if (event.type === 'completion' && provider) {
          yield { ...event, providerMetadata: { openrouter: { provider } } };
        } else {
          yield event;
        }
      }
    } catch (error) {
      throw withUpstreamErrorDetail(error);
    }
  }
}

/**
 * Appends the upstream provider and raw upstream error to the message. The
 * status and class are untouched, so retry classification is unchanged.
 */
function withUpstreamErrorDetail(error: unknown): unknown {
  if (!(error instanceof Error)) return error;
  const detail = upstreamErrorDetail(upstreamErrorPayload(error));
  if (detail) error.message = `${error.message} (${detail})`;
  return error;
}

/** The OpenRouter error object: from an in-band frame, or from an HTTP error body. */
function upstreamErrorPayload(error: Error): Record<string, unknown> | undefined {
  if (error instanceof OpenAICompatibleError && typeof error.responseBody === 'string') {
    try {
      const parsed: unknown = JSON.parse(error.responseBody);
      return isRecord(parsed) ? parsed : undefined;
    } catch {
      return undefined;
    }
  }
  const body = (error as { error?: unknown }).error;
  if (!isRecord(body)) return undefined;
  return isRecord(body.error) ? body.error : body;
}

function upstreamErrorDetail(payload: Record<string, unknown> | undefined): string | undefined {
  const metadata = isRecord(payload?.metadata) ? payload.metadata : undefined;
  const provider = typeof metadata?.provider_name === 'string' ? metadata.provider_name.trim() : '';
  const raw = rawUpstreamText(metadata?.raw);
  const parts = [provider ? `upstream provider ${provider}` : '', raw ? `upstream error ${raw}` : ''].filter(Boolean);
  return parts.length ? parts.join(', ') : undefined;
}

/** A string raw is kept verbatim, an object as JSON; a null or empty raw carries nothing. */
function rawUpstreamText(raw: unknown): string | undefined {
  if (raw === null || raw === undefined) return undefined;
  const text = (typeof raw === 'string' ? raw : JSON.stringify(raw) ?? '').trim();
  if (!text) return undefined;
  return text.length > UPSTREAM_DETAIL_LIMIT ? `${text.slice(0, UPSTREAM_DETAIL_LIMIT)}…` : text;
}
