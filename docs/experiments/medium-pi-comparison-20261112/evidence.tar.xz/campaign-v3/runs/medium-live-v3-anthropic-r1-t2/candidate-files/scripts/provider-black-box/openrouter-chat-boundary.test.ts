import { afterEach, describe, expect, it, vi } from 'vitest';
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import OpenAI from 'openai';
import { getProvider } from '../../src/model/providers/registry.js';
import '../../src/model/providers/index.js';
import { OpenAIChatCompletionsModel } from '../../src/model/providers/openai-chat-completions-model.js';
import type { ILoggingService, ISettingsService, IProviderTraffic } from '../../src/shared/service-interfaces.js';
import type { StreamedModelTurnEvent, StreamedModelTurnRequest } from '../../src/model/streamed-model-turn.js';
import { fixtureRequest, fixtureTool } from './provider-wire-fixtures.js';

/**
 * OpenRouter boundary behaviour over real loopback HTTP. The server is a
 * scripted chat-completions endpoint: each test decides the status, frames and
 * whether the connection closes, so the wire shape under test is what the
 * production OpenAI client actually sends and receives.
 */

type Captured = { headers: IncomingMessage['headers']; body: any };
type Script = (req: IncomingMessage, res: ServerResponse, body: any, index: number) => void;

const servers: Array<{ close(): void }> = [];

afterEach(() => {
  for (const server of servers.splice(0)) server.close();
});

async function startScripted(script: Script) {
  const requests: Captured[] = [];
  const sockets = new Set<import('node:net').Socket>();
  const server = createServer((req, res) => {
    let raw = '';
    req.setEncoding('utf8');
    req.on('data', (chunk) => (raw += chunk));
    req.on('end', () => {
      const body = raw ? JSON.parse(raw) : undefined;
      requests.push({ headers: req.headers, body });
      script(req, res, body, requests.length - 1);
    });
  });
  server.on('connection', (socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address() as { port: number };
  const handle = {
    baseUrl: `http://127.0.0.1:${port}/api/v1`,
    requests,
    close() {
      for (const socket of sockets) socket.destroy();
      server.close();
    },
  };
  servers.push(handle);
  return handle;
}

function sseHeaders(res: ServerResponse) {
  res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache' });
}

function writeFrames(res: ServerResponse, frames: unknown[], end = true) {
  sseHeaders(res);
  for (const frame of frames) res.write(`data: ${JSON.stringify(frame)}\n\n`);
  if (end) {
    res.write('data: [DONE]\n\n');
    res.end();
  }
}

const stopChunk = (delta: Record<string, unknown> = {}, extra: Record<string, unknown> = {}) => ({
  id: 'gen_fixture',
  object: 'chat.completion.chunk',
  choices: [{ index: 0, delta, finish_reason: 'stop' }],
  ...extra,
});

const quietLogging = (providerTraffic?: IProviderTraffic): ILoggingService =>
  ({
    info() {},
    warn() {},
    error() {},
    debug() {},
    security() {},
    setCorrelationId() {},
    getCorrelationId() {
      return undefined;
    },
    clearCorrelationId() {},
    ...(providerTraffic ? { providerTraffic } : {}),
  } as unknown as ILoggingService);

function settingsFor(baseUrl: string, extra: Record<string, unknown> = {}): ISettingsService {
  const values: Record<string, unknown> = {
    'agent.modelSelection': { model: 'fixture/provider', provider: 'openrouter' },
    'agent.retryAttempts': 0,
    'agent.openrouter.apiKey': 'fixture-key',
    'agent.openrouter.baseUrl': baseUrl,
    'agent.openrouter.referrer': 'https://fixture.test',
    'agent.openrouter.title': 'boundary-test',
    ...extra,
  };
  return {
    get: (key: string) => values[key] as never,
    getDynamic: () => [],
    set() {},
    setDynamic() {},
    setPersistent() {},
    setPersistentDynamic() {},
  } as unknown as ISettingsService;
}

async function openRouterModel(baseUrl: string, loggingService: ILoggingService = quietLogging()) {
  const provider = getProvider('openrouter')!;
  return provider.createStreamedModel!('fixture/provider', {
    settingsService: settingsFor(baseUrl),
    loggingService,
    retryAttempts: 0,
  });
}

const request = (overrides: Partial<StreamedModelTurnRequest> = {}): StreamedModelTurnRequest => ({
  ...fixtureRequest,
  reasoning: undefined,
  ...overrides,
});

async function collect(stream: AsyncIterable<StreamedModelTurnEvent>): Promise<StreamedModelTurnEvent[]> {
  const events: StreamedModelTurnEvent[] = [];
  for await (const event of stream) events.push(event);
  return events;
}

const okFrames = [{ id: 'gen_fixture', choices: [{ index: 0, delta: { content: 'ok' }, finish_reason: 'stop' }] }];

describe('OpenRouter chat-completions boundary', () => {
  it('sends selected effort as reasoning:{effort}, never reasoning_effort, and skips the default effort', async () => {
    const server = await startScripted((_req, res) => writeFrames(res, okFrames));
    const model = await openRouterModel(server.baseUrl);

    await collect(model.stream(request({ reasoning: { effort: 'high' } })));
    expect(server.requests[0]!.body.reasoning).toEqual({ effort: 'high' });
    expect(server.requests[0]!.body).not.toHaveProperty('reasoning_effort');

    await collect(model.stream(request({ reasoning: { effort: 'default' } })));
    expect(server.requests[1]!.body).not.toHaveProperty('reasoning');
    expect(server.requests[1]!.body).not.toHaveProperty('reasoning_effort');
  });

  it('flattens provider options with namespaced precedence and keeps wrapper keys off the wire', async () => {
    const server = await startScripted((_req, res) => writeFrames(res, okFrames));
    const model = await openRouterModel(server.baseUrl);

    await collect(
      model.stream(
        request({
          reasoning: { effort: 'high' },
          providerOptions: {
            seed: 3,
            transforms: ['top'],
            openrouter: { reasoning: { effort: 'low' }, transforms: ['direct'], user: 'direct-user' },
            providerOptions: { openrouter: { transforms: ['nested'] } },
          },
        }),
      ),
    );
    const body = server.requests[0]!.body;
    expect(body.reasoning).toEqual({ effort: 'low' });
    expect(body.transforms).toEqual(['nested']);
    expect(body.user).toBe('direct-user');
    expect(body.seed).toBe(3);
    expect(body).not.toHaveProperty('openrouter');
    expect(body).not.toHaveProperty('providerOptions');
    expect(body).not.toHaveProperty('reasoning_effort');
  });

  it('lets a top-level reasoning option win over namespaced reasoning', async () => {
    const server = await startScripted((_req, res) => writeFrames(res, okFrames));
    const model = await openRouterModel(server.baseUrl);

    await collect(
      model.stream(
        request({
          providerOptions: { reasoning: { max_tokens: 100 }, openrouter: { reasoning: { effort: 'low' } } },
        }),
      ),
    );
    expect(server.requests[0]!.body.reasoning).toEqual({ max_tokens: 100 });
  });

  it('sends the API key and the referrer and title headers', async () => {
    const server = await startScripted((_req, res) => writeFrames(res, okFrames));
    const model = await openRouterModel(server.baseUrl);

    await collect(model.stream(request()));
    const headers = server.requests[0]!.headers;
    expect(headers.authorization).toBe('Bearer fixture-key');
    expect(headers['http-referer']).toBe('https://fixture.test');
    expect(headers['x-title']).toBe('boundary-test');
    expect(headers['x-openrouter-title']).toBe('boundary-test');
  });

  it('sends tool_choice only when tools exist', async () => {
    const server = await startScripted((_req, res) => writeFrames(res, okFrames));
    const model = await openRouterModel(server.baseUrl);

    await collect(model.stream(request({ tools: [], toolChoice: 'auto' })));
    expect(server.requests[0]!.body).not.toHaveProperty('tool_choice');
    expect(server.requests[0]!.body).not.toHaveProperty('tools');

    await collect(model.stream(request({ toolChoice: 'none' })));
    expect(server.requests[1]!.body).toMatchObject({
      tool_choice: 'none',
      tools: [{ function: { name: fixtureTool.name } }],
    });
  });

  it('reports the upstream provider in completion metadata for OpenRouter only', async () => {
    const server = await startScripted((_req, res) =>
      writeFrames(res, [
        { id: 'gen_fixture', provider: 'CoreWeave', choices: [{ index: 0, delta: { content: 'ok' } }] },
        stopChunk(),
      ]),
    );
    const model = await openRouterModel(server.baseUrl);
    const events = await collect(model.stream(request()));
    expect(events.at(-1)).toMatchObject({
      type: 'completion',
      providerMetadata: { openrouter: { provider: 'CoreWeave' } },
    });

    const generic = new OpenAIChatCompletionsModel(
      new OpenAI({ apiKey: 'fixture-key', baseURL: server.baseUrl, maxRetries: 0 }),
      'generic-model',
      undefined,
      'generic-gateway',
    );
    const genericEvents = await collect(generic.stream(request()));
    expect(genericEvents.at(-1)).toMatchObject({ type: 'completion' });
    expect(genericEvents.at(-1)).not.toHaveProperty('providerMetadata');
  });

  it('surfaces in-band upstream error detail from metadata, skipping null raw values', async () => {
    const server = await startScripted((_req, res, _body, index) =>
      writeFrames(
        res,
        [
          {
            error: {
              code: 502,
              message: 'Provider returned error',
              metadata: { provider_name: 'CoreWeave', raw: index === 0 ? { message: 'Model is at capacity' } : null },
            },
          },
        ],
        true,
      ),
    );
    const model = await openRouterModel(server.baseUrl);
    const first = await collect(model.stream(request())).catch((error: Error) => error);
    expect(first).toMatchObject({ status: 502, message: '[CoreWeave] Model is at capacity' });

    const second = await collect(model.stream(request())).catch((error: Error) => error);
    expect(second).toMatchObject({ status: 502, message: '[CoreWeave] Provider returned error' });
  });

  it('adds upstream detail to HTTP error messages and makes one physical attempt (retries stay with RetryingModel)', async () => {
    const server = await startScripted((_req, res) => {
      res.writeHead(400, { 'content-type': 'application/json' });
      res.end(
        JSON.stringify({
          error: {
            code: 400,
            message: 'Provider returned error',
            metadata: { provider_name: 'CoreWeave', raw: '{"error":{"message":"bad input"}}' },
          },
        }),
      );
    });
    const model = await openRouterModel(server.baseUrl);
    const failure = await collect(model.stream(request())).catch((error: Error) => error);
    expect(failure).toBeInstanceOf(Error);
    expect((failure as Error).message).toBe('400 [CoreWeave] bad input');
    expect(server.requests).toHaveLength(1);
  });

  it('streams reasoning text and reasoning_details, and replays reasoning_details on the next request', async () => {
    const details = (text: string) => [{ type: 'reasoning.text', text, format: 'openrouter-fixture-v1', index: 0 }];
    const server = await startScripted((_req, res, _body, index) =>
      index === 0
        ? writeFrames(res, [
            {
              id: 'gen_a',
              choices: [{ index: 0, delta: { reasoning: 'Thinking. ', reasoning_details: details('Thinking. ') } }],
            },
            { id: 'gen_a', choices: [{ index: 0, delta: { reasoning_details: details('More') } }] },
            { id: 'gen_a', choices: [{ index: 0, delta: { content: 'answer' }, finish_reason: 'stop' }] },
          ])
        : writeFrames(res, okFrames),
    );
    const model = await openRouterModel(server.baseUrl);

    const events = await collect(model.stream(request()));
    expect(events.filter((event) => event.type === 'reasoning_delta').map((event) => (event as any).text)).toEqual([
      'Thinking. ',
    ]);
    expect(events.filter((event) => event.type === 'text_delta')).toEqual([{ type: 'text_delta', text: 'answer' }]);
    const completion = events.at(-1) as Extract<StreamedModelTurnEvent, { type: 'completion' }>;
    const opaque = completion.output.find((item) => item.type === 'provider_opaque') as any;
    expect(opaque).toMatchObject({ provider: 'openrouter', item: { reasoning_details: [{ text: 'Thinking. More' }] } });

    await collect(
      model.stream(
        request({
          input: [
            { type: 'message', role: 'user', content: [{ type: 'text', text: 'look up' }] },
            { type: 'reasoning', text: 'Thinking. ' },
            { type: 'provider_opaque', provider: 'openrouter', item: opaque.item },
            { type: 'tool_call', id: 'call_1', name: fixtureTool.name, arguments: '{"a":1}' },
            { type: 'tool_result', id: 'call_1', output: 'ok' },
          ],
        }),
      ),
    );
    const replayed = server.requests[1]!.body.messages.find((message: any) => message.role === 'assistant');
    expect(replayed.reasoning_details).toEqual([
      { type: 'reasoning.text', text: 'Thinking. More', format: 'openrouter-fixture-v1', index: 0 },
    ]);
  });

  it('settles an in-band error held open when no traffic recorder drains the response', async () => {
    const server = await startScripted((_req, res) => {
      sseHeaders(res);
      res.write(`data: ${JSON.stringify({ error: { code: 502, message: 'Model is at capacity' } })}\n\n`);
      // Deliberately never ends the response: the adapter must cancel it itself.
    });
    const model = await openRouterModel(server.baseUrl);
    let settled = 'pending';
    collect(model.stream(request())).then(
      () => (settled = 'completed'),
      (error: Error) => (settled = `rejected:${error.message}`),
    );
    await vi.waitFor(() => expect(settled).not.toBe('pending'), { timeout: 5000 });
    expect(settled).toBe('rejected:Model is at capacity');
  });

  it('keeps an in-band error frame for an active recorder once the error stream closes', async () => {
    const server = await startScripted((_req, res) => {
      writeFrames(res, [{ error: { code: 502, message: 'Model is at capacity' } }]);
    });
    let recorded = '';
    const traffic: IProviderTraffic = {
      recordRequestStart() {},
      async recordResponseReceived(input: any) {
        recorded = await input.response.text();
      },
      recordResponseClosed() {},
      recordRequestFailed() {},
    } as unknown as IProviderTraffic;
    const provider = getProvider('openrouter')!;
    const model = await provider.createStreamedModel!('fixture/provider', {
      settingsService: settingsFor(server.baseUrl),
      loggingService: quietLogging(traffic),
      retryAttempts: 0,
    });
    await expect(collect(model.stream(request()))).rejects.toThrow('Model is at capacity');
    await vi.waitFor(() => expect(recorded).toContain('Model is at capacity'), { timeout: 5000 });
  });
});
