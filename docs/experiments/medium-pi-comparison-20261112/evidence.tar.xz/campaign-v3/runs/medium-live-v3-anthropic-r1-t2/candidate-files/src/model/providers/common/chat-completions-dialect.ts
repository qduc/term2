import { isRecord, normalizeChatCompletionError } from './openai-chat-completions-errors.js';

/**
 * Gateway dialect seam of the application-owned chat-completions adapter. A
 * gateway (OpenRouter today) supplies only the spellings it differs on; generic
 * endpoints use no dialect and keep the plain `reasoning_effort` wire.
 */
export interface ChatCompletionsDialect {
  /** Body fields expressing the selected reasoning effort. */
  reasoningFields(effort: string): Record<string, unknown>;
  /** Efforts that send no reasoning field at all. */
  skipReasoningEffort?(effort: string): boolean;
  /** Maps caller provider options to body fields; they are spread last, so they win. */
  providerOptionFields?(options: Record<string, unknown>): Record<string, unknown>;
  /** Send `tool_choice` only when the request carries tools. */
  omitToolChoiceWithoutTools?: boolean;
  /** Upstream provider the gateway reports on a chunk. */
  upstreamProvider?(chunk: unknown): string | undefined;
  /** Namespace under which the upstream provider is reported in completion metadata. */
  upstreamProviderKey?: string;
  /** Upstream detail for an error payload; used as the error message when present. */
  describeError?(error: unknown): string | undefined;
}

/**
 * The OpenAI client throws an error without an HTTP status when an SSE frame
 * carries an `error` body (an in-band failure). A gateway dialect maps that
 * error to the application error the retry policy classifies; generic
 * endpoints keep the client's error unchanged.
 */
export async function* surfaceInBandErrors<T>(
  stream: AsyncIterable<T>,
  dialect?: ChatCompletionsDialect,
): AsyncGenerator<T> {
  try {
    yield* stream;
  } catch (error) {
    const body = (error as { error?: unknown } | null)?.error;
    const inBand = (error as { status?: unknown } | null)?.status === undefined && isRecord(body);
    if (dialect && inBand) throw normalizeChatCompletionError(body, dialect.describeError);
    throw error;
  }
}
