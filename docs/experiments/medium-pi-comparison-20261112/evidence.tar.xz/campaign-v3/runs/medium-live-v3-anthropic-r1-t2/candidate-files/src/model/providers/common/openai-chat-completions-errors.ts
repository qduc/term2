import { OpenAICompatibleError } from './provider-errors.js';
import type { ChatCompletionsDialect } from './chat-completions-dialect.js';

/**
 * Maps an in-band chat-completions error payload to the application error the
 * retry policy classifies. `describe` lets a gateway dialect contribute upstream
 * detail to the message; without it the generic message is used.
 */
export function normalizeChatCompletionError(
  error: unknown,
  describe?: (error: unknown) => string | undefined,
): OpenAICompatibleError {
  const record = isRecord(error) ? error : undefined;
  const nested = record && isRecord(record.error) ? record.error : undefined;
  const code = record?.code ?? record?.status ?? record?.statusCode ?? nested?.code ?? nested?.status;
  const numericStatus =
    typeof code === 'number' && Number.isInteger(code)
      ? code
      : typeof code === 'string' && /^\d+$/.test(code.trim())
      ? Number(code)
      : undefined;
  const symbolicCode = typeof code === 'string' ? code.toLowerCase() : '';
  const status =
    numericStatus ??
    (symbolicCode.includes('rate_limit') || symbolicCode.includes('too_many_requests')
      ? 429
      : symbolicCode.includes('invalid')
      ? 400
      : symbolicCode.includes('auth')
      ? 401
      : symbolicCode.includes('permission')
      ? 403
      : symbolicCode.includes('not_found')
      ? 404
      : 502);
  const message =
    describe?.(error) ||
    (typeof record?.message === 'string' && record.message) ||
    (typeof nested?.message === 'string' && nested.message) ||
    (typeof error === 'string' ? error : 'OpenAI-compatible provider returned an in-band error');
  let responseBody: string | undefined;
  try {
    responseBody = JSON.stringify(error);
  } catch {
    responseBody = undefined;
  }
  return new OpenAICompatibleError(message, status, {}, responseBody);
}

export const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

/** Adds gateway-reported upstream detail to an HTTP error message, keeping its class and status. */
export function withDialectErrorDetail(error: unknown, dialect?: ChatCompletionsDialect): unknown {
  const body = (error as { error?: unknown } | null)?.error;
  const status = (error as { status?: unknown } | null)?.status;
  if (!dialect?.describeError || !isRecord(body) || !isRecord(body.metadata) || typeof status !== 'number')
    return error;
  const detail = dialect.describeError(body);
  if (detail && error instanceof Error) error.message = `${status} ${detail}`;
  return error;
}
