/**
 * OpenRouter's dialect of the application-owned chat-completions adapter.
 *
 * The adapter (`openai-chat-completions-model.ts`) speaks the generic wire.
 * This module supplies only what OpenRouter spells differently: reasoning is
 * `reasoning: { effort }`, provider options may arrive under `openrouter` or
 * `providerOptions.openrouter`, the upstream provider is reported on the stream
 * chunk, and error payloads carry `metadata.provider_name` and `metadata.raw`.
 */
import type { ChatCompletionsDialect } from './common/chat-completions-dialect.js';

const WRAPPER_KEYS = new Set(['openrouter', 'providerOptions']);

/**
 * Flattens OpenRouter provider options into request-body fields.
 *
 * Precedence: top-level keys, then `openrouter`, then `providerOptions.openrouter`
 * (later namespaces win). A top-level `reasoning` wins over any namespaced one.
 * The wrapper keys themselves never reach the wire.
 */
function flattenOpenRouterOptions(options: Record<string, unknown> | undefined): Record<string, unknown> {
  if (!options) return {};
  const top: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(options)) {
    if (!WRAPPER_KEYS.has(key)) top[key] = value;
  }
  const direct = asRecord(options.openrouter) ?? {};
  const nested = asRecord(asRecord(options.providerOptions)?.openrouter) ?? {};
  const flattened: Record<string, unknown> = { ...top, ...direct, ...nested };
  if (top.reasoning !== undefined) flattened.reasoning = top.reasoning;
  return flattened;
}

/**
 * Formats an OpenRouter error the way its SDK did: `[provider] <raw message>`,
 * where the raw message is taken from `metadata.raw` (a string, a JSON string,
 * or an object with a message-like field). A null or absent raw value is skipped.
 */
function describeOpenRouterError(error: unknown): string | undefined {
  const record = asRecord(error);
  const message = typeof record?.message === 'string' ? record.message : undefined;
  const metadata = asRecord(record?.metadata);
  if (!metadata) return message;
  const parts: string[] = [];
  if (typeof metadata.provider_name === 'string' && metadata.provider_name) parts.push(`[${metadata.provider_name}]`);
  const rawMessage = extractRawMessage(metadata.raw);
  parts.push(rawMessage && rawMessage !== message ? rawMessage : message ?? '');
  const joined = parts.filter(Boolean).join(' ');
  return joined || undefined;
}

function extractRawMessage(raw: unknown): string | undefined {
  if (typeof raw === 'string') {
    try {
      const parsed: unknown = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return extractRawMessage(parsed);
    } catch {
      /* not JSON: the string is the message */
    }
    return raw || undefined;
  }
  const obj = asRecord(raw);
  if (!obj) return undefined;
  for (const field of ['message', 'error', 'detail', 'details', 'msg']) {
    const value = obj[field];
    if (typeof value === 'string' && value.length > 0) return value;
    if (value && typeof value === 'object') {
      const nested = extractRawMessage(value);
      if (nested) return nested;
    }
  }
  return undefined;
}

/** Upstream provider name OpenRouter reports on a stream chunk, if any. */
function upstreamProviderOf(chunk: unknown): string | undefined {
  const provider = asRecord(chunk)?.provider;
  return typeof provider === 'string' && provider.trim() ? provider.trim() : undefined;
}

const asRecord = (value: unknown): Record<string, unknown> | undefined =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : undefined;

/** The OpenRouter dialect of the chat-completions adapter. */
export function createOpenRouterChatDialect(): ChatCompletionsDialect {
  return {
    reasoningFields: (effort) => ({ reasoning: { effort } }),
    skipReasoningEffort: (effort) => effort === 'default',
    providerOptionFields: flattenOpenRouterOptions,
    omitToolChoiceWithoutTools: true,
    upstreamProvider: upstreamProviderOf,
    describeError: describeOpenRouterError,
    upstreamProviderKey: 'openrouter',
  };
}
