## [Unreleased]

### Improvements
- The built-in OpenRouter provider runs on the application's chat-completions adapter; the `@openrouter/ai-sdk-provider` dependency is removed. Reasoning effort is sent as OpenRouter's `reasoning` object, and provider options from the top level, `openrouter` or `providerOptions.openrouter` are flattened into the request. `tool_choice` is sent only with tools. The upstream provider OpenRouter reports is kept in completion metadata, and in-band errors include the upstream provider and its detail.

### Bug Fixes
- A chat-completions in-band error no longer waits forever on a stream when no traffic recorder is attached. Cancelling an OpenRouter stream is reported as a cancellation rather than as a stream that ended without a finish reason.

## [1.1.0] - 2026-11-10

### Features
- **Stable ACP v1 for editors.** `term2 acp` now also serves ACP v1 clients such as JetBrains Air and Zed; the protocol version is chosen from the editor's `initialize` request, with no extra flag. V1 sessions support new/list/load/resume/close, prompts, cancellation, tool permissions, form-based questions and budget pauses, and forwarded stdio/HTTP/SSE MCP servers (#231).
- ACP v1 sessions offer **Model**, **Thinking level** and **Approval mode** selectors. Model and thinking-level changes apply only to that session and persist across load/resume. Approval mode (Ask, Assisted, or Always · Sandbox off) is live-session only and resets to Ask when the runtime reopens (#231).
- The task panel shows the model each subagent is running (#229).

### Improvements
- ACP turn failures return a client-facing JSON-RPC error with structured `kind` and `retryable` fields, without forwarding private provider response text (#231).
- In ACP v1, a sandboxed foreground shell asks the editor for permission only when a command explicitly requests to run outside the sandbox once (#231).
- ACP sessions open even when a configured MCP server is unavailable (#231).
- Website guides were reorganized around tasks (#236, #237).

### Bug Fixes
- Fix ACP v1 prompt echoes and tool-invocation display, and interoperability issues with Air and Zed (#231).

## [1.0.0] - 2026-11-08

### Breaking Changes
- **Node.js 24 or newer is required.** `engines.node` is now `>=24`, matching the only version CI and the publish workflow test.
- **New runtime and conversation store.** term2 now runs on the rewritten "next" runtime (#86) and saves conversations in a separate `conversations-next` data directory. The old `conversations` directory is never written to and is not read automatically, so conversations saved by 0.40.0 and earlier do not appear in `term2 --resume ls` after upgrading.
- **Profiles removed.** Plan, Pair, Mentor and Orchestrator are gone (#149), along with `/plan` and the `Shift+Tab` plan toggle. Saved settings and sessions that name a removed profile fall back to Bare without rewriting their history. Standard/`full` and Lite also resolve to Bare.
- **Discord peer relays are agent data.** A session's routed response no longer inherits the originating human's authority or steers a busy peer. The original message remains attached as provenance and the peer receives a queued follow-up.

### Improvements
- Startup reaches an idle composer about 35% sooner by loading startup-only work on demand and caching compiled bundle code (#192, #195).

### Bug Fixes
- Require the shell sandbox in ACP sessions even when saved settings disable it; retain cancellation received during prompt admission replay accepted nested branch history, and retain human/system provenance on nested interaction answers. Expanded SDK 1.4.0 experimental/v2 process and native-session coverage includes real sandboxed tool execution, fail-closed permission replies and a packed-install Gemini smoke.
- Correct ACP embedded text-resource handling and capability advertisement, gate question/budget forms on client support, and synchronize activity on resume and around native interactions. Preserve SDK 1.4.0 experimental v2 wire shapes.
- Fix native web/BFF pairing races, idle stream connection, accepted user-message delivery, truncated-frame checkpoints, native interaction IDs, settled abort responses and result-only hydration. Preserve native command/replay errors and remove unsupported profile choices. Enable native browser v2 with wire 0.2.3, preserving background task questions, tool tracking and activity observations (#80).
- Restore per-session cost accounting and the footer cost display.
- Resume native sessions after changes to a built-in profile, and accept additional older provider and profile formats when migrating copied conversation stores.
- Honor startup settings for shared tool output limits (#178).
- Suppress notices for denied recovery retries (#177).
- Validate messages imported from the session browser (#176).
- Honor summary replacement metadata at compaction boundaries, and preserve launch intent and compaction boundaries on resume (#174, #175).
- Hide live reasoning in concise display mode (#161).

### Upgrading from 0.40.x
- Back up your term2 data directory before upgrading. Older versions cannot be assumed to read data written by this release.
- Old conversations stay where they were and are not deleted. They can be converted with the standalone migrator, `scripts/migrate-conversations.mjs`, which currently ships only in a source checkout, not in the npm package. It works on a **copy** of the old directory; see `scripts/conversation-migration/migration-command.md` for the required flags.
- Re-check `--profile` flags and saved profile settings if you used a removed profile.

## [0.40.0] - 2026-10-29

### Features
- Enable subagent delegation in the Bare profile while retaining its minimal shell-led prompt.
- Add `/restart` to reload the supported built CLI in place and resume the conversation with durable queued-text recovery (not unsaved editor drafts). `/restart stop` explicitly consents to stopping live background work. Requires POSIX Node with `process.execve` support and a built `dist/cli.js` entry; Windows, Node flags/loaders, and `NODE_OPTIONS` are unsupported. Active workspace leases reset to home scope; non-durable pending input must be handled before restart.

### Improvements
- The Discord bridge now uses a Gateway connection as a wake-up signal, so new messages are read immediately instead of on the next one-second poll; REST reads drop to a 30-second safety poll while push is connected. Content still comes only from the cursor-based REST read. Set `TERM2_DISCORD_GATEWAY=off` to keep polling only. Live Discord/mobile validation remains outstanding.

### Bug Fixes
- Preserve Discord ingress while the configured default coordinator is unavailable, and improve bridge transport and shutdown cleanup.
- Admit read-only gateway grants on physically writable directories without widening write authority, and propagate the launcher's write policy to the runtime. Read-only gateway sessions refuse shell execution outside the sandbox, including when the sandbox is disabled or execution uses SSH.
- Restore recorded tool-result bodies and stopped partial replies on gateway session reload, replay in-flight turns from their start, improve reconnect/backpressure handling, and forward all multi-question answers.
- Reject publication with a dirty, untagged, stale, or mismatched build identity. The local publish route rebuilds after creating or reusing the exact release tag; this does not repair the already-published 0.39.0 artifact.

### Separate Web Client
- Refresh Markdown/code rendering, grouped tool calls, composer/sidebar layout, workspace selection, multi-select questions, and reload recovery in the private Next.js `web-client/` app. This frontend is not included in the npm CLI package; update and rebuild it separately. Gateway backend fixes above ship with the CLI.

## [0.39.0] - 2026-10-27

### Features
- Added an opt-in Discord bridge for existing interactive sessions, with allowlisted users and channels, private token enrollment, runtime `/bridge connect` attachment, and explicit `discord_send` replies. Approvals and questions remain local; real-account Discord/mobile validation is still outstanding.

### Improvements
- Model and subagent-pool pickers share catalog loading and isolate provider discovery failures; first-run provider setup proceeds to model selection.
- Active-task menus keep task labels compact and allow foreground work to transfer to the background. Model-waiting and reasoning phases now have distinct labels, and rollover and shell notifications are more concise.
- Bare uses a smaller shell-led prompt with project instructions included and image reading available; Lite remains a compatibility alias for Bare.
- Removed the extra idle uncached-input confirmation; normal context-fit, budget, and approval controls remain in place.

### Bug Fixes
- Preserve public session identity and creation time across internal context rollover, and retain queued input ownership when continuing after rollover.
- Recover repeated tool-call occurrences without collapsing distinct calls that reuse an identifier.
- Retry typed zero-frame session timeouts and Codex capacity failures within the configured retry budget.
- Honor injected provider registries when constructing agent clients.
- Keep explicit durable-goal completion and rejected Discord bridge-result queries on their intended completion and recovery paths.

## [0.38.0] - 2026-10-24

### Features
- Continue saved conversations non-interactively with `term2 --resume <session-id> "Follow-up prompt"` or `--resume last`, including JSON output and forked continuations. Restored history, session identity, reasoning settings, and provenance are preserved; missing sessions fail explicitly.

### Improvements
- Lite is now a compatibility alias for Bare across CLI flags, slash commands, saved settings, and session restoration. Bare reads project instructions on demand and exposes selected web, memory, session, MCP, and background-task capabilities through `run_code` while keeping shell directly available.
- Explicit `session_read` requests resolve only the matching session-reference bucket instead of refreshing the full project search index, with canonical replay performed off the main thread.

### Bug Fixes
- Removing the last retained queued item, or restoring an empty paused queue, releases the pause so later submissions can run.
- Defer terminal renderer loading until interactive startup, avoiding unnecessary renderer initialization for headless CLI commands.

### Internal/Chores
- Added bounded generated verification for history, queue, tool-ledger, and additional runtime boundaries, with replayable seeds and retained verification evidence.
- Repaired macOS and temporary-directory assumptions in integration and end-to-end fixtures.

## [0.37.0] - 2026-10-24

### Features
- Local context compaction prefers a one-shot summary request over the live conversation prefix when the full request fits the model input window, preserving prompt-cache and transport affinity on Codex, Grok, and OpenCode while falling back to the bounded chunk reducer for larger histories.
- The Bare profile presents a foreground-only `shell` tool schema and batching guidance while keeping the full canonical schema for runtime parameter normalization and approval checks.

### Improvements
- `/resume` and `term2 --resume` sort conversation files by modification time before reading and bound full log parsing to the requested limit.

### Bug Fixes
- Local context compaction caps the verbatim hot tail at 16,000 tokens, applies that budget to whole-turn retention, and falls back to the newest settled round when a single round exceeds the budget.
- Local context compaction renders up to 40 recent tool receipts as a one-line digest outside `<summary>` (with full paths extracted before argument truncation) instead of re-feeding raw JSON receipts into later summaries, and anchors legacy receipt stripping so summary prose mentioning the tag is preserved.
- Native Codex freeform `apply_patch` tool calls return `{ patch }` matching the canonical tool schema instead of failing schema validation with `{ operations }` before any file write.
- The interactive banner and status bar resolve profile labels (`Bare`, `Pair`, etc.) directly from the built-in profile registry instead of falling back to `Standard`.

## [0.36.0] - 2026-10-23

### Features
- The Bare profile now includes the skills catalog and `activate_skill` capability, plus the environment context source.

### Bug Fixes
- Logging no longer crashes the process on disk failures (ENOSPC/EACCES): a failed file sink is disabled after one visible warning, provider-traffic capture fails open, and critical conversation journal writes still fail fast with a warning.
- Removed Winston sinks no longer emit per-record stderr warnings or buffer unread records after the final transport fails.
- Startup now prunes rotated application logs and dated provider-traffic folders older than 7 days or beyond 512 MiB per directory, keeping current-day logs; application log retention follows local dates to match rotated file names.
- Sandbox blocked-read approval answers (deny, allow once, Escape, auto mode) are routed to the correct post-execute decision instead of an uninstalled wait.
- Session rollover is deferred while a queued submission owns the queue, and a rollover that fails reports the error and preserves the handoff brief for manual retry.

## [0.35.0] - 2026-10-22

### Features
- Added the opt-in `bare` profile (`--profile bare`, `/profile bare`, `profiles.active: "bare"`), providing a minimal system prompt baseline while retaining codebase tool access, system invariants, and completion verification safeguards.
- Added `--profile <name>` CLI option to select an operating profile (`full`, `bare`, `lite`, `plan`, `pair`, `mentor`, `orchestrator`) directly on startup.
- Added `agent.backgroundWaitTimeoutMs` setting to configure the overall wait limit for headless background tasks (default 1 hour), terminating and reporting unfinished work when exceeded.
- Added `verifier.model` setting allowing an independent verifier model to be designated for completion verification.

### Improvements
- Headless non-interactive workflows with durable goals run unattended: when completion verification passes, the workflow stops cleanly without prompting or stalling.
- Provider selection menu (`/providers`) removes the redundant "(disabled)" text suffix on disabled provider rows.

### Bug Fixes
- Fixed Bare profile initialization during interactive session startup so system prompt generation and legacy mode adapters handle bare mode properly.
- Fixed authorized reference approval context evaluation in headless runs so references in approval prompts are resolved correctly.

## [0.34.0] - 2026-10-19

### Features
- Durable goal completion can now be gated by adaptive independent verification before being marked achieved, evaluating actual changes against the stated outcome and criteria (`agent.completionVerification`).
- Expose runtime model and provider discovery to agents and `run_code` scripts via `list_models`, supporting pagination, credential readiness checks, and session usage stats.
- Declarative provider presets inventory for streamlined provider connection and custom endpoint configuration.

### Improvements
- The `/settings` menu is reorganized into curated tabs (Models, Providers, Context, Safety, Tools, UI, Hooks) with human-readable labels, dollar-denominated run budget inputs, masked sensitive API keys, and in-place boolean toggling. Advanced settings are tagged and discoverable via search.
- Upstream Grok client versions are resolved dynamically to prevent 426 upgrade rejections.
- Consolidated web and skill tool construction for root and child agent assemblies.

### Bug Fixes
- Providers returning unrecognized bodies with HTTP 200 (such as error payloads) surface descriptive errors instead of silently producing an empty model catalog.
- Fixed handling of null model list items when parsing OrcaRouter models.

### Internal/Chores
- Updated upstream model catalog.
- Added test coverage for Codex approval crash recovery.

## [0.33.0] - 2026-10-18

### Features
- `tools.shell` is now available inside `run_code` scripts with shared sandbox policy, approval prompts, timeouts, output monitors, and background job tracking.

### Improvements
- The interactive model picker (`Ctrl+O`) displays providers in a grouped leading column on the unified models and favorites tabs.
- Model catalogs for custom OpenAI-compatible providers and OrcaRouter filter out models that do not support text generation.

### Internal/Chores
- Isolated provider policies and catalog adapters into their owning modules.
- Refactored the core conversation engine around a single model-tool execution loop, consolidating turn execution, session projection, and conversation acceptance in `ConversationRecord`.

## [0.32.2] - 2026-10-17

### Bug Fixes
- Gemini tool-call thought signatures are preserved when replaying conversation history, avoiding rejected tool continuations.
- Gemini rate-limit retries honor supported provider retry delays within the retry policy's bounds.
- Model pickers reset their selection when filtered results change, preventing a stale selection from choosing the wrong model.
- The working indicator ends its current step when a tool result arrives instead of continuing to count tool execution as model work.

### Improvements
- Model filtering prioritizes whole-word matches.
- The working indicator now says "Waiting for model" and shows a countdown during retry backoff.
- Compact tool entries in `run_code` include declared return-shape guidance, and every scriptable tool must declare its scripted return contract.

## [0.32.1] - 2026-10-10

### Bug Fixes
- Codex sessions keep their WebSocket connection across turns. The routine per-turn agent refresh no longer invalidates reusable session transports; only real configuration changes do.
- Pressing Shift+Enter in the idle input box inserts a newline again in terminals that send the same sequence as Alt+Enter. Alt+Enter still queues a follow-up message while a turn is running.
- The approval prompt for `propose_goal` now shows the outcome and success criteria as labelled lines instead of raw serialized arguments.
- Background task timers stay visible in narrow panels instead of being dropped.

## [0.32.0] - 2026-10-08

### Behavior Changes
- Non-interactive runs (a prompt on the command line) that stop at a context limit now exit with code 2 instead of 1 and keep the session, with a `--resume <session>` hint. This covers a request refused before sending (`request_input_limit`), local compaction that cannot make the conversation fit (`context_compaction_hard_fit`), and a context overflow reported by the provider (`provider_context_overflow`). With `--json`, these are reported as a `context_paused` event (with `code`, `sessionId`, and `recovery`) instead of an `error` event.
- In non-interactive runs, a run-budget pause now always stops the run with exit code 2 and a `--resume <session>` hint; with `--json` it emits a `run_budget_paused` event (with `code`, `sessionId`, `evidence`, and `recovery`). Budget pauses only happen when `agent.runBudget.escalation` is set to `contain` or `pause`. `--auto-approve` approves tools only and never grants more budget. In 0.31.x, `pause` combined with `--auto-approve` granted the parent run-budget extensions automatically. With the default `warn`, nothing changes.
- Before each model request, term2 now refuses a request whose estimated input does not fit the model's context window from the model catalog, after reserving the output allocation and a 10% estimation margin. The new `agent.maxRequestInputTokens` setting can only lower this limit, never raise it. Models with a small or under-reported context window may therefore refuse requests that 0.31.x sent. Settings files from earlier versions contain `agent.maxOutputTokens: 32000`, which counts as an explicit choice, so up to 32,000 tokens (capped at the model's maximum output) are reserved. If a small-window model refuses requests, lower or remove that setting.
- Turns with an active durable goal make at least one extra model request for the new goal stop check, plus one per reminder. When the reminders run out, the turn ends with the "Goal stop check unresolved…" notice (`goal_check_unresolved`; printed on stderr in non-interactive mode) and the goal stays active.
- New defaults apply to fresh installs only. Earlier versions saved their defaults into `settings.json`, and those saved values are kept on upgrade: context compaction stays off (`agent.contextCompaction.enabled: false`) until you enable it, and the saved `agent.maxOutputTokens: 32000` counts as explicit, so the new quarter-of-context-window output cap does not apply.
- Downgrading to 0.31.x: 0.31.x cannot load a settings file with `agent.runBudget.escalation: "contain"` ("Failed to parse settings file"), so set it back to `warn` or `pause` before downgrading. 0.31.x also drops `agent.maxRequestInputTokens` and writes `agent.maxOutputTokens: 32000` back into the file. Otherwise, a settings file created by 0.32.0 loads in 0.31.x.

### Features
- Active session goals now have a stop check. While a durable goal is active, the agent reports its progress through a new `goal_check` tool (`achieved`, `blocked`, `not_achieved`, or `deferred`) before a turn can end. If it tries to stop without a valid check, term2 reminds it and the same turn continues. Reminders are capped: two in a row without new work, or six per user message. At the cap the turn ends and the goal stays active.
- A valid `achieved` goal check that ends a turn now closes the durable goal on its own, just like `/goal achieved`. The goal is saved as achieved and its status line is shown (on stderr in non-interactive mode). `blocked`, `deferred`, and `not_achieved` checks never change the goal, and subagents and `run_code` scripts cannot close it. A check counts only for the goal the agent was shown: if you replace the goal with `/goal set` (from the prompt or the control socket) while a turn is running, the earlier check is not recorded or does not count, and the agent is asked to check the new goal instead.
- Requests that cannot fit the model's known context window are paused before sending, with your conversation and completed work kept, instead of failing at the provider. `agent.maxRequestInputTokens` sets an optional lower input ceiling (default: none beyond the model's capacity).
- New opt-in `contain` run-budget escalation (`agent.runBudget.escalation: "contain"`): when a run exhausts its budget, it pauses so you can decide whether to grant more; warnings and stall evidence stay advisory. In non-interactive mode it exits with code 2 and prints the `--resume <session>` command to continue; `--auto-approve` never grants budget. The default stays `warn`.
- `TERM2_SUPERVISED=1` is an environment override for an unattended-run profile: an 80,000-token request input ceiling, an 8,192-token output allocation, and local context compaction at 60,000 tokens. It applies to any term2 process started with the variable set, including interactive sessions, and is never written to `settings.json`. It does not change the run-budget escalation.

### Bug Fixes
- A one-time tool approval or rejection now applies only to the call you answered. Previously, a later call that reused the same call ID could inherit the decision with different arguments, for example on OpenAI-compatible providers that number calls `call_0`, `call_1`, … in every response. Such calls now prompt again. Tool calls without an ID get one unique to their response. With several pending calls that share an ID, a decision settles exactly the call it was made for. Subagents and `run_code` child agents inherit only your "always" decisions, and a blanket rejection always uses its own message.
- OpenRouter requests now forward the selected reasoning effort and keep explicitly configured OpenRouter options.
- Session search no longer stalls on very common search terms. When the session index is unavailable, browsing and search run off the UI thread.
- Codex WebSocket sessions no longer send a chained request over a replacement connection that cannot resolve the previous response; they recover from full history instead. A WebSocket closed with code 1000 before the response finished is now retried.
- `/retry-tool` rewinds to the correct position in the conversation.
- After a crash or forced exit during a tool call, resuming the session marks that call's outcome as unobserved and tells the agent to verify the current state before retrying, instead of dropping the call from the resumed conversation, where the agent could blindly repeat it.
- `/goal set`, `/goal achieved`, and `/goal abandon` now confirm the goal that was just written, not the previous one.
- A saved `agent.maxModelRequestDurationMs` of exactly 300000 is no longer rewritten to 0 (no deadline) at startup; it is kept as a 5-minute request deadline. Earlier versions treated that one value as a leftover of an old default; no other value was rewritten.
- Context estimates no longer count history twice after a self-contained request, which could trigger compaction or a context pause too early.

### Improvements
- Context compaction is enabled by default for new installs (`agent.contextCompaction.enabled`, auto mode at 80% of the context window). Existing settings files keep `enabled: false`; set it to `true` to opt in. Local compaction keeps your own messages, recent paired tool rounds, and tool receipts, and runs again only after the conversation has grown.
- When `agent.maxOutputTokens` is not set in `settings.json`, the output allocation is capped at a quarter of a known model's context window (and at most 32,000 tokens), so small models keep room for input. New installs no longer write this key. Files from earlier versions contain `32000`, which counts as explicit; remove the key to get the cap.
- One-shot subagents now inherit the selected output limit, stream output limit, request deadline, and stream idle timeout; a role's own output limit still takes precedence.
- `/retry-turn` now regenerates the entire latest user turn from its original prompt.
- `/clear` now marks the start of the new conversation with a labelled divider. The working indicator renders above the live divider, the bottom area is more compact, and the rail skin shows quota in its status line.

### Internal/Chores
- Before release, the run-budget escalation default was set back to `warn` (`contain` is opt-in). Non-interactive mode parks every run-budget check-in, and the non-interactive approval policy refuses all run check-ins, so `--auto-approve` cannot grant budget or turns under any escalation.
- `scripts/release.sh` now refuses to tag unless it runs on `main`, a fetch of the remote's `main` succeeds, and HEAD is the remote's `main` (or one unpushed release commit on top of it). HEAD must also be the `chore(release): vX.Y.Z` commit with `package.json` at `X.Y.Z`. The tag is pushed only after `main` was pushed and confirmed on the remote; a failed `main` push never pushes the tag.
- Test fixtures no longer write into the repository tree: settings and skills fixtures use temporary directories, and the sandbox network-approval test no longer writes `.term2/sandbox-network-hosts.json` into the checkout.
- CI now runs the full check suite on pull requests, and focused test runs start faster.
- Added an opt-in workflow-evolution experiment ledger, run from a checkout (`docs/workflow-evolution.md`) and not exposed through the `term2` command, and a supervised-worker launcher under `tools/supervised-term2`, which is not part of the published package.
- README and website refresh, including a demo recording.

## [0.31.1] - 2026-10-04

### Bug Fixes
- Model selections now retain their provider binding across settings, model menus, sessions, and subagent tier pools, preventing ambiguous model names from selecting the wrong provider.
- Existing persisted model selections are migrated before strict settings validation so older settings remain usable on startup.
- Failed `run_code` scripts now expose results from nested tools that already completed, allowing recovery without repeating their effects.

## [0.31.0] - 2026-10-03

### Features
- Added configurable colour themes with automatic terminal-background detection and monochrome support through `ui.theme`.
- Added classic, rail, cards, ledger, and zen layout skins, selectable through `ui.skin`, covering messages, tool output, approvals, menus, and the status bar.

### Bug Fixes
- Queued input and drafts now survive approval prompts and queued-message editing. Stopping a paused queue, clearing a session, and late cancellation settlement no longer leave queued turns incorrectly armed or lose their cancellation state.
- Live background-shell watches now see matching output before retention eviction removes it.
- Completed background agents release their pending approvals, while session shutdown preserves lifecycle and persistence observers until asynchronous work settles.
- Resetting a session with a reused client no longer lets the old session's shutdown clear the replacement session's background callbacks.
- Subagent errors containing words such as “cancel” or “abort” are reported as failures unless they carry cancellation identity.
- Invalid model-catalog prices are treated as unpriced and normalized during catalog refresh.
- Nested filesystem tools in remote `run_code` calls now resolve physical paths over SSH and refuse paths whose authority cannot be established safely.
- Web sessions expose their live turn status on reconnect, preserve local errors, and cancel active chat-completions streams correctly.

### Improvements
- Refreshed the model catalog.

## [0.30.0] - 2026-09-29

### Features
- Subagents can now be launched from a per-invocation agent specification (goal, context, tools, constraints, completion criterion, model policy, and budget) instead of only a fixed role. Existing roles remain as thin presets, and existing `run_subagent` callers keep working.
- `run_code` scripts can start and compose child agents with `agent.run`, `agent.start`, `agent.status`, `agent.result`, and `agent.cancel`. Child permissions are narrowed to the parent's authority, worktree scope is pinned, and runs are bounded by call, concurrency, and start budgets. When a script's child agent needs tool approval, the request goes through the session's normal approval prompt and the child resumes after the decision.
- Added a `propose_goal` tool so the agent can suggest a session goal; proposals always require the user's approval.
- Added Firecrawl and SearXNG web search providers, configurable in settings.

### Improvements
- A subagent tier-pool entry that is unhealthy now fails over to the next entry.
- The web gateway covers more of the client API, routes its session lifecycle through a session handle, and closes new admissions cleanly during abort and shutdown.
- Web search settings from environment overrides are preserved, and provider options are forwarded correctly.

## [0.29.1] - 2026-09-28

### Bug Fixes
- Provider-state rejections during a tool continuation now recover the conversation chain when all live-turn tools have completed, instead of failing the user's turn.

## [0.29.0] - 2026-09-28

### Bug Fixes
- The startup banner now shows the same version string as `term2 --version`, including the build identity of a build made from a checkout, instead of only the package version.
- Input released after cancelling an `ask_user` prompt (a steer or a settled background run) no longer lets the model resume the plan the user just cancelled. Cancelling from the web client now ends the turn too, as Escape does in the terminal.
- Distinct assistant message parts no longer render, persist, and replay to the model as one run-on sentence.
- Agent-run shell commands no longer claim the herdr pane that launched term2. herdr routing metadata is still passed through, so helper commands keep working.
- Model catalog refreshes no longer drop context windows and pricing when the upstream catalog keys models as `<kind>:<id>`.
- A malformed patch applied in YOLO mode now reports the patch problem instead of failing the turn.

### Improvements
- All GPT-5 and GPT-6 main-agent models now share one base prompt, and other models keep the simpler prompt; the per-model prompt files were removed.
- Global memories are pinned into a session's instructions once per session, replacing per-turn automatic recall.
- Removed the RTK shell-output compression integration and its `shell.useRtkCompression` setting.
- `run_code`, `grep`, and patch failures now explain what to do next instead of surfacing a raw tool error.
- Interactive startup is faster: the terminal UI is imported only when a session actually starts.

## [0.28.0] - 2026-09-27

### Features
- Added durable session goals: set one at launch with `--goal` (and optional `--goal-criteria`) or in chat with `/goal`. The goal persists across resume and session rollover and is included in request context.
- Added an opt-in local control socket for a live TUI session (`--control-socket[=<name>]`) and a `term2 control` command to read status and submit, steer, or interrupt turns from another process.
- Sessions and project memory are now scoped by git project, so a checkout and its worktrees share one session list, resume history, and project memory.
- Mistyped slash commands now suggest close matches instead of being sent to the model.

### Bug Fixes
- Fixed Codex sessions refusing every turn after native context compaction, including resumed sessions that were compacted in earlier versions.
- Compacted conversation history now persists across turns and resumes correctly; switching providers after native compaction is refused only when the compacted history came from a different backend.
- An oversized tool call is recovered by asking the model to split the work instead of failing the turn.
- Resuming a session whose working directory was deleted, and recovering a locked session, now work and explain what happened.
- Session rollover fails safely when the log writer fails, and keeps durable goals and usage reminders.
- The control socket survives misbehaving or disconnecting clients instead of crashing the TUI.
- Image paste failures now show a notice; large paste markers show the logical line count.
- Restart-required settings changed with slash commands are now saved.

### Improvements
- Ctrl+C now clears the draft or interrupts the running turn first; press it again to exit. Ctrl+\ exits immediately. Scripts or terminal automation that stopped term2 with a single Ctrl+C must now send it twice, or use Ctrl+\.
- Approval prompts have clearer actions and labels. Deny stays the second option, and number keys can only allow once or deny, never grant a session or project-wide permission. Docker host control cannot be approved with a single keystroke.
- Provider and tool errors are more readable and actionable; key hints, working indicators, and status-bar priorities are more consistent.
- Polished CLI startup help and the exit summary, which keeps the SSH-aware resume command.
- Removed unused code and the `import-jsx` dev dependency.

## [0.27.0] - 2026-09-26

### Features
- Added opt-in automatic-memory canary evaluation and offline memory-candidate distillation, with evidence-gated promotion, secret redaction, and path-safety checks.
- Added teammate-memory checkpoint tooling and historical session-knowledge candidate scanning.
- Added memory injection receipts, correction provenance, and topical filtering for automatic memory recall.

### Bug Fixes
- Preserved user-authored memory-recall markup and stopped rewriting instructions to inject memory context.
- Prevented subagent lifecycle events and background-task completion from producing misleading user notifications.
- Improved memory distillation transport cleanup and memory-store promotion safety.

### Improvements
- Loaded recent conversations asynchronously through a worker for more responsive resume menus.
- Refined menu layout, selection markers, confirmation prompts, and pending-queue presentation.
- Improved session rollover knowledge recovery and teammate-memory evaluation coverage.

## [0.26.1] - 2026-09-24

### Features
- Added version badge display to the startup banner.
- Added task-relevant teammate memory retrieval at root turn start.

### Bug Fixes
- Fixed nested Codex response chains sharing sockets and omitted parent wire cache key in child requests.
- Repaired release integration gate fixtures.

### Improvements
- Refined GPT-6 prompt guidance for proactive follow-through and outcome-driven execution.
- Added product, cost, and architecture research on teammate-like memory and active project memory.

## [0.26.0] - 2026-09-23

### Features
- Added an experimental ACP v2 adapter and `term2 acp` stdio launcher, including persistent sessions, permission requests, and writable-session support.
- Added a human-led Pair profile and opt-in approval-decision shadow review.
- Model pickers now support nicknames, including managing and moving nicknames between models.

### Bug Fixes
- Improved ACP permission enforcement, session persistence, and teardown reliability.
- Fixed settings being rewritten to use the OpenAI provider when an unregistered provider was configured.
- Improved recovery guidance for context hard-fit and reporting of provider continuity recovery.
- Removed the 64K cap on compaction fallback windows for uncatalogued models.
- Fixed composer text being retained across `/clear`, `/quit`, and `/resume`.

### Improvements
- Improved model-picker descriptions, directional tab navigation, and `/retry-turn` output.
- Improved decision-shadow failure diagnostics and live approval routing.
- Added `term2 acp` and Web Gateway API documentation.

## [0.25.0] - 2026-09-18

### Features
- Added MCP server support: configure stdio, HTTP, and SSE servers; use their tools through `run_code`; authenticate OAuth-backed servers; and manage server state from an interactive menu.
- Added opt-in OpenRouter Decisions shadow review for approval decisions, with a live model picker for selecting the reviewer.

### Bug Fixes
- Fixed Responses API tool names being lost in the UI.
- Fixed malformed tool arguments crashing tool-label rendering.

### Improvements
- Nested read approvals now show the active workspace.
- Tool status remains visible while commands run, and slow direct shell commands receive an acknowledgement.

## [0.24.1] - 2026-09-14

### Features
- Added the `agent.disabledProviders` setting so disabled providers disappear from model pickers and catalogs.

### Bug Fixes
- Fixed chained OpenAI requests resending duplicate reasoning content by projecting requests to input deltas.
- Fixed the codex client preferring the latest npm version.

### Improvements
- Compacted status bar and background-task panel labels for narrow terminals.
- Subagent task panel shows each task's latest tool; pooled mentor output no longer exposes model names.
- Provider order now follows the settings list; manual reordering was removed from the provider menu.
- Session read tools fall back for "previous" and allow larger read budgets.

## [0.24.0] - 2026-09-13

### Features
- OAuth logins now accept a pasted callback query string or a bare authorization code, not only the full URL.

### Bug Fixes
- Fixed Grok OAuth login being rejected by auth.x.ai: the redirect now uses 127.0.0.1 on an ephemeral port, matching the registered redirect URI.
- Fixed grep/glob disappearing from read-only surfaces or when `tools.fileWrite.enabled = false`; the search tools now gate on read authority, so only `tools.fileRead.enabled` removes them.
- Fixed grep/glob exposure varying by model: the dedicated search tools now depend on the `app.searchViaShell` setting alone, and only an explicit `on` routes search through the shell.
- Fixed committed command groups being reprinted once per later message as the UI message cap trimmed their front.
- Fixed the `run_code` description recommending `grep` where it may not exist on patch-editing surfaces, and unknown-tool rejections raised before dispatch are now counted in completion telemetry.
- Fixed the composer keeping the drafted text after submitting a custom `ask_user` answer.

### Improvements
- User messages now render on a full-width background band so they read as content blocks, with the accent color confined to the prompt glyph.

## [0.23.0] - 2026-09-13

### Features
- Added the term2 documentation website, covering installation, providers, operating modes, tools, safety, remote development, and configuration.
- Added the production web gateway with authenticated session commands, broad conversation-event projection, read-only workspace enforcement, and durable session recovery for external clients.
- Added `run_code` improvements for separate JSON inputs, structured execution outcomes, declarable return contracts, nested tool traces, and clearer failure diagnostics.
- Added Librarian and Reviewer subagent roles, configurable round-robin model pools for subagent roles, and completed background runs that can be continued.
- Added session retrieval filters and indexed seeks, bounded previews, and tool names in session results.

### Bug Fixes
- Fixed live streaming rows being claimed after their React update was queued, which could leave rendered state behind the conversation state.
- Fixed nested `run_code` approval prompts so tool arguments remain visible.
- Fixed settings menus while filtering and removed deprecated subagent researcher settings.

### Improvements
- Added shell call descriptions to the task UI.
- Removed the unused memory synthesis tool and clarified the librarian's history-retrieval role.
- Extended modern GPT tool handling to GPT-6 models.

## [0.22.1] - 2026-09-12

### Improvements
- Replaced the "N more" overflow hints in menus with scrollbars.
- Tab now switches tabs in the model menu instead of completing the model id.
- The mentor pool model setting now uses the unified model picker, and its filter starts empty.
- Removed the legacy smart/cheap tier and `tools.editHealingProvider` fallback settings reads; use the tier-primary keys.

### Bug Fixes
- Fixed streaming and reasoning rows left unfinished after an aborted turn.
- Fixed the startup model picker leaving its frame on screen after a selection.
- Fixed the slash menu staying open while its action runs.

## [0.22.0] - 2026-09-11

### Features
- Added `run_code`, a script tool that exposes the toolset as a `tools` namespace, and made it the primary tool path: when `run_code` is available the direct surface is `run_code` plus script-prohibited tools only.
- Added inline approval for tool calls made from inside a `run_code` script, with per-tool-graph approval policy ownership and a work-clock that pauses only while a nested approval waits.
- Added a SQLite session index behind the session browser and session tools, with FTS5 trigram search, indexed message reads, and canonical-log fallback; the indexed backend is now the default.
- Added declarable scripted return shapes on scriptable tools, surfaced through `describe`, so scripts can see a tool's result contract before calling it.
- Added a unified cross-provider model picker with favorites, model nicknames, an all-models tab, and `--list-models --refresh` to bust a stale catalog cache.
- Added an interactive picker for ambiguous, no-match, or valueless `--model` arguments.
- Added a GPT-6 Astra prompt profile.
- Added a `run_code` nested-call tool trace to the UI, and recent subagent tool calls to the background tasks panel.
- Added comma-separated entry for array-typed settings, in-place Space toggling of booleans, and free-form string value entry seeded with the current value.
- Added typed shell termination reasons (`deadline`, `cancelled`, `output-overflow`) with paused-time accounting, so a cancellation no longer reads as a timeout.
- Added live task inventory to the session rollover brief and preserved live background work across an in-place rollover.
- Added human-friendly display units for setting values in the settings UI.

### Bug Fixes
- Fixed `run_code` scripts receiving context-capped fragments: scripts now get whole files, whole glob and grep match sets, and structured results.
- Fixed a vm realm-isolation escape where a value exposed to a script could recover the host `Function` and then `process`; all bindings are now constructed inside the context at one site.
- Fixed `run_code` JSON serialization parity, image and large-media delivery, call-budget diagnostics, syntax and runtime error locations, and nested tool error attribution.
- Fixed action receipts under output clipping and misattributed budget receipts on rejected calls.
- Fixed model catalog cache poisoning from degraded provider catalogs, and made `--provider` no longer widen the model search.
- Fixed context compaction triggering early, and added backoff when a trigger is blocked.
- Fixed Codex compaction worker identity, Luna provider chain reset after native compaction, and parallel tool calls during Lite compaction.
- Fixed sandbox worker startup after the launch directory was deleted.
- Fixed orphaned streaming bot messages blocking the static commit, and render crashes on malformed tool arguments.
- Fixed menu rows wrapping as separate fragments instead of one layout unit.
- Fixed background check-ins interrupting active work and firing with no content to report.
- Fixed cancelled agent streams being classified as errors rather than aborts, and worker validation receipts claiming success on unknown outcomes.
- Fixed async subagents being dropped across session rollover, and settled tasks appearing in the rollover live inventory.
- Fixed non-interactive mode exiting with background subagent work still pending.
- Fixed `glob` no-match results not explaining that matches were ignored.
- Fixed the standalone model picker refusing to render interactively under CI.
- Fixed provider-traffic capture still writing after it was disabled, and a lost log sequence after an oversized tail event.
- Fixed session rollover losing provider cache affinity, so a rollover no longer discards the prompt cache.
- Fixed `--model`/`-m` treating its value as a prompt, and the picker opening on the default tab instead of the matched provider.

### Improvements
- Reduced session tool search and cursor friction, and repaired backward tail reads (`from: "end"`) to be a real tail region with page-local omitted counts.
- Made `--model` resolution lazy with deterministic fuzzy ranking; raised the model catalog cache TTL to 24h with a 7-day grace.
- Filtered the OpenRouter model catalog by age.
- Stopped asserting the local OS and shell as fact in SSH and remote sessions.
- Compacted the background task strip and stopped concise tool groups reprinting on text-free continuation steps.
- Required the `description` parameter on `run_code`, and made unexposed tool names throw a descriptive `Unknown tool` error.
- Removed dead settings scaffolding and legacy Zod v3 branches; settings UI metadata and provider suggestions are now schema- and registry-derived.
- Reduced repeated compaction and tool recovery work in the run loop.

## [0.21.0] - 2026-09-03

### Features
- Added Profile architecture (Milestone 1) supporting typed profiles, capability-gated tools, active profile enforcement, and an interactive `/profile` picker menu.
- Added per-capability tool toggle settings (`tools.<capability>.enabled`) to granularly enable or disable specific agent capabilities.
- Added 1-hour atomic disk caching for provider model listings to eliminate redundant network fetches across CLI invocations.
- Added model flag improvements: `--list-models` CLI flag to inspect available models, plus partial and fuzzy matching with interactive disambiguation for `--model`.
- Added backward transcript tail reads (`from: "end"`) and pagination snapshot caching to session retrieval.
- Added last-3 subagent tool calls with formatted parameters into the task panel for improved execution visibility.
- Enabled auto-approval for safe file read and mutation tools when operating within workspace boundaries.
- Added opt-in raw provider traffic logging sidecar (`TERM2_RAW_TRAFFIC`).

### Bug Fixes
- Hardened `apply_patch` with canonical patch envelope enforcement and fail-closed syntax guards.
- Clamped foreground shell `max_output_length` to configured budget limits to prevent output flood.
- Fixed footer token rate calculations by subtracting hidden reasoning tokens and marking burst decodes.
- Fixed historical provider-traffic index timestamps and corrupt index recovery.
- Prevented conflict between `--list-models` and `--resume`/`--fork`.
- Fixed `--model` flag override to remain strictly session-scoped and avoid mutating persisted settings.
- Restored proper chronological interleaving of background shell firings and assistant replay turns.
- Maintained DeepSeek reasoning stream continuity and recovered settled-tool provider state rejections.

### Improvements
- Redesigned injected memory index with a two-tier counted layout and explicit omission reporting.
- Raised background check-in minimum interval to 300s and next check-in delay to 30s.
- Formatted generic tool command fallbacks in task summaries to display identifying scalar parameters.

## [0.20.0] - 2026-09-01

### Features
- Added live and settled streaming speed (tokens/sec) to the status bar, with per-request token calibration from actual usage.
- Added upstream provider name display in the status bar for OpenRouter requests.
- Added dynamic background-task check-in controls and removed the fixed check-in cap setting.
- Added image support to `read_file` results.

### Bug Fixes
- Fixed message ordering around background notifications.
- Fixed session-browser results to use the session's home workspace and show the workspace scope.
- Fixed concise command rendering so lone commands remain ungrouped and tool categories are displayed.

### Improvements
- Shortened session read cursors to reduce context overhead on small models.

## [0.19.0] - 2026-09-01

### Features
- Added live and settled streaming speed (tokens/sec) to the status bar, with per-request token calibration from actual usage.
- Added upstream provider name display in the status bar for OpenRouter requests.

### Bug Fixes
- Fixed Codex context compaction against the upstream v2 compact protocol.
- Fixed dropped Codex/OpenAI WebSocket streams after completed tool calls.
- Fixed the model continuing to generate after a session rollover handoff.
- Fixed fabricated terminal text when a stream ends with empty or whitespace-only output.
- Fixed interrupted background tasks being left in a non-terminal state, and a stop race that resurrected processing.
- Fixed command group fragmentation and duplicate static lines in concise mode.
- Fixed unrecovered WebSocket connect timeouts after a dropped connection.
- Fixed retry handling: transport failures no longer masquerade as context compaction, upstream retryable errors are honored mid-turn, and an exhausted retry budget settles the turn truthfully.

### Improvements
- Shortened session read cursors to reduce context overhead on small models.

---

## [0.18.0] - 2026-08-31

### Features
- Added session rollover: context-milestone reminders and a new `session_rollover` tool that hands off a long conversation to a fresh session before it hits context limits.
- Enriched background check-in notifications with a recent output tail and richer live status for long-running background shells and subagents.

### Bug Fixes
- Fixed session-rollover settings not appearing in the Settings UI and contract inventory.

---

## [0.17.0] - 2026-08-30

### Features
- Added structured NDJSON output streaming (`--json`) and `--quiet`/`--reasoning` flags for clean non-interactive execution.
- Converted `/auto-approve` and `/resume` commands into interactive value selection menus.
- Added automatic approval for memory mutations and safe temp/scratch directory file operations (including session-created scratch file deletions in `rm`).
- Enhanced memory and session search with broad retrieval routing through synthesis, unambiguous pagination/omitted counts, and active-session demotion in search results.

### Bug Fixes
- Fixed Codex context compaction by invoking native `/responses/compact` instead of unsupported `context_management` payloads.
- Fixed stale `previous_response_id` reuse on mid-session model changes by resetting chaining to prevent server 400 errors.
- Fixed lossy chain recovery to rebuild full history rather than sending truncated deltas when an anchor is invalid.
- Disabled the interactive `ask_user` tool in non-interactive mode.
- Fixed temporary directory creation to be lazy, eliminating import-time filesystem side effects on core entry points.

### Improvements
- Improved readability of safety findings in command execution prompts.
- Updated `CommandGroupSummary` failure handling color cues and diagnostics.

---

## [0.16.0] - 2026-08-30

### Features
- Added in-app and command-line session resumption, including recent-session listing and saved-session outcome details.
- Added bounded persistent-memory retrieval and a local browser for finding prior sessions from the current project.
- Added periodic check-ins for long-running background shells and subagents, with configurable scheduling and limits.
- Added browser-owned gateway control for local server mode, workspaces, settings, credentials, and OTP pairing, with durable interaction recovery.
- Added prefix-triggered shell input mode, model and reasoning-effort shortcuts (`Ctrl+O` and `Ctrl+T`), and clearer in-flight composer hints.
- Added OpenCode Go usage-limit reporting and an option to disable run-budget escalation.

### Bug Fixes
- Improved recovery from provider stalls, in-stream rate limits, interrupted retries, verbose reasoning, invalid response IDs, and expired Codex WebSocket sessions.
- Fixed continuation and history handling for Luna explorer turns, interrupted conversations, and undo-removed turns.
- Fixed background-task status synchronization across the terminal, title, gateway, hooks, and non-interactive mode.
- Fixed queued-tool timing, pending-steer labeling, output trimming, message grouping, and several menu and authentication edge cases.
- Prevented conversation-mutating slash commands during active turns and made YOLO workspace-boundary behavior consistent for subagents.

### Improvements
- Unified runtime modes around prompt guidance while preserving provider prompt-cache behavior.
- Made concise display mode the default for new users and improved run-budget status formatting.
- Improved the task strip and background-subagent presentation, including completed-run grouping and live elapsed times.
- Accepted pasted OAuth loopback redirects and handled headless environments without a browser opener.

---

## [0.15.0] - 2026-08-25

### Features
- Added Grok OAuth login (`--grok-login`) with a term2-owned credential store, and a switcher for multiple Grok and Codex accounts. Account changes apply from the next session.
- Ran Grok on the Responses API with its own opaque reasoning lane, prompt-cache affinity, and weekly credit usage in the status bar.
- Added per-model usage and cost, including provider-reported cost on streamed turns.
- Added staged run-budget limits with stall detection, warn-mode escalation, and a subscription exemption.
- Added a confirmation prompt when switching modes mid-session.
- Discovered OpenCode model transports and routed Opencode Muse through Responses.
- Added inline background-shell monitoring, richer Tasks-panel liveness, and a unified live UI for foreground and background subagents.
- Collapsed closed tool-call runs into one summary line in concise mode, and added safe `apply_patch` self-healing.
- Made YOLO mode skip approvals globally except `ask_user`, including workspace-boundary prompts for read tools.

### Bug Fixes
- Fixed tool-call rendering so in-flight calls stay visible, long runs group instead of wiping scrollback, mixed results are not overstated, and empty failed output is not shown as an approval denial.
- Stopped retrying expired provider credentials and stopped tab-completion from echoing stored API keys.
- Recovered flaky or nested Responses WebSocket closes, settled broken `previous_response_id` chains without retry loops, and dropped foreign or cold provider-opaque items instead of refusing the turn or compaction.
- Kept assistant text that arrives with tool calls, committed it before dispatch, shared project memory across worktrees, and treated schema and JSON tool errors as failures.
- Primed Plan Mode notices on remaining entry paths and sent Plan Mode workflow only while Plan Mode is on.
- Disabled unsupported Codex server-side context compaction, removed the unused Codex warmup request, and recovered corrupt Codex history without warmup partitioning.
- Isolated background-task manager input, settled SSH commands on transport drop, honored the parallel tool-call setting, and redrew committed messages on terminal resize.

### Improvements
- Polished `ask_user` layout, queue vs steer guidance, and paused-queue prompts.
- Defaulted local context compaction to `auto` and propagated reasoning effort through compaction.
- Updated the bundled model catalog, including Muse Spark token limits.
- Switched npm publishing to GitHub Actions Trusted Publishing with short-lived OIDC authentication and automatic provenance.

---

## [0.14.0] - 2026-08-12

### Features
- Added provider-neutral local context compaction, including configurable policies and modes, manual compaction, durable checkpoints, safe request-boundary handling, and bounded quality evaluation.
- Added a configurable mentor pool that can consult multiple models, sample each consultation, and select a provider and model through the shared model picker.
- Added concurrent dispatch for contiguous auto-approved, read-only tool calls while preserving result order and serial approval, write, and control barriers.
- Added OpenAI Responses `context_management` support for Codex models and expanded the supported model allowlist.
- Added code-block previews in the `/copy` menu and retained active filter text in interactive menus.
- Added scheduled CI updates for the model catalog.

### Bug Fixes
- Fixed local compaction boundaries and disabled-mode request timing so compaction remains safe and does not alter normal provider request behavior.
- Fixed oversized or unobserved tool effects by bounding tool results and settling interrupted calls as unknown instead of retrying them blindly.
- Fixed background task rows lingering after completion, slash-command menu wrapping, and mentor-pool input and settings stability.
- Fixed subagent max-turn handling to stop cleanly at its budget and removed subagent tool-start events from activity messages.

### Improvements
- Improved diagnostics for aborted provider streams.
- Clarified explorer delegation so explorers collect evidence while the parent agent retains analysis and decisions.
- Updated the bundled model catalog.

---

## [0.13.0] - 2026-08-11

### Features
- Added monitored background shell jobs with retained output, tail inspection, watches, completion notifications, configurable timeouts, and bounded overflow handling.
- Added first-run provider setup and credential-aware model readiness checks.
- Added provider-faithful reasoning round-trips for chat-completions models, preserving provider-specific reasoning metadata across tool turns.
- Expanded `/copy` with options to copy the full response or selected code.

### Bug Fixes
- Fixed Codex WebSocket close recovery and stopped accepted close events from being replayed.
- Fixed unpaid tool-chain debt after mid-stream failures so stale continuation state is not reused.
- Fixed Tab handling in the slash-command menu, approval handoffs, and command rows that could remain running or leave shell job-control calls unresolved.
- Fixed active background-result polling by routing incomplete results through the appropriate wait or messaging path.

### Improvements
- Added per-request session cost tracking and pricing for catalog-matched gateway models.
- Improved input responsiveness for large uncached histories and suppressed the uncached warning while an agent turn is running.
- Improved provider and skill-selection flows, including provider-wizard input and immediate skill activation.
- Added more detailed command-line help and clearer worktree transition descriptions.

## [0.12.0] - 2026-08-09

### Features
- Added server-side context compaction for supported OpenAI Responses models, with configurable thresholds and context-usage feedback in the status bar.
- Added editing and removal of messages queued while a turn is in progress.
- Added fuller background-task controls, including task inspection, stopping tasks, clearer completion notifications, shell handoff, and foreground-subagent transfer with approval handling.
- Added acknowledged peer-channel delivery so local Codex and compatible agent sessions can reliably wake and exchange follow-up messages.
- Added a session-scoped option to approve edits outside the workspace.

### Bug Fixes
- Fixed Escape and prompt-input handling across menu transitions, including double-Escape interruption behavior.
- Fixed provider-stream recovery, cancellation, replay, and usage-accounting edge cases across supported providers.
- Fixed runaway or malformed model output from continuing indefinitely.
- Fixed orphaned shell child processes when the CLI exits.
- Fixed Codex requests that included an unsupported `max_output_tokens` parameter.

### Improvements
- Redesigned interactive menus so each surface has exclusive input ownership, improving autocomplete, cursor preservation, and transition reliability.
- Improved provider support and resilience, including direct application-owned streaming, OpenCode Responses indicators, and safer continuation handling.
- Made the status bar more concise while adding elapsed command time, cache percentage, and clearer background-subagent identity and context information.
- Improved approval decisions with risk-aware automatic review and clearer adopted-subagent approval controls.
- Centralized conversation, settings, provider, model-catalog, and handoff session ownership for more reliable interactive and non-interactive behavior.

## [0.11.1]

### Features
- Background subagent activity now appears in the UI.
- Added a subagent status peek tool with richer turn history.
- Added subagent steering and blocker questions.
- Agent instructions now load from both the project `AGENTS.md` and your global `~/.agents/AGENTS.md`.

### Bug Fixes
- Search-tool descriptions now stay consistent when a glob pattern is omitted.

### Improvements
- Subagent completion messages now provide clearer status and outcome details.
- Subagent results now retain more useful evidence, including diffs and validation notes.

## [0.11.0] - 2026-07-26

### Features
- Added a background task overview for async subagent work.
- Async subagent sessions now persist across turns, and the main agent is notified when background runs finish.
- Orchestrator mode now delegates background work asynchronously by default.
- Added Remember options to network access approval prompts.
- LLM auto-approved commands are now clearly labeled.

### Bug Fixes
- Fixed the default ordering of menu items.
- Fixed Docker host-control approvals so they’re inferred correctly.

### Improvements
- Clarified delegation guidance and task ownership in Orchestrator mode.
- Improved labeling of async subagent activity.
- Made Codex rate-limit windows easier to read.

## [0.10.1] - 2026-07-25

### Features
- Added labels for LLM auto-approved commands.

### Bug Fixes
- Fixed Codex rate limit window formatting.
- Fixed Docker host-control approval detection in sandboxed runs.

### Improvements
- No additional improvements.

## [0.10.0] - 2026-07-25

### Features
- Add a persistent memory system with a dedicated librarian subagent for storing, retrieving, and consulting memories across global and project scopes
- Add message queueing: send follow-up messages while the agent is working, with up-arrow cancellation for queued messages
- Add Docker host control capability for sandboxed commands, with explicit approval grants and sandboxed tmux socket access
- Automatically detect and stop runaway/repetitive model responses
- Allow file modifications while in lite mode
- Add "Allow this folder for this session" option to outside-workspace file read approval prompts
- Add model tier settings with fallback chains for ancillary models
- Add skill activation support for subagents

### Bug Fixes
- Fix Codex WebSocket reliability: recover from stalled responses, fix warmup path, and prevent session history from growing unbounded
- Fix stale tool call continuation recovery after interrupted turns
- Fix approval outputs not recovering correctly after continuation
- Fix duplicate user messages appearing in the UI
- Fix Escape key closing menus from unintentionally stopping the agent
- Fix shell command timeout not pausing during network approval prompts
- Fix built CLI not marked as executable

### Improvements
- Improve usage and cost tracking accuracy
- Improve subagent task delegation guidance

---

## [0.9.4] - 2026-07-08

### Improvements
- Rebalance executor and mentor prompts to remove adversarial/gate framing: mentor is now a calibrated strategic advisor, executor retains final decision responsibility

---

## [0.9.3] - 2026-07-05

### Features
- Implement sandbox network approval system with toggle command and tests
- Add sandbox failure classification for enhanced error handling
- Enhance context mismatch diagnosis with closest candidate blocks suggestion
- Add terminal title management with project folder and running state indicators
- Enhance Codex WebSocket handling for network failures with automatic history clearing
- Add `id` field to provider settings for unique identification
- Add E2E test infrastructure with terminal integration helpers

### Bug Fixes
- Fix shell commands not waiting for network approval before execution
- Fix custom providers not available in non-interactive mode
- Fix nested subagent terminal events causing incorrect UI state
- Fix lost tool output after retrying network errors in Codex WebSocket
- Fix double banner output on conversation start
- Fix flickering after handoff or parallel subagent completion
- Fix resume tool call argument replay producing incorrect history
- Fix chained continuation recovery after interrupted turns
- Fix type errors in non-interactive mode and runtime setting router

### Improvements
- Simplify CodexResponsesWSModel warmup logic by removing unnecessary retry mechanisms
- Replace `exec` with `spawn` for improved process handling in shell execution
- Extract `ConversationOrchestrator` from `use-conversation.ts` for cleaner separation of UI and business logic
- Extract conversation state projection and schema from replay logic
- Rearrange settings menu for improved usability
- Update system prompts for better agent behavior

---

## [0.9.2] - 2026-06-26

### Features
- Allow enabling outbound networking for sandboxed shell commands via settings

### Bug Fixes
- Fix reasoning message status not supporting 'streaming' state; ensures finalization and teardown run even with empty text buffer
- Fix reasoning not finalizing when text delta starts
- Fix memory leak

---

## [0.9.1] - 2026-06-26

### Features
- Add `/retry tool` command that rewinds to the last tool output, trims the trailing assistant/system UI tail, and replays the model from the preserved tool-result history
- Redesign tool call display in UI
- Add refresh functionality to model selection and input handling
- Enhance `search_replace` with detailed command message formatting
- Enhance `glob` tool to support absolute path patterns and improve error handling
- Add sandbox read policy display to StatusBar component
- Add line numbers to `read_file` tool output
- Adjust `grep` and `glob` tool output to reduce confusion and improve clarity
- Add sandbox XDG directory redirection
- Improve sandbox prompts and clarify temp directory location in sandbox messages

### Bug Fixes
- Fix finished subagent messages retaining in dynamic rendering area causing flickering
- Fix log files not being cleaned up properly
- Fix next turn not working correctly after aborting
- Fix lost user message after aborting
- Fix stale images callback in InputBox component
- Fix redundant marginY from CommandMessage tool panels
- Fix UI not reflecting post-retry tool state

---

## [0.9.0] - 2026-06-23

### Features
- Add sandboxed shell execution with configurable read policy levels (`credential-denylist`, `home-denylist`, `standard`, `strict`)
- Add sandbox write protection with filtered path logging
- Add sandbox temp directory management for consistent temporary file handling
- Add denied read approval UX for sandbox filesystem access
- Add unsandboxed shell approval support in ApprovalPrompt
- Rename `find_files` tool to `glob` for clarity
- Show approval prompt when reading outside workspace instead of denying access
- Allow using custom model names not in the predefined list
- Sanitize and detect malformed tool call arguments in conversation history
- Optimize token input handling for improved performance
- Increase default max tool output size from 10k to 40k characters
- Enhance skill discovery paths for better workspace resolution

### Bug Fixes
- Fix missing tool outputs in stateless full-history fallback causing HTTP 400 errors
- Fix ghost dotfiles not being cleaned up properly
- Fix model selection not working in handoff flow
- Fix duplicate text appearing in non-interactive mode

---

## [0.8.0] - 2026-06-20

### Features
- Add skills support with `/skills` command to browse and manage available skills
- Implement batch-barrier approval flow for parallel tool calls
- Add structured `ask_user` tool with multi-question navigation, multi-select choices, typed answers, and decline option
- Add reasoning effort selection in handoff flow
- Add plan mode exit reminder when running handoff command
- Add concise display mode for compact tool output rendering
- Add UI indicator for tool call streaming
- Add shell output formatting with truncation handling and execution duration tracking
- Display first paragraph of tool output when commands complete
- Add rate-limit middleware to handle 429 responses with excessive `retry-after` headers
- Add WebSocket-to-HTTP downgrade support for conversation chaining
- Add `overwrite` parameter to `create_file` tool
- Add `match_all` parameter to `search_replace` tool
- Add reasoning metadata retention in message processing and WebSocket response payloads
- Add `PROVIDER_ORDER` support in settings with provider reordering functionality
- Add resume state handling for continuation of streaming conversations
- Add `grep` case sensitivity, regex/literal mode options, and strict JSON parsing

### Bug Fixes
- Fix inability to write outside workspace after approval
- Fix missing tool output in response to Codex API
- Fix missing `reasoning_content` after interrupted turns
- Fix `undefined` value handling for `confirmOverwriteCode` in `create_file` tool
- Fix fetch models error for Gemini
- Fix out-of-order rendering and duplication of committed messages
- Fix prompt-cache prefix break after `max_turns_exceeded` continuation for full-history providers
- Fix completed subagent messages disappearing in UI while waiting for parallel subagents
- Fix tool call streaming indicator missing for Anthropic/Gemini providers
- Fix concise mode regression where query patterns failed to render
- Fix chaining request not working properly for Codex
- Fix tool chaining and input filtering for conversation continuity
- Fix non-string/object JSON array items handling in tool output warnings
- Fix input surge guard false positive block on approval continuation retries
- Fix cursor position issues in input when value and cursor override change simultaneously
- Fix wrong cursor position when selecting setting items
- Fix text color handling for approval rejections and error messages
- Fix interleaved tool outputs and delta filtering in Codex responses
- Fix missing `turnId` in conversation sessions
- Fix subagent turn count increment in context handling
- Fix transient retry handling to preserve conversation chaining instead of permanently disabling it

## [0.7.3] - 2026-06-04

### Features
- Add delta-input filtering for conversation chaining to prevent duplicate inputs
- Add `getMaxOutputTokens` utility with dynamic token limits integrated into Anthropic provider
- Support conversation history chaining for Codex over WebSocket
- Add `prompt_cache_key` forwarding to OpenAI WebSocket requests
- Add `modelClass` and `modelWrapperClass` metadata to logging and provider traffic records
- Add headers to traffic log entries
- Add hardened `ask_user` tool with improved clarity and usage consistency
- Add field-level validation errors and discard confirmation flow for provider settings
- Add providers management menu for configuring multiple API providers
- Enable explorer subagent to run safe read-only shell commands
- Refine orchestrator mode prompt for better task delegation
- Support free-form string settings with runtime modification
- Add inactive state support to menu items and improve navigation handling
- Add safeguards and user confirmation prompt when starting non-lite mode from home or root directory
- Improve settings handling with schema-based validation, persistence, and numeric suggestions
- Add notification mechanism for main agent and subagents approaching maximum turn limits
- Improve inline completion cancellation and dismissal tracking
- Limit number of path completion entries to avoid performance issues
- Deliver plan mode toggle as a prefixed user-turn notice
- Sanitize `system` field in sent traffic data with truncation support

### Bug Fixes
- Fix chaining continuity issues and improve undo tool ledger logic
- Fix maxOutputTokens fallback to 4096 for non-Claude models
- Fix false positive from wrapToolInvoke scanning result strings for error types
- Fix corrupt tool display for resumed conversations
- Fix active prompt label wrapping for long input content
- Fix prompt token estimates
- Fix cannot leave empty handoff message (fallback to default now works)
- Fix completed commands stuck in dynamic render queue
- Fix already billable token usage handling in accumulators
- Update token prop in LargeUncachedConfirmationPrompt for consistency

### Improvements
- Refactor ask_user tool guidance for clarity and improved usage consistency
- Remove redundant "Decline to answer" instruction from ask_user tool description
- Extract provider middleware and session handling into dedicated modules
- Decouple session context management from LoggingService
- Extract warning injection logic from trim-tool-output.ts
- Streamline notification send method
- Improve command-safety classifications

### Internal/Chores
- Cleanup various code smells
- Improve sidebar in log viewer to work with complex multi-file nested structures

## [0.7.2] - 2026-05-31

### Features
- Add `maxParallelToolCalls` runtime setting for configuring parallel tool execution
- Add notification support when agent needs approval or finishes a task
- Display usage data (token counts) when resuming a conversation
- Enhance focus handling and input sequence fixes
- Add robust large uncached input handling with confirmation prompt
- Enhance handoff flow with dynamic message prompts and input handling
- Implement lazy-load to reduce memory usage
- Improve conversation filtering and error handling in `--resume ls`
- Add function to strip RTK's "No hook installed" warning from stderr output

### Bug Fixes
- Fix render performance issue when resuming conversation
- Fix wrong token usage display and token estimation in large uncached input warning
- Prevent truncation when saving conversation
- Fix streamed transient retries to preserve completed tool-call progress for non-chaining providers
- Fix retry command to correctly send back tool calls after user message
- Fix StatusBar time display for resets within 24 hours
- Fix fallback responses crash when missing `output` in WebSocket responses
- Fix memory leak
- Fix GPT prompts to follow Codex guidelines

### Improvements
- Rename `estimatedTokens` to `accumulatedInputTokens` in LargeUncachedConfirmationPrompt for clarity
- Split language providers per file and add more language definitions
- Remove title and headerRight props from multiple selection menus for cleaner UI
- Replace `writeBoundary` with `tags` in schemas and update related tests
- Cache custom provider instance to improve model retrieval performance

### Internal/Chores
- Bump `ink-prompt` to v0.3.0
- Add regression test for lazy provider instance reuse across `getModel` calls

## [0.7.1] - 2026-05-29

### Features
- Introduce `TimedResponsesWSModel` with configurable timeouts and enhanced WebSocket error handling
- Add `firstFrameTimeoutMs` for configurable WebSocket connection timeouts
- Improve WebSocket error handling with close code and reason tracking
- Add automatic retry for transient WebSocket 1006 connection closures
- Add `--resume ls` and metadata-rich conversation listing for session management
- Implement OSC 52 clipboard support for improved SSH clipboard handling
- Add `assistant_turn` events and persisted turn item support for more robust conversation replay
- Handle reasoning in `rawContent` for persisted turn items, improving reasoning round-trip across sessions
- Enhance continuation handling and logging in conversation sessions
- Add large uncached input warnings and confirmation prompts in the status bar
- Enhance error logging with stack traces and improved formatting
- Enhance `/undo` and `/retry` commands to handle image attachments
- Add `parentTool` to `subagent_started` events for mentor subagent parent tracking
- Handle mid-turn interruptions and incomplete tool batches during conversation replay
- Extend `apply_patch_call` support and improve argument normalization
- Enhance tool execution ledger and conversation session state management for recovery
- Adjust Codex provider request timeout and retry policy
- Tab-completing `/undo` now opens the undo selection menu directly

### Bug Fixes
- Fix missing `rawContent` in replayed reasoning items during conversation restoration
- Fix conversation store history duplication after interrupted tool batches
- Fix reordered full-snapshot supersets being incorrectly accepted in `updateFromClient`
- Fix missing or empty terminal response output in `CodexResponsesModel`
- Fix `use-conversation` logging stack property leaked through `rawEvent`
- Fix flaky test suite: resolve race conditions, timing sensitivity, and open handles
- Increase default timeout for edit healing model

### Improvements
- Refactor conversation event logging: replace `assistant_final` with `assistant_turn` and streamline session logging
- Optimize project tree rendering with breadth-first search for improved performance
- Remove mode notice handling and related code for clarity
- Remove `writeBoundary` parameter from subagent definitions
- Remove redundant recovery message checks from conversation replay and tool execution tests
- Improve patch error messages for clarity and consistency
- Centralize WebSocket timeouts in `DEFAULT_TIMED_WS_TIMEOUTS`
- Simplify `ConversationStore` API with identity-aware merge strategy
- Refactor app commands hook for cleaner structure
- Rename `OpencodeMinimaxHybridProvider` to `OpencodeAnthropicFormatProvider`
- Use system temp directory for test files and add cleanup logic
- Streamline assistant guidelines and update test command in package.json

### Internal/Chores
- Remove unused `CODEX_REQUEST_TIMEOUT_MS` and `CODEX_MAX_RETRIES` constants
- Remove file reference guidelines from GPT-5 prompt
- Update `SHELL_AUTO_APPROVAL_PROMPT_VERSION` to v5 and refine approval prompt
- Update readme and AGENTS.md

## [0.7.0] - 2026-05-26

### Features
- Add `/handoff` command and workflow for transferring assistant responses between sessions
- Add `/retry` command to re-send the last user message
- Implement event-log conversation persistence for reliable session saving and resumption
- Add tool execution ledger for stream failure recovery
- Implement project tree generation with custom ignore rules and limits
- Add Codex rate limit information display in the status bar
- Introduce `auto`, `on`, and `off` options for `searchViaShell` setting
- Add reasoning efficiency guidance to system prompts
- Enhance subagent recoverable error handling and retry logic
- Add `callId` field to message types for better message tracking
- Implement `switchProvider` with safety guard for runtime provider changes
- Add `large-uncached-input` guard to prevent excessive input sizes
- Handle truncated events during conversation replay
- Sanitize nested subagent results in conversation logs
- Enhance `apply-patch` error reporting for invalid diffs and context mismatches
- Add `combineAbortSignals` utility for improved tool execution control
- Enrich error context with event details for better debugging
- Add duplicate tool call/result pair detection and warnings in streams
- Ensure stable fallback session ID for opencode across turns
- Integrate traffic context session ID for opencode headers
- Cache model instances in Opencode provider for efficiency
- Resolve and apply default reasoning level for Codex models

### Bug Fixes
- Fix undo not working correctly when there is an error on the last turn
- Fix newline dropped when emitting reasoning delta in stream event processor
- Fix stale path entries not being refreshed in `use-path-completion`
- Fix rejected commands not being preserved during message extraction
- Fix approval-rejected commands not rendering correctly in the UI
- Fix Codex rate limit handling and provider reset behavior
- Fix rate limit extraction and StatusBar rendering for Codex
- Fix input-box handling of direct command triggers vs settings menu
- Fix prompt test suite

### Improvements
- Centralize error description with `describeError` and enhance retry logic
- Deduplicate `tool_started` events and normalize tool call arguments
- Replace `writeLastPointer` with `saveLastConversation` for more robust persistence
- Extract match context and approval logic into utility functions for `search-replace`
- Improve category lookup and test coverage in settings
- Add `onReset` option to `useSettingsValueCompletion` and refactor reset handling
- Track subagent usage and integrate into session management
- Introduce prompt profiles and restructure prompt selection
- Add modular middleware and session handling for OpenAI-compatible providers
- Simplify token refresh logic in Codex provider
- Refactor `useSelection` state handling and stabilize tests
- Include plan-mode-info in standard mode for cache stability
- Clarify and expand Plan Mode drafting requirements in docs

## [0.6.1] - 2026-05-23

### Features
- **SSH session resumption**: Resume SSH sessions with `--resume`, including full SSH options support in the resume command.
- **Session archiving**: Cleared conversations are now archived and assigned a fresh session ID, preserving history without cluttering the active session.
- **Subagent auto-approval**: Shell commands rated YELLOW (low-risk) are now auto-approved when issued by subagents, reducing interruptions during delegated tasks.
- **Flex tier retry**: Automatically retries requests when the flex tier fails.
- **OpenRouter reasoning**: Reasoning details in OpenRouter API requests are now preprocessed for improved compatibility.
- **Conversation history repair**: Automatic cleanup and optimization of conversation history to recover from corrupted or oversized state.

### Bug Fixes
- Fixed incorrect model sort order when a filter is active.
- Fixed missing task context when subagents request auto-approval, restoring correct approval decisions.

### Improvements
- Plan Mode and Subagent Delegation instructions are now only included in the system prompt when those modes are active, reducing token usage.
- Shell command auto-approval evaluations now use structured output and caching for faster, more consistent decisions.
- Provider traffic logs reorganized into a flat per-day folder layout with millisecond-precision timestamps and key-value labels for easier querying.

## [0.6.0] - 2026-05-21

### Features
- **Orchestrator mode**: New mode that delegates tasks to specialized subagents with shell access for complex multi-step work
- **Plan mode**: Read-only mode for researching and proposing step-by-step implementation plans before making changes
- **Undo / Rewind**: Select any past user message and rewind the conversation to that point
- **Conversation persistence**: Automatically save and resume sessions with `--resume`; conversations are now project-aware
- **Slash command completion**: Tab-complete slash commands from the input field
- **Anthropic prompt caching**: Reduced latency and cost when using Anthropic providers
- **Provider override**: Specify a provider directly via CLI flag with validation
- **OpencodeMinimaxHybrid provider**: New provider option for hybrid routing
- **Web-fetch improvements**: Large results saved to a temp file instead of being truncated in context
- **Enhanced undo**: ESC key resets input and mode in contextual states; terminal redraws correctly after undo
- **Settings menu**: Stays open after changing a setting so you can adjust multiple options without reopening
- **Grep enhancements**: File pattern filtering and improved charset handling for binary-safe output
- **Input surge guard**: Detects and blocks abrupt message growth or replayed tool-call histories to prevent runaway loops
- **Subagent editing model**: Subagents can now prefer a dedicated editing model for file operations
- **Task preview**: Longer previews with smarter truncation for subagent task descriptions

### Bug Fixes
- Fixed undo not working when using the Responses API (chaining provider)
- Fixed history navigation (up-arrow) losing image attachments
- Fixed plan mode incorrectly prompting for approval on edit tools
- Fixed prompt cache breaking when exiting plan mode
- Fixed errors from input surge guard not surfacing in the UI
- Fixed failed user messages not being cleaned up on non-retryable provider errors
- Fixed reasoning blocks being dropped before pending or running tool calls
- Fixed stream cancellation not being handled correctly in the event processor
- Fixed newline normalization between code fences and the first line of code
- Fixed `cwd` missing from environment info in lite mode
- Fixed strict providers rejecting messages with a stray `index` field

### Improvements
- Simplified file editing: standard mode now allows writing anywhere in the workspace by default, removing the separate "edit mode"
- Subagents now respect abort signals so cancellation propagates cleanly through delegated runs
- Non-interactive mode has stricter security defaults
- Streaming reasoning and text deltas are logged to stderr for easier debugging
- Reasoning-efficiency guidance added to prompts to reduce unnecessary thinking steps

## [0.5.0] - 2026-05-18

### Features
- **Subagents**: Added subagent support with real-time activity rendering, token usage tracking, and dynamic role descriptions
- **Clipboard command**: Added `/clipboard` command with async support
- **Reasoning cancellation**: Added cancellation and finalize handling for reasoning deltas

### Bug Fixes
- Fixed blank lines being stranded mid-history during chunked reasoning
- Fixed markdown heading depths and spacing being lost in streaming/continuation messages
- Fixed double-counting in token usage tracking for multi-turn tasks
- Fixed token usage counting across streamed turns

### Improvements
- Improved search-replace tool to reject identical search and replace content
- Improved command safety: external paths now require approval; temporary directories handled safely
- Replaced `bash-parser` with `unbash` for more reliable command parsing and safety
- Improved prompt cache control targeting for compatible models
- Token usage now merged across auto-approved and continuation events

## [0.4.0] - 2026-05-16

### Features

- **Token usage tracking and reporting** — Session token usage is now tracked and propagated through the approval flow with billable calculations
- **Code context tools** — New code searching capabilities with multi-language support for better code exploration
- **apply_patch tool** — Direct support for applying patches to files
- **Reasoning formatting** — Reasoning and streaming text now rendered with Markdown formatting for better readability
- **Auto-healing enhancements** — Improved auto-healing with detailed failure reasons and extended recovery capabilities
- **File batch operations** — Support for parallel edits with file locking utilities
- **Slash command additions** — New `/effort` slash command for configuring reasoning effort levels
- **Provider expansion** — Anthropic and Google now available as first-class provider types; OpenCode provider added with session headers
- **Search tool improvements** — Search output now uses plain-text format for better efficiency; added `no_ignore` option for search and file tools
- **Settings enhancements** — Support for optional `baseUrl` configuration in providers; current setting values now highlighted in suggestions
- **Cache control** — Prompt cache now applied to last two messages for extended context preservation

### Bug Fixes

- **Dotfiles in file matching** — Dotfiles are now properly included in file matching operations
- **Conversation event handling** — Fixed flushing and correction issues in conversation event processing
- **Batched replacements** — Improved error handling and increased edit-healing timeout
- **Reasoning text persistence** — Fixed reasoning text being reset when restarting after tool execution
- **Shell command handling** — Fixed hanging issue with shell commands expecting stdin input
- **Rendering improvements** — Better fallback rendering in shell prompts and approval flows
- **Layout fixes** — Fixed horizontal padding alignment between static and active message sections; improved table layout width propagation
- **Provider configuration** — Fixed support for empty `apiKey` in provider configuration

### Improvements

- Enhanced token usage extraction and caching logic
- Improved command safety inspection and path analysis
- Better message streaming with streamlined status bar alignment
- OpenAI-compatible message sanitization for improved compatibility
- Optimized settings menu with scrollable result list and better filtering
- Disabled OpenAI agents tracing globally by default for reduced overhead

## [0.3.1] - 2026-05-10

### Features
- Add OpenRouter provider support via AI SDK integration
- Normalize assistant reasoning handling across AI SDK models
- Add reasoning-delta event streaming support for improved real-time reasoning output

### Bug Fixes
- Fix incorrect model list loading when rapidly switching between providers

## [0.3.0] - 2026-05-10

### Features
- Support image pasting in the terminal
- Add configurable paste threshold setting
- Vercel AI SDK integration for additional provider support

### Bug Fixes
- Fix models endpoint path for OpenAI-compatible providers

### Improvements
- Improve table column width calculation and terminal wrapping
- Ensure table borders adapt to terminal width and align with rows

## [0.2.0] - 2026-05-08

### Features
- Model setting configurations and provider handling for edit-healing
- Exa search provider integration
- `/copy` command to copy the last assistant message
- `/auto-approve` slash command with enhanced StatusBar UI
- Shell command auto-approval advisory mode with LLM-based safety evaluation and configurable settings
- Auto-approval system with batch evaluation, caching, and leaderboard functionality
- Auto-approval evaluator with YAML-based multi-provider/model configuration
- Severity-weighted scoring and wrong-approval penalty in leaderboard calculations
- Prompt version handling for improved result tracking
- Current date in system prompt
- Default path for `--models-file` with improved model runs validation

### Bug Fixes
- Fixed reasoning_content not included when using openai-compatible providers
- Fixed stale closures in keyboard handlers and provider switching
- Ensured reasoning_content correctly replaces reasoning in openai-compatible tests and model logic

### Improvements
- Table rendering with word wrapping and width constraints
- Enhanced command safety classification and advisory logic for improved risk assessment
- Improved logging for openai-compatible providers
- Unified traffic log structure with simplified cleanup logic
- Shell auto-approval evaluator with compact history context and truncation logic
- Command search results now prioritized and sorted alphabetically
- Reduced noisy logs throughout the application
- Decoupled business logic and state management from main UI component
- Decomposed ConversationSession into focused collaborator modules
- Enhanced error handling and retry logic for rate-limited operations

### Internal/Chores
- Tests refactored to improve maintainability and coverage
- Extracted shared selection logic into useSelection hook
- Refactored approval rejection interceptor with comprehensive tests
- Refactored InputBox into focused hooks and pure helpers
- Replaced async result promises with async generators in conversation session flow
- Upgraded @openai/agents, ink, and ink-prompt dependencies

## [0.1.8] - 2026-02-14

### Features
- Dynamically calculate input box width based on current mode and terminal size
- Introduce `usage_update` event to provide real-time token usage during streaming
- Implement JSON repair for tool inputs and expand model error recovery with explicit error context
- Implement gap matching in the search-replace tool, allowing `<...>` in `search_content` to skip intermediate text
- Enable DEC Mode 2026 synchronized output to prevent terminal flickering during Ink rendering by patching `process.stdout`

### Bug Fixes
- Fix tilde operator (~) not expanding to home directory in path parameter of tools

### Internal/Chores
- Implement conversation flow refactor
- Add resume functionality to the release script
- Update documentation

## [0.1.7] - 2026-02-09

### Bug Fixes
- Normalized tool call name before emitting to agent runtime
- Make defaulted tool params optional and fix OpenAI strict schemas
- Refine changelog generation to exclude markdown code blocks and comments

### Internal/Chores
- Cleanup changelog

## [0.1.6] - 2026-02-09

### Features

- Improve message logging with enhanced logging contract and trace taxonomy
- Improve log viewer UI with debugging upgrades
- Add non-interactive mode for CLI usage

### Bug Fixes

- Clear token usage when running /clear command

### Improvements

- Use provider capabilities for better provider abstraction
- Refine apply_patch approval prevalidation behavior
- Reset mentor state when rebuilding main agent

### Internal/Chores

- Extract prompt selector for cleaner separation of concerns
- Extract approval state holder for better state management
- Extract command message streaming helper for reusability
- Extract stream event parsing helpers for maintainability
- Unify CommandMessage type across codebase
- Centralize tool name constants
- Extract streaming session factory for dependency injection
- Decompose settings service for better modularity
- Add conversation integration test coverage for stream, approval, and retry scenarios
- Set up Husky and lint-staged for pre-commit code formatting with Prettier
- Update coding style to follow industry standards

## [0.1.5] - 2026-02-07

### Features

- Display token usage in conversations
- Add a global tool-output character cap to limit output verbosity

### Bug Fixes

- Show error when fetching model fails instead of silently skipping it
- Fix reject flow with Esc key producing incorrect message history
- Fix schema validation issues
- Trim whitespaces in command arguments
- Handle SSH find_files patterns without fd utility

### Improvements

- Refactor: Extract web-fetch to standalone package for reusability

### Internal/Chores

- Update README documentation

## [0.1.4] - 2026-01-30

### Features

- Add web_fetch tool for fetching and processing web content
- Implement AI-powered healing for malformed edit patches
- Add conversion of GitHub file URLs to raw links for improved accessibility
- Implement EOL normalization and comment stripping for search/replace tool
- Use incremental rendering to reduce flickering and improve performance

### Bug Fixes

- Fix issue where RED level commands were hard-blocked even after user approval
- Merge consecutive messages with the same role before sending to API
- Update text colors for better visibility and consistency across components
- Ensure npm authentication before publishing in release script

### Improvements

- Update changelog generation to use Haiku model for improved output quality
- Refactor use-conversation hook and improve test coverage

### Internal/Chores

- Bump Ink version to 6.6.0
- Add planning for GitHub Copilot SDK as provider

## [0.1.3] - 2026-01-28

### Features

- Add normalized whitespace matching to search-replace tool
- Modified ESC key behavior in settings menu to step back one level at a time instead of closing completely
- Add 'flex' service tier for OpenAI provider
- Fetch fresh project context when starting a new conversation
- Redesign and revamp settings menu to improve UX

### Bug Fixes

- Display create_file tool approval in clean format, consistent with other tools
- Fix read_file tool test
- Fix mentor usage with different provider than main model
- Fix tool schema issues
- Fix type errors from new SDK version
- Allow custom values for number-based settings
- Make tool definitions strictly compliant with OpenAI's "Structured Outputs" requirements
- Update text and reasoning colors for better visibility
- Fix markdown blockquote renderer wrapping block-level elements inside Text component

### Improvements

- Enhance read_file tool output to be clearer
- Enhance release script with health checks and final verification

### Internal/Chores

- Update OpenAI Agents SDK to 0.4.3

## [0.1.2] - 2026-01-23

### Features

- Modified ESC key behavior in settings menu to step back one level at a time instead of closing completely
- Add 'flex' service tier for OpenAI provider
- Fetch fresh project context when starting a new conversation
- Redesigned settings menu with improved UX
- Enhanced release script with health checks and final verification

### Bug Fixes

- Allow custom values for number-based settings
- Tool definitions now strictly compliant with OpenAI's "Structured Outputs" requirements
- Update text color for better visibility
- Update reasoning text color for better visibility
- Markdown blockquote renderer no longer wraps block-level elements inside Text components

### Internal/Chores

- Fix tests

# Changelog

## [0.1.1] - 2026-01-20

### Features

- Add create file tool
- Add web search tool to agent definition

### Bug Fixes

- Fix reasoning content not displaying for OpenAI-compatible providers
- Fix tools to work outside of workspace in lite mode

### Improvements

- Refactor mentor mode prompt
- Update lite prompt documentation

### Internal/Chores

- Add release script
- Update README documentation
