import { APIError } from 'openai';
import { OpenAICompatibleError } from './common/provider-errors.js';

/** Object-shaped check shared by the chat-completions adapter and its helpers. */
export const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

/** Longest upstream `raw` payload kept in the user-facing message; the full body stays in `responseBody`. */
const MAX_UPSTREAM_RAW_LENGTH = 500;

/**
 * Upstream detail a gateway attaches to an in-band error: OpenRouter reports the
 * failing provider as `error.metadata.provider_name` and its payload as
 * `error.metadata.raw` (a string or a JSON object). A null raw value carries
 * nothing and is skipped.
 */
function upstreamDetail(record: Record<string, unknown> | undefined): string | undefined {
  const nested = record && isRecord(record.error) ? record.error : undefined;
  const metadata = [record?.metadata, nested?.metadata].find(isRecord);
  if (!metadata) return undefined;

  const provider = typeof metadata.provider_name === 'string' ? metadata.provider_name.trim() : '';
  let raw: string | undefined;
  if (typeof metadata.raw === 'string') {
    raw = metadata.raw;
  } else if (metadata.raw != null) {
    try {
      raw = JSON.stringify(metadata.raw);
    } catch {
      raw = undefined;
    }
  }
  raw = raw?.trim().slice(0, MAX_UPSTREAM_RAW_LENGTH);

  if (provider && raw) return `upstream provider ${provider}: ${raw}`;
  if (provider) return `upstream provider ${provider}`;
  if (raw) return `upstream detail: ${raw}`;
  return undefined;
}

/**
 * Turns an in-band error payload into the adapter's provider error. When
 * `reportsUpstream` is set (a gateway such as OpenRouter), the upstream
 * provider and its raw detail are appended to the message; other
 * chat-completions providers keep the plain message.
 */
export function normalizeChatCompletionError(error: unknown, reportsUpstream = false): OpenAICompatibleError {
  const record = isRecord(error) ? error : undefined;
  const nested = record && isRecord(record.error) ? record.error : undefined;
  const code = record?.code ?? record?.status ?? record?.statusCode ?? nested?.code ?? nested?.status;
  const numericStatus =
    typeof code === 'number' && Number.isInteger(code)
      ? code
      : typeof code === 'string' && /^\d+$/.test(code.trim())
      ? Number(code)
      : undefined;
  const symbolicCode = typeof code === 'string' ? code.toLowerCase() : '';
  const status =
    numericStatus ??
    (symbolicCode.includes('rate_limit') || symbolicCode.includes('too_many_requests')
      ? 429
      : symbolicCode.includes('invalid')
      ? 400
      : symbolicCode.includes('auth')
      ? 401
      : symbolicCode.includes('permission')
      ? 403
      : symbolicCode.includes('not_found')
      ? 404
      : 502);
  const baseMessage =
    (typeof record?.message === 'string' && record.message) ||
    (typeof nested?.message === 'string' && nested.message) ||
    (typeof error === 'string' ? error : 'OpenAI-compatible provider returned an in-band error');
  const detail = reportsUpstream ? upstreamDetail(record) : undefined;
  const message = detail ? `${baseMessage} (${detail})` : baseMessage;
  let responseBody: string | undefined;
  try {
    responseBody = JSON.stringify(error);
  } catch {
    responseBody = undefined;
  }
  return new OpenAICompatibleError(message, status, {}, responseBody);
}

/**
 * An in-band `error` frame that the OpenAI client has already thrown, with no HTTP
 * status. Connection and abort errors are subclasses of APIError with the same
 * shape, so match the exact class.
 */
const isClientInBandError = (error: unknown): error is APIError =>
  error instanceof APIError && error.constructor === APIError && error.status === undefined && error.error != null;

/**
 * Frames of a gateway stream, as the adapter needs to see them. The OpenAI client
 * settles two outcomes before the adapter does, and a gateway needs both mapped back:
 * an in-band `error` frame is thrown as its own APIError, which drops the upstream
 * detail; and a read aborted by the caller ends the iteration quietly, so the
 * adapter would report a stream without a finish reason (a transient failure to
 * the retry layer) instead of a cancellation.
 */
export async function* gatewayStreamFrames(
  stream: AsyncIterable<unknown>,
  signal?: AbortSignal,
): AsyncGenerator<unknown> {
  try {
    for await (const frame of stream) yield frame;
  } catch (error) {
    if (isClientInBandError(error)) throw normalizeChatCompletionError(error.error, true);
    throw error;
  }
  if (signal?.aborted) throw Object.assign(new Error('The operation was aborted.'), { name: 'AbortError' });
}
