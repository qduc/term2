import OpenAI from 'openai';
import { RetryingModel } from './retrying-model.js';
import { registerProvider } from './registry.js';
import type { ProviderDeps, ProviderFetch } from './registry.js';
import { createProviderFetch } from './fetch/composer.js';
import type { FetchMiddleware } from './fetch/compose.js';
import { addCacheControlToLastTwoMessages } from './anthropic-chat-caching.js';
import { normalizeBaseUrl } from './common/openai-compatible-utils.js';
import { OpenAIChatCompletionsModel } from './openai-chat-completions-model.js';
import { isRecord } from './openai-chat-completions-errors.js';
import { NULL_SESSION_CONTEXT_SERVICE } from '../traffic-context.js';
import type { StreamedModelTurn } from '../streamed-model-turn.js';

const DEFAULT_BASE_URL = 'https://openrouter.ai/api/v1';
const DEFAULT_REFERRER = 'https://github.com/qduc/term2';
const DEFAULT_TITLE = 'term2';

/**
 * OpenRouter is served by the application-owned chat-completions adapter. The
 * OpenAI client only carries transport; retries belong to RetryingModel alone.
 */
function createOpenRouterModel(deps: ProviderDeps, model: string): OpenAIChatCompletionsModel | null {
  const { settingsService, loggingService, sessionContextService } = deps;
  const apiKey = settingsService.get('agent.openrouter.apiKey') || process.env.OPENROUTER_API_KEY;
  if (!apiKey) return null;

  const referrer = settingsService.get('agent.openrouter.referrer') || DEFAULT_REFERRER;
  const title = settingsService.get('agent.openrouter.title') || DEFAULT_TITLE;
  const client = new OpenAI({
    apiKey,
    baseURL: normalizeBaseUrl(settingsService.get('agent.openrouter.baseUrl') || DEFAULT_BASE_URL),
    // Attribution headers: the referrer, and the title under both spellings OpenRouter reads.
    defaultHeaders: { 'HTTP-Referer': referrer, 'X-Title': title, 'X-OpenRouter-Title': title },
    maxRetries: 0,
    fetch: createProviderFetch({
      providerId: 'openrouter',
      defaultModel: settingsService.get('agent.modelSelection').model || model,
      deps: {
        loggingService,
        sessionContextService: sessionContextService ?? NULL_SESSION_CONTEXT_SERVICE,
        onDispatched: deps.onDispatched,
      },
      middlewares: [openRouterRequestMiddleware, openRouterPreprocessingMiddleware],
    }),
  });
  return new OpenAIChatCompletionsModel(client, model, undefined, 'openrouter', 'openrouter');
}

/**
 * Shapes the chat-completions body into OpenRouter's request. Provider options
 * arrive top-level, under `openrouter`, or under `providerOptions.openrouter`;
 * they are flattened so that later namespaces win, and the wrapper keys never
 * reach the wire. Reasoning is `reasoning: { effort }`, never `reasoning_effort`:
 * an explicit top-level `reasoning` wins, then an explicit namespaced one, and
 * only then the selected effort (`default` means no preference).
 */
function shapeOpenRouterChatBody(body: Record<string, unknown>): Record<string, unknown> {
  const {
    openrouter,
    providerOptions,
    reasoning_effort: selectedEffort,
    reasoning: topLevelReasoning,
    ...fields
  } = body;
  const wrapped = isRecord(providerOptions) && isRecord(providerOptions.openrouter) ? providerOptions.openrouter : {};
  const namespaced: Record<string, unknown> = { ...(isRecord(openrouter) ? openrouter : {}), ...wrapped };
  const shaped: Record<string, unknown> = { ...fields, ...namespaced };

  const effort = typeof selectedEffort === 'string' && selectedEffort !== 'default' ? selectedEffort : undefined;
  const reasoning = topLevelReasoning ?? namespaced.reasoning ?? (effort ? { effort } : undefined);
  delete shaped.reasoning;
  if (reasoning != null) shaped.reasoning = reasoning;

  // tool_choice is meaningless without tools and rejected by some routes.
  if (!Array.isArray(shaped.tools) || shaped.tools.length === 0) delete shaped.tool_choice;
  return shaped;
}

const openRouterRequestMiddleware: FetchMiddleware = async (ctx, next) => {
  if (typeof ctx.init?.body !== 'string') return next(ctx);
  let body: unknown;
  try {
    body = JSON.parse(ctx.init.body);
  } catch {
    return next(ctx);
  }
  if (!isRecord(body)) return next(ctx);
  return next({ ...ctx, init: { ...ctx.init, body: JSON.stringify(shapeOpenRouterChatBody(body)) } });
};

function sanitizeOpenRouterReasoningDetails(messages: any[]): void {
  const requiresSignature = new Set(['google-gemini-v1', 'anthropic-claude-v1']);
  for (const message of messages) {
    if (!Array.isArray(message?.reasoning_details)) {
      continue;
    }
    message.reasoning_details = message.reasoning_details.filter((detail: any) => {
      if (detail?.type !== 'reasoning.text') {
        return true;
      }
      if (!requiresSignature.has(detail?.format)) {
        return true;
      }
      return Boolean(detail?.signature);
    });
  }
}

export const openRouterPreprocessingMiddleware: FetchMiddleware = async (ctx, next) => {
  if (typeof ctx.init?.body === 'string') {
    try {
      const body = JSON.parse(ctx.init.body);
      if (Array.isArray(body?.messages)) {
        sanitizeOpenRouterReasoningDetails(body.messages);
        addCacheControlToLastTwoMessages(body.messages, body.model);
        ctx.init = { ...ctx.init, body: JSON.stringify(body) };
      }
    } catch {
      /* fall through */
    }
  }
  return next(ctx);
};

async function fetchOpenRouterModels(
  deps: ProviderDeps,
  fetchImpl: ProviderFetch = fetch,
): Promise<Array<{ id: string; name?: string }>> {
  const { settingsService } = deps;

  const baseUrl = settingsService.get('agent.openrouter.baseUrl') || 'https://openrouter.ai/api/v1';
  const apiKey = settingsService.get('agent.openrouter.apiKey') || process.env.OPENROUTER_API_KEY;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (apiKey) {
    headers.Authorization = `Bearer ${apiKey}`;
  }

  const response = await fetchImpl(`${baseUrl}/models`, { headers });
  if (!response.ok) {
    throw new Error(`OpenRouter models request failed (${response.status})`);
  }

  const body = await response.json();
  const twoYearsAgo = new Date();
  twoYearsAgo.setUTCFullYear(twoYearsAgo.getUTCFullYear() - 2);
  const minimumCreatedAt = twoYearsAgo.getTime() / 1000;
  const filteredData = (body?.data || []).filter(
    (item: any) =>
      Array.isArray(item?.supported_parameters) &&
      item.supported_parameters.includes('tools') &&
      typeof item.created === 'number' &&
      Number.isFinite(item.created) &&
      item.created >= minimumCreatedAt,
  );

  if (!Array.isArray(filteredData)) return [];

  return filteredData
    .map((item: any) => {
      const id = item?.id || item?.model || '';
      const name = item?.name || item?.display_name || item?.description;
      return id ? { id, name } : null;
    })
    .filter(Boolean) as Array<{ id: string; name?: string }>;
}

// Register OpenRouter provider
registerProvider(
  {
    id: 'openrouter',
    label: 'OpenRouter',
    createStreamedModel: async (model, deps): Promise<StreamedModelTurn> => {
      const streamedModel = createOpenRouterModel(deps, model);
      if (!streamedModel) throw new Error('OpenRouter API key is not configured');
      const retryAttempts = deps.retryAttempts ?? deps.settingsService.get('agent.retryAttempts') ?? 2;
      return new RetryingModel(streamedModel, {
        retryAttempts,
        loggingService: deps.loggingService,
        onRetry: deps.onRetry,
      });
    },
    fetchModels: fetchOpenRouterModels,
    sensitiveSettingKeys: [
      'agent.openrouter.apiKey',
      'agent.openrouter.baseUrl',
      'agent.openrouter.referrer',
      'agent.openrouter.title',
    ],
    capabilities: {
      supportsFlexServiceTier: true,
      supportsConversationChaining: false,
    },
  },
  { builtin: true },
);
