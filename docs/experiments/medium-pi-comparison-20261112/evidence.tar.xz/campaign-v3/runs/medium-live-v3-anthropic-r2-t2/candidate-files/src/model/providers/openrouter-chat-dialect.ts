/**
 * OpenRouter's wire rules on top of the application-owned chat-completions
 * adapter: reasoning as `reasoning: { effort }`, flattened provider options,
 * tool choice only with tools, upstream provider reporting, and upstream error
 * detail. Consumed by `openrouter.provider.ts`; generic providers never see it.
 */
import type { ChatCompletionsDialect } from './openai-chat-completions-model.js';
import { toChatToolChoice } from './openai-chat-completions-model.js';
import type { FetchMiddleware } from './fetch/compose.js';
import type { StreamedModelTurnRequest } from '../streamed-model-turn.js';

/** Option wrappers that are flattened into the body and never sent themselves. */
const OPTION_WRAPPER_KEYS = new Set(['openrouter', 'providerOptions']);

const asRecord = (value: unknown): Record<string, unknown> | undefined =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : undefined;

/**
 * Body fields for one request. The selected effort is the default reasoning;
 * explicit reasoning overrides it. Options are flattened in the order top-level,
 * `openrouter`, `providerOptions.openrouter`, so later namespaced values win,
 * except a top-level `reasoning`, which wins over every namespaced one.
 */
export function openRouterRequestFields(request: StreamedModelTurnRequest): Record<string, unknown> {
  const options = request.providerOptions ?? {};
  const topLevel: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(options)) {
    if (!OPTION_WRAPPER_KEYS.has(key)) topLevel[key] = value;
  }
  const direct = asRecord(options.openrouter) ?? {};
  const nested = asRecord(asRecord(options.providerOptions)?.openrouter) ?? {};
  const effort = request.reasoning?.effort;
  return {
    ...(request.tools.length && request.toolChoice !== undefined
      ? { tool_choice: toChatToolChoice(request.toolChoice) }
      : {}),
    ...(effort && effort !== 'default' ? { reasoning: { effort } } : {}),
    ...topLevel,
    ...direct,
    ...nested,
    ...(topLevel.reasoning !== undefined ? { reasoning: topLevel.reasoning } : {}),
  };
}

/** Extracts the human-readable detail from an upstream `raw` value (string or JSON object). */
function rawErrorMessage(raw: unknown): string | undefined {
  if (typeof raw === 'string') {
    try {
      const parsed: unknown = JSON.parse(raw);
      return asRecord(parsed) ? rawErrorMessage(parsed) : raw;
    } catch {
      return raw;
    }
  }
  const record = asRecord(raw);
  if (!record) return undefined;
  for (const field of ['message', 'error', 'detail', 'details', 'msg']) {
    const value = record[field];
    if (typeof value === 'string' && value.length > 0) return value;
    if (value && typeof value === 'object') {
      const nested = rawErrorMessage(value);
      if (nested) return nested;
    }
  }
  return undefined;
}

/**
 * `[provider_name] <raw detail>` for an OpenRouter error object carrying
 * `metadata`. A null or empty `raw` is skipped and the error's own message used.
 */
export function openRouterErrorMessage(error: unknown): string | undefined {
  const record = asRecord(error);
  const metadata = asRecord(record?.metadata);
  if (!record || !metadata) return undefined;
  const base = typeof record.message === 'string' && record.message ? record.message : undefined;
  const raw = rawErrorMessage(metadata.raw);
  const detail = raw && raw !== base ? raw : base;
  if (!detail) return undefined;
  const provider =
    typeof metadata.provider_name === 'string' && metadata.provider_name ? `[${metadata.provider_name}]` : undefined;
  return provider ? `${provider} ${detail}` : detail;
}

/** The upstream provider OpenRouter reports on each chunk, carried as completion metadata. */
export function openRouterChunkMetadata(chunk: any): Record<string, unknown> | undefined {
  const provider = typeof chunk?.provider === 'string' ? chunk.provider.trim() : '';
  return provider ? { openrouter: { provider } } : undefined;
}

export const OPENROUTER_CHAT_DIALECT: ChatCompletionsDialect = {
  requestFields: openRouterRequestFields,
  errorMessage: openRouterErrorMessage,
  chunkMetadata: openRouterChunkMetadata,
};

/**
 * Rewrites a failed JSON response so the SDK-visible message carries upstream
 * detail. Headers are kept, so retry-after and request IDs still reach retry
 * classification. Successful and non-JSON responses pass through unchanged.
 */
export const openRouterErrorDetailMiddleware: FetchMiddleware = async (ctx, next) => {
  const response = await next(ctx);
  if (response.ok) return response;
  const text = await response.text();
  const headers = new Headers(response.headers);
  headers.delete('content-length');
  const rebuild = (body: string) =>
    new Response(body, { status: response.status, statusText: response.statusText, headers });
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    return rebuild(text);
  }
  const body = asRecord(parsed);
  const error = asRecord(body?.error);
  const message = openRouterErrorMessage(error);
  if (!body || !error || !message) return rebuild(text);
  return rebuild(JSON.stringify({ ...body, error: { ...error, message } }));
};
