import { createServer, type IncomingHttpHeaders, type Server } from 'node:http';
import type { AddressInfo, Socket } from 'node:net';
import { afterEach, expect, it } from 'vitest';
import '../../src/model/providers/index.js';
import { getProvider } from '../../src/model/providers/registry.js';
import { createCustomProviderModelProvider } from '../../src/model/providers/openai-compatible.provider.js';

/** Loopback OpenRouter-shaped endpoint: records each request and replies with scripted frames. */
type Reply = { status?: number; body?: unknown; frames?: unknown[]; holdOpen?: boolean };
type Captured = { url: string; headers: IncomingHttpHeaders; body: any };

const servers: Array<{ server: Server; sockets: Set<Socket> }> = [];
afterEach(async () => {
  for (const { server, sockets } of servers.splice(0)) {
    for (const socket of sockets) socket.destroy();
    await new Promise((resolve) => server.close(resolve));
  }
});

async function startEndpoint(reply: (index: number, body: any) => Reply) {
  const requests: Captured[] = [];
  const sockets = new Set<Socket>();
  const server = createServer((req, res) => {
    let raw = '';
    req.on('data', (chunk) => (raw += chunk));
    req.on('end', () => {
      const body = raw ? JSON.parse(raw) : undefined;
      requests.push({ url: req.url ?? '', headers: req.headers, body });
      const scripted = reply(requests.length - 1, body);
      if (scripted.status !== undefined) {
        res.writeHead(scripted.status, { 'content-type': 'application/json' });
        res.end(JSON.stringify(scripted.body ?? {}));
        return;
      }
      res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache' });
      for (const frame of scripted.frames ?? []) res.write(`data: ${JSON.stringify(frame)}\n\n`);
      if (scripted.holdOpen) return;
      res.write('data: [DONE]\n\n');
      res.end();
    });
  });
  server.on('connection', (socket) => sockets.add(socket));
  servers.push({ server, sockets });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const { port } = server.address() as AddressInfo;
  return { baseUrl: `http://127.0.0.1:${port}`, requests };
}

const quietLogging = { debug() {}, info() {}, warn() {}, error() {} } as any;

function openRouterSettings(baseUrl: string, extra: Record<string, unknown> = {}) {
  const values: Record<string, unknown> = {
    'agent.modelSelection': { model: 'openai/gpt-x', provider: 'openrouter' },
    'agent.retryAttempts': 0,
    'agent.openrouter.apiKey': 'fixture-key',
    'agent.openrouter.baseUrl': `${baseUrl}/api/v1`,
    'agent.openrouter.referrer': 'https://github.com/qduc/term2',
    'agent.openrouter.title': 'term2',
    ...extra,
  };
  return { get: (key: string) => values[key], getDynamic: () => undefined } as any;
}

async function openRouterModel(baseUrl: string, model = 'openai/gpt-x', deps: Record<string, unknown> = {}) {
  return getProvider('openrouter')!.createStreamedModel!(model, {
    settingsService: openRouterSettings(baseUrl),
    loggingService: quietLogging,
    ...deps,
  });
}

async function collect(stream: AsyncIterable<any>): Promise<any[]> {
  const events: any[] = [];
  for await (const event of stream) events.push(event);
  return events;
}

const userText = (text: string) => ({ type: 'message', role: 'user', content: [{ type: 'text', text }] });
const request = (overrides: Record<string, unknown> = {}): any => ({
  input: [userText('hello')],
  tools: [],
  ...overrides,
});

const chunk = (delta: Record<string, unknown>, extra: Record<string, unknown> = {}) => ({
  id: 'gen-1',
  object: 'chat.completion.chunk',
  created: 1,
  model: 'openai/gpt-x',
  provider: 'Upstream Co',
  choices: [{ index: 0, delta, finish_reason: null }],
  ...extra,
});
const finish = (reason: string, extra: Record<string, unknown> = {}) => ({
  id: 'gen-1',
  object: 'chat.completion.chunk',
  created: 1,
  model: 'openai/gpt-x',
  provider: 'Upstream Co',
  choices: [{ index: 0, delta: {}, finish_reason: reason }],
  ...extra,
});
const usage = {
  prompt_tokens: 10,
  completion_tokens: 2,
  total_tokens: 12,
  cost: 0.0012,
  prompt_tokens_details: { cached_tokens: 4 },
  completion_tokens_details: { reasoning_tokens: 1 },
};

it('sends reasoning as reasoning.effort, sets referrer/title headers, and sends tool_choice only with tools', async () => {
  const endpoint = await startEndpoint(() => ({ frames: [finish('stop')] }));
  const model = await openRouterModel(endpoint.baseUrl);

  await collect(model.stream(request({ reasoning: { effort: 'high' } })));
  const [wire] = endpoint.requests;
  expect(wire!.url).toBe('/api/v1/chat/completions');
  expect(wire!.headers).toMatchObject({
    authorization: 'Bearer fixture-key',
    'http-referer': 'https://github.com/qduc/term2',
    'x-title': 'term2',
    'x-openrouter-title': 'term2',
  });
  expect(wire!.body.reasoning).toEqual({ effort: 'high' });
  expect(wire!.body).not.toHaveProperty('reasoning_effort');
  expect(wire!.body).not.toHaveProperty('tool_choice');

  await collect(model.stream(request({ reasoning: { effort: 'default' }, toolChoice: 'required' })));
  expect(endpoint.requests[1]!.body).not.toHaveProperty('reasoning');
  expect(endpoint.requests[1]!.body).not.toHaveProperty('tool_choice');

  const tool = { name: 'lookup', description: 'Look up.', parameters: { type: 'object', properties: {} } };
  await collect(model.stream(request({ tools: [tool], toolChoice: 'required' })));
  expect(endpoint.requests[2]!.body).toMatchObject({
    tool_choice: 'required',
    tools: [{ function: { name: 'lookup' } }],
  });
});

it('flattens provider options with namespaced precedence, top-level reasoning winning, and no wrapper keys on the wire', async () => {
  const endpoint = await startEndpoint(() => ({ frames: [finish('stop')] }));
  const model = await openRouterModel(endpoint.baseUrl);

  await collect(
    model.stream(
      request({
        reasoning: { effort: 'high' },
        providerOptions: {
          transforms: ['middle-out'],
          openrouter: { user: 'direct', reasoning: { effort: 'low' } },
          providerOptions: { openrouter: { user: 'nested', top_k: 3 } },
        },
      }),
    ),
  );
  expect(endpoint.requests[0]!.body).toMatchObject({
    transforms: ['middle-out'],
    user: 'nested',
    top_k: 3,
    reasoning: { effort: 'low' },
  });
  expect(endpoint.requests[0]!.body).not.toHaveProperty('openrouter');
  expect(endpoint.requests[0]!.body).not.toHaveProperty('providerOptions');

  await collect(
    model.stream(
      request({
        providerOptions: { reasoning: { effort: 'minimal' }, openrouter: { reasoning: { effort: 'low' } } },
      }),
    ),
  );
  expect(endpoint.requests[1]!.body.reasoning).toEqual({ effort: 'minimal' });
});

it('streams text, reasoning, usage and cost, and reports the upstream provider only for OpenRouter', async () => {
  const frames = [
    chunk({ role: 'assistant', content: '', reasoning: 'Think.' }),
    chunk({ content: 'Hi' }),
    finish('stop', { usage }),
  ];
  const endpoint = await startEndpoint(() => ({ frames }));
  const events = await collect((await openRouterModel(endpoint.baseUrl)).stream(request()));

  expect(events.find((e) => e.type === 'reasoning_delta')).toMatchObject({ text: 'Think.' });
  expect(events.find((e) => e.type === 'text_delta')).toMatchObject({ text: 'Hi' });
  const completion = events.at(-1);
  expect(completion).toMatchObject({
    type: 'completion',
    finishReason: 'stop',
    usage: { inputTokens: 10, outputTokens: 2, cachedInputTokens: 4, reasoningTokens: 1 },
    costUsd: 0.0012,
    providerMetadata: { openrouter: { provider: 'Upstream Co' } },
  });

  const generic = createCustomProviderModelProvider(
    { name: 'generic-gateway', type: 'openai-compatible', baseUrl: `${endpoint.baseUrl}/v1`, apiKey: 'k' },
    { defaultModel: 'openai/gpt-x' } as any,
  ).getStreamedModel();
  const genericCompletion = (await collect(generic.stream(request()))).at(-1);
  expect(genericCompletion.type).toBe('completion');
  expect(genericCompletion.providerMetadata).toBeUndefined();
});

it('replays signed reasoning and the continuation payload, and keeps legacy reasoning as text after a switch', async () => {
  const detail = [
    { type: 'reasoning.text', text: 'Plan.', format: 'anthropic-claude-v1', index: 0, signature: 'sig-1' },
    { type: 'reasoning.text', text: 'Unsigned.', format: 'anthropic-claude-v1', index: 1 },
    { type: 'reasoning.text', text: 'Free.', format: 'unknown', index: 2 },
  ];
  const endpoint = await startEndpoint((index) =>
    index === 0
      ? {
          frames: [
            chunk({ role: 'assistant', content: '', reasoning: 'Plan.', reasoning_details: detail }),
            chunk({
              tool_calls: [
                { index: 0, id: 'call_1', type: 'function', function: { name: 'lookup', arguments: '{"q":' } },
              ],
            }),
            chunk({ tool_calls: [{ index: 0, function: { arguments: '"x"}' } }] }),
            finish('tool_calls'),
          ],
        }
      : { frames: [finish('stop')] },
  );
  const model = await openRouterModel(endpoint.baseUrl, 'anthropic/claude-test');
  const first = await collect(model.stream(request()));
  const output = first.at(-1).output as any[];
  expect(output.find((item) => item.type === 'provider_opaque')).toMatchObject({ provider: 'openrouter' });
  const toolCall = output.find((item) => item.type === 'tool_call');
  expect(toolCall).toMatchObject({ id: 'call_1', name: 'lookup', arguments: '{"q":"x"}' });

  await collect(
    model.stream(
      request({
        input: [
          userText('hello'),
          ...output,
          { type: 'tool_result', id: 'call_1', output: '{"ok":true}' },
          userText('summarize'),
        ],
      }),
    ),
  );
  const replayed = endpoint.requests[1]!.body.messages;
  const assistant = replayed.find((message: any) => Array.isArray(message.tool_calls));
  expect(assistant.reasoning).toBe('Plan.');
  expect(assistant.reasoning_details.map((entry: any) => entry.text)).toEqual(['Plan.', 'Free.']);
  expect(replayed.at(-1).content.at(-1).cache_control).toEqual({ type: 'ephemeral' });

  const endpointLegacy = await startEndpoint(() => ({ frames: [finish('stop')] }));
  const legacy = await openRouterModel(endpointLegacy.baseUrl);
  await collect(
    legacy.stream(
      request({
        input: [
          userText('hello'),
          { type: 'reasoning', text: 'Old plan.', providerMetadata: { openrouter: { reasoning_details: [] } } },
          { type: 'message', role: 'assistant', content: [{ type: 'text', text: 'Answer.' }] },
          { type: 'provider_opaque', provider: 'some-other-lane', item: { reasoning_content: 'foreign' } },
          userText('next'),
        ],
      }),
    ),
  );
  const legacyBody = endpointLegacy.requests[0]!.body;
  expect(legacyBody.messages).toContainEqual({ role: 'assistant', content: 'Old plan.' });
  expect(JSON.stringify(legacyBody)).not.toContain('foreign');
  expect(JSON.stringify(legacyBody)).not.toContain('reasoning_content');
});

it('surfaces upstream error detail for in-band and HTTP failures and retries only through RetryingModel', async () => {
  const errorFrame = {
    error: {
      code: 502,
      message: 'Provider returned error',
      metadata: { provider_name: 'Upstream Co', raw: { message: 'boom upstream' } },
    },
  };
  const held = await startEndpoint(() => ({ frames: [errorFrame], holdOpen: true }));
  const heldModel = await openRouterModel(held.baseUrl);
  const outcome = await Promise.race([
    collect(heldModel.stream(request())).then(
      () => 'completed',
      (error: any) => error,
    ),
    new Promise((resolve) => setTimeout(() => resolve('timed out'), 3000)),
  ]);
  expect(outcome).toMatchObject({ message: '[Upstream Co] boom upstream', status: 502 });

  const rawString = await startEndpoint(() => ({
    frames: [
      { error: { message: 'x', metadata: { provider_name: 'Upstream Co', raw: '{"detail":"quota exceeded"}' } } },
    ],
  }));
  await expect(collect((await openRouterModel(rawString.baseUrl)).stream(request()))).rejects.toMatchObject({
    message: '[Upstream Co] quota exceeded',
  });

  const nullRaw = await startEndpoint(() => ({
    frames: [{ error: { message: 'Provider returned error', metadata: { provider_name: 'Upstream Co', raw: null } } }],
  }));
  const nullError = await collect((await openRouterModel(nullRaw.baseUrl)).stream(request())).catch((e) => e);
  expect(nullError.message).toBe('[Upstream Co] Provider returned error');

  const http = await startEndpoint(() => ({
    status: 503,
    body: { error: { message: 'Service down', code: 503, metadata: { provider_name: 'Upstream Co', raw: null } } },
  }));
  const httpError = await collect((await openRouterModel(http.baseUrl)).stream(request())).catch((e) => e);
  expect(httpError.message).toBe('503 [Upstream Co] Service down');
  expect(httpError.status).toBe(503);
  expect(http.requests).toHaveLength(1);
});

it('retains the error frame of a closed error stream when a traffic recorder is active', async () => {
  const endpoint = await startEndpoint(() => ({
    frames: [{ error: { message: 'Recorded failure', metadata: { provider_name: 'Upstream Co', raw: null } } }],
  }));
  let recorded: string | undefined;
  const providerTraffic = {
    recordRequestStart() {},
    async recordResponseReceived(event: { response: Response }) {
      recorded = await event.response.text();
    },
    recordResponseClosed() {},
    recordRequestFailed() {},
  };
  const model = await openRouterModel(endpoint.baseUrl, 'openai/gpt-x', {
    loggingService: { ...quietLogging, providerTraffic },
  });
  await expect(collect(model.stream(request()))).rejects.toMatchObject({ message: '[Upstream Co] Recorded failure' });
  const deadline = Date.now() + 2000;
  while (recorded === undefined && Date.now() < deadline) await new Promise((resolve) => setTimeout(resolve, 10));
  expect(recorded).toContain('Recorded failure');
});

it('cancels an in-flight OpenRouter stream when the request signal aborts', async () => {
  const endpoint = await startEndpoint(() => ({ frames: [chunk({ content: 'part' })], holdOpen: true }));
  const model = await openRouterModel(endpoint.baseUrl);
  const controller = new AbortController();
  const iterator = model.stream(request({ signal: controller.signal }))[Symbol.asyncIterator]();
  expect(await iterator.next()).toMatchObject({ value: { type: 'text_delta', text: 'part' } });
  controller.abort();
  const outcome = await Promise.race([
    iterator.next().then(
      () => 'resolved',
      () => 'rejected',
    ),
    new Promise((resolve) => setTimeout(() => resolve('timed out'), 3000)),
  ]);
  expect(outcome).toBe('rejected');
});
