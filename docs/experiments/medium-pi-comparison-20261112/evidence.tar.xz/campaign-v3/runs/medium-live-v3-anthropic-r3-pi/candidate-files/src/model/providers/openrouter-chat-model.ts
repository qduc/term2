/**
 * Built-in OpenRouter lane: the owned chat-completions adapter behind OpenRouter's
 * wire dialect. Loaded lazily with the first OpenRouter model (see openrouter.provider.ts).
 *
 * Owns only what differs from a generic chat-completions endpoint:
 * - request translation: selected effort becomes `reasoning: { effort }`, provider
 *   options are flattened from their three spellings, and `tool_choice` is sent only
 *   with tools;
 * - the upstream provider OpenRouter reports per chunk, attached to completion metadata;
 * - error detail from `error.metadata` (provider name and raw upstream text).
 *
 * Retries stay with RetryingModel (the SDK's own retries are disabled), and cancellation
 * flows through the request signal to the adapter's transport options.
 */
import OpenAI, { APIError } from 'openai';
import { OpenAIChatCompletionsModel, normalizeChatCompletionError } from './openai-chat-completions-model.js';
import { OpenAICompatibleError } from './common/provider-errors.js';
import { isAbortLikeError } from '../error-helpers.js';
import type { StreamedModelTurn, StreamedModelTurnEvent, StreamedModelTurnRequest } from '../streamed-model-turn.js';

const PROVIDER_ID = 'openrouter';
const MAX_UPSTREAM_DETAIL_LENGTH = 500;

/** Keys that name the option namespace rather than a wire field. */
const OPTION_WRAPPER_KEYS = new Set(['openrouter', 'providerOptions', 'reasoning']);

export type OpenRouterChatModelOptions = {
  apiKey: string;
  baseURL: string;
  /** Attribution headers OpenRouter reads for app ranking and display. */
  headers: Record<string, string>;
  fetch: typeof fetch;
  model: string;
};

/** Builds the OpenRouter turn model over an OpenAI-compatible client. */
export function createOpenRouterChatModel(options: OpenRouterChatModelOptions): StreamedModelTurn {
  const client = new OpenAI({
    apiKey: options.apiKey,
    baseURL: options.baseURL,
    defaultHeaders: options.headers,
    fetch: options.fetch,
    // RetryingModel owns provider retries; the SDK's own retries would stack under it.
    maxRetries: 0,
  });
  return new OpenRouterChatModel(client, options.model);
}

class OpenRouterChatModel implements StreamedModelTurn {
  readonly #client: OpenAI;
  readonly #model: string;

  constructor(client: OpenAI, model: string) {
    this.#client = client;
    this.#model = model;
  }

  async *stream(request: StreamedModelTurnRequest): AsyncIterable<StreamedModelTurnEvent> {
    // The upstream provider arrives on stream chunks, not in the adapter's output.
    // A per-call observer keeps that capture scoped to this one request.
    const observed: { provider?: string } = {};
    const adapter = new OpenAIChatCompletionsModel(
      observeUpstreamProvider(this.#client, observed),
      this.#model,
      undefined,
      PROVIDER_ID,
    );
    try {
      for await (const event of adapter.stream(toOpenRouterRequest(request))) {
        yield event.type === 'completion' && observed.provider
          ? {
              ...event,
              providerMetadata: { ...event.providerMetadata, openrouter: { provider: observed.provider } },
            }
          : event;
      }
    } catch (error) {
      throw openRouterStreamFailure(error);
    }
  }
}

/** Translates the application request into the body fields OpenRouter reads. */
function toOpenRouterRequest(request: StreamedModelTurnRequest): StreamedModelTurnRequest {
  const { reasoning, toolChoice, ...rest } = request;
  return {
    ...rest,
    // The adapter would send `reasoning_effort`; OpenRouter reads `reasoning`.
    providerOptions: flattenOpenRouterOptions(request.providerOptions, reasoning?.effort),
    // A tool choice without tools is rejected upstream, so it is dropped with them.
    ...(request.tools.length > 0 && toolChoice !== undefined ? { toolChoice } : {}),
  };
}

/**
 * Flattens top-level, `openrouter`, and `providerOptions.openrouter` options into
 * one body. Later namespaces win; a top-level `reasoning` wins over every namespaced
 * one. Without explicit reasoning, a selected effort other than `default` applies.
 */
function flattenOpenRouterOptions(
  options: StreamedModelTurnRequest['providerOptions'],
  effort: string | null | undefined,
): Record<string, unknown> {
  const source: Record<string, unknown> = isRecord(options) ? options : {};
  const nested = isRecord(source.providerOptions) ? source.providerOptions : {};
  const topLevel = Object.fromEntries(Object.entries(source).filter(([key]) => !OPTION_WRAPPER_KEYS.has(key)));
  const flattened: Record<string, unknown> = {
    ...topLevel,
    ...(isRecord(source.openrouter) ? source.openrouter : {}),
    ...(isRecord(nested.openrouter) ? nested.openrouter : {}),
  };
  if (source.reasoning != null) flattened.reasoning = source.reasoning;
  else if (flattened.reasoning == null && effort && effort !== 'default') flattened.reasoning = { effort };
  return flattened;
}

type UpstreamChunk = { provider?: unknown } & Record<string, unknown>;
type CompletionsEndpoint = {
  create(body: Record<string, unknown>, options: { signal?: AbortSignal }): Promise<AsyncIterable<UpstreamChunk>>;
};

/** A client whose streamed chunks record the upstream provider as they pass through. */
function observeUpstreamProvider(client: OpenAI, observed: { provider?: string }): unknown {
  const endpoint = client.chat.completions as unknown as CompletionsEndpoint;
  return {
    chat: {
      completions: {
        create: async (body: Record<string, unknown>, options: { signal?: AbortSignal }) =>
          recordUpstreamProvider(await endpoint.create(body, options), observed),
      },
    },
  };
}

async function* recordUpstreamProvider(
  chunks: AsyncIterable<UpstreamChunk>,
  observed: { provider?: string },
): AsyncIterable<UpstreamChunk> {
  for await (const chunk of chunks) {
    if (typeof chunk?.provider === 'string' && chunk.provider.trim()) observed.provider = chunk.provider.trim();
    yield chunk;
  }
}

/**
 * Keeps the failure's retry class and appends OpenRouter's upstream detail to its message.
 * An in-band error frame reaches here as an SDK APIError with no status, because the SDK
 * rejects `error` frames before the adapter reads them; it is normalized the way the
 * adapter normalizes its own in-band errors, so 5xx-coded frames stay retryable.
 */
function openRouterStreamFailure(error: unknown): unknown {
  if (isAbortLikeError(error)) return error;
  if (error instanceof APIError) {
    if (error.error == null) return error;
    if (error.status !== undefined) {
      appendUpstreamDetail(error, error.error);
      return error;
    }
    const normalized = normalizeChatCompletionError(error.error);
    appendUpstreamDetail(normalized, error.error);
    return normalized;
  }
  if (error instanceof OpenAICompatibleError) {
    appendUpstreamDetail(error, parseBody(error.responseBody));
  }
  return error;
}

function appendUpstreamDetail(error: Error, payload: unknown): void {
  const detail = upstreamDetail(payload);
  if (detail) error.message = `${error.message} (${detail})`;
}

/** `[provider] raw` from `error.metadata`; a null or empty raw is skipped. */
function upstreamDetail(payload: unknown): string | undefined {
  const metadata = isRecord(payload) && isRecord(payload.metadata) ? payload.metadata : undefined;
  if (!metadata) return undefined;
  const provider = typeof metadata.provider_name === 'string' ? metadata.provider_name.trim() : '';
  const text = [provider ? `[${provider}]` : undefined, rawDetail(metadata.raw)].filter(Boolean).join(' ');
  if (!text) return undefined;
  return text.length > MAX_UPSTREAM_DETAIL_LENGTH ? `${text.slice(0, MAX_UPSTREAM_DETAIL_LENGTH)}…` : text;
}

/** Raw upstream text: a JSON string or object contributes its message; otherwise the text itself. */
function rawDetail(raw: unknown): string | undefined {
  if (raw === null || raw === undefined) return undefined;
  const parsed = typeof raw === 'string' ? parseBody(raw) : raw;
  const message = messageOf(parsed ?? raw, 0);
  if (message) return message;
  const text = typeof raw === 'string' ? raw.trim() : JSON.stringify(raw);
  return text || undefined;
}

function messageOf(value: unknown, depth: number): string | undefined {
  if (typeof value === 'string') return value.trim() || undefined;
  if (!isRecord(value) || depth > 3) return undefined;
  for (const key of ['message', 'error', 'detail', 'details', 'msg']) {
    const found = messageOf(value[key], depth + 1);
    if (found) return found;
  }
  return undefined;
}

function parseBody(body: string | undefined): unknown {
  if (!body) return undefined;
  try {
    return JSON.parse(body);
  } catch {
    return undefined;
  }
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);
