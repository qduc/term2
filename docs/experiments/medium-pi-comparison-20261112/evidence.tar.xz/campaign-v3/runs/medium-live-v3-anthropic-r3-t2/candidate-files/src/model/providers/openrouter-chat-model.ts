import { APIError } from 'openai';
import { OpenAICompatibleError, OpenRouterError } from './common/provider-errors.js';
import type { OpenAIChatCompletionsModel } from './openai-chat-completions-model.js';
import type {
  StreamedModelProviderOptions,
  StreamedModelTurn,
  StreamedModelTurnEvent,
  StreamedModelTurnRequest,
} from '../streamed-model-turn.js';

/**
 * OpenRouter over the application-owned chat-completions adapter.
 *
 * Owns only what OpenRouter's wire needs beyond plain chat completions: reasoning
 * is sent as `reasoning: { effort }` instead of `reasoning_effort`, provider
 * options are flattened from their three spellings, `tool_choice` is sent only
 * with tools, and upstream error detail is folded into the message.
 */
export class OpenRouterChatModel implements StreamedModelTurn {
  readonly #adapter: OpenAIChatCompletionsModel;

  constructor(adapter: OpenAIChatCompletionsModel) {
    this.#adapter = adapter;
  }

  async *stream(request: StreamedModelTurnRequest): AsyncIterable<StreamedModelTurnEvent> {
    try {
      yield* this.#adapter.stream(toOpenRouterRequest(request));
    } catch (error) {
      throw toOpenRouterError(error);
    }
  }
}

/** Rewrites a neutral turn request into the OpenRouter-shaped request the chat adapter serializes. */
function toOpenRouterRequest(request: StreamedModelTurnRequest): StreamedModelTurnRequest {
  const { reasoning: selected, toolChoice, providerOptions, ...rest } = request;
  const flat = flattenOpenRouterOptions(providerOptions);
  const effort = selected?.effort;
  // Explicit reasoning (any spelling) overrides the selected effort; `default` means no override.
  const reasoning = flat.reasoning != null ? flat.reasoning : effort && effort !== 'default' ? { effort } : undefined;
  return {
    ...rest,
    ...(request.tools.length && toolChoice !== undefined ? { toolChoice } : {}),
    providerOptions: { ...flat, ...(reasoning !== undefined ? { reasoning } : {}) },
  };
}

/**
 * Flattens `providerOptions` written top-level, under `openrouter`, or under
 * `providerOptions.openrouter`. Later namespaced values win; a top-level
 * `reasoning` wins over every namespaced one. The wrapper keys are dropped so
 * they never reach the wire.
 */
function flattenOpenRouterOptions(options: StreamedModelProviderOptions | undefined): Record<string, unknown> {
  if (!isRecord(options)) return {};
  const { openrouter: direct, providerOptions: wrapper, reasoning: topLevelReasoning, ...extra } = options;
  const nested = isRecord(wrapper) && isRecord(wrapper.openrouter) ? wrapper.openrouter : {};
  const flat: Record<string, unknown> = { ...extra, ...(isRecord(direct) ? direct : {}), ...nested };
  if (topLevelReasoning !== undefined) flat.reasoning = topLevelReasoning;
  return flat;
}

/** Converts a thrown transport or in-band failure into an OpenRouterError with upstream detail. */
function toOpenRouterError(error: unknown): unknown {
  if (error instanceof OpenRouterError) return error;
  if (error instanceof OpenAICompatibleError) {
    return new OpenRouterError(
      describeOpenRouterError(parseJson(error.responseBody), error.message),
      error.status,
      error.headers,
      error.responseBody,
    );
  }
  if (error instanceof APIError) {
    // The SDK's stream layer raises an in-band `data.error` chunk as an APIError
    // with no HTTP status; its body is the error object itself.
    const status = typeof error.status === 'number' ? error.status : inBandStatus(error.error);
    if (status === undefined) return error;
    return new OpenRouterError(
      describeOpenRouterError(error.error, error.message),
      status,
      headersToRecord(error.headers),
      safeStringify(error.error),
    );
  }
  return error;
}

/** Upstream in-band errors carry their status in `code`; anything unrecognised is a 502, as the chat adapter treats it. */
function inBandStatus(body: unknown): number {
  const record = isRecord(body) ? body : undefined;
  const code = record?.code ?? record?.status;
  const numeric = typeof code === 'number' ? code : typeof code === 'string' && /^\d+$/.test(code) ? Number(code) : NaN;
  return Number.isInteger(numeric) && numeric >= 400 && numeric <= 599 ? numeric : 502;
}

/**
 * `[provider] upstream detail`, as OpenRouter's own error text reads. The raw
 * upstream detail (string or JSON object) is used only when it adds to the
 * message; a null raw value contributes nothing.
 */
function describeOpenRouterError(body: unknown, fallback: string): string {
  const record = isRecord(body) ? body : undefined;
  const error = isRecord(record?.error) ? record.error : record;
  const message = nonEmptyString(error?.message) ?? fallback;
  const metadata = isRecord(error?.metadata) ? error.metadata : undefined;
  if (!metadata) return message;
  const provider = nonEmptyString(metadata.provider_name);
  const raw = rawDetail(metadata.raw);
  const detail = raw && raw !== message ? raw : message;
  return provider ? `[${provider}] ${detail}` : detail;
}

function rawDetail(raw: unknown): string | undefined {
  if (typeof raw === 'string') {
    const parsed = parseJson(raw);
    if (isRecord(parsed)) return extractMessageField(parsed) ?? nonEmptyString(raw);
    return nonEmptyString(raw);
  }
  if (isRecord(raw)) return extractMessageField(raw) ?? truncate(safeStringify(raw));
  return undefined;
}

function extractMessageField(value: Record<string, unknown>, depth = 0): string | undefined {
  if (depth > 3) return undefined;
  for (const field of ['message', 'error', 'detail', 'details', 'msg']) {
    const found = value[field];
    const text = nonEmptyString(found);
    if (text) return text;
    if (isRecord(found)) {
      const nested = extractMessageField(found, depth + 1);
      if (nested) return nested;
    }
  }
  return undefined;
}

function headersToRecord(headers: unknown): Record<string, string> {
  if (headers && typeof (headers as Headers).forEach === 'function') {
    const record: Record<string, string> = {};
    (headers as Headers).forEach((value, key) => {
      record[key] = value;
    });
    return record;
  }
  return isRecord(headers) ? (headers as Record<string, string>) : {};
}

const MAX_RAW_DETAIL = 500;
const truncate = (text: string | undefined): string | undefined =>
  text === undefined ? undefined : text.length > MAX_RAW_DETAIL ? `${text.slice(0, MAX_RAW_DETAIL)}…` : text;

const nonEmptyString = (value: unknown): string | undefined =>
  typeof value === 'string' && value.trim().length > 0 ? value.trim() : undefined;

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

function parseJson(text: string | undefined | null): unknown {
  if (typeof text !== 'string') return text ?? undefined;
  try {
    return JSON.parse(text);
  } catch {
    return undefined;
  }
}

function safeStringify(value: unknown): string | undefined {
  try {
    return JSON.stringify(value);
  } catch {
    return undefined;
  }
}
