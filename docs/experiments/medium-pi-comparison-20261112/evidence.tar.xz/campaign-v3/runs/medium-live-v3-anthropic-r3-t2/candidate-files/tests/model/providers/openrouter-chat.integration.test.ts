import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { afterEach, describe, expect, it } from 'vitest';
import '../../../src/model/providers/index.js';
import { getProvider } from '../../../src/model/providers/registry.js';
import { OpenAIChatCompletionsModel } from '../../../src/model/providers/openai-chat-completions-model.js';
import { createProviderFetch } from '../../../src/model/providers/fetch/composer.js';
import { isTransientRetryableError } from '../../../src/model/failure/retry-error-classification.js';
import { OpenRouterError } from '../../../src/model/providers/common/provider-errors.js';
import type { ILoggingService, ISettingsService, IProviderTraffic } from '../../../src/shared/service-interfaces.js';
import type { StreamedModelTurnRequest } from '../../../src/model/streamed-model-turn.js';
import OpenAI from 'openai';

// Loopback OpenRouter-style gateway. Each request consumes the next scripted reply;
// the last reply repeats. Replies are raw SSE/JSON bodies or a held-open stream.
type Reply = {
  status?: number;
  headers?: Record<string, string>;
  frames?: unknown[];
  rawBody?: string;
  holdOpenAfterFrames?: boolean;
};
type Captured = { url: string; headers: IncomingMessage['headers']; body: any };

let close: (() => Promise<void>) | undefined;
afterEach(async () => {
  await close?.();
  close = undefined;
});

async function startGateway(replies: Reply[]) {
  const requests: Captured[] = [];
  const sockets = new Set<import('node:net').Socket>();
  const server = createServer((req: IncomingMessage, res: ServerResponse) => {
    const chunks: Buffer[] = [];
    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => {
      const text = Buffer.concat(chunks).toString('utf8');
      requests.push({ url: req.url ?? '', headers: req.headers, body: text ? JSON.parse(text) : undefined });
      const reply = replies[Math.min(requests.length - 1, replies.length - 1)]!;
      res.writeHead(reply.status ?? 200, reply.headers ?? { 'content-type': 'text/event-stream' });
      if (reply.rawBody !== undefined) {
        res.end(reply.rawBody);
        return;
      }
      for (const frame of reply.frames ?? []) res.write(`data: ${JSON.stringify(frame)}\n\n`);
      // holdOpenAfterFrames never ends: the consumer must not wait on it.
      if (reply.holdOpenAfterFrames) return;
      res.end('data: [DONE]\n\n');
    });
  });
  server.on('connection', (socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  const baseUrl = `http://127.0.0.1:${(server.address() as import('node:net').AddressInfo).port}`;
  close = async () => {
    for (const socket of sockets) socket.destroy();
    await new Promise<void>((resolve) => server.close(() => resolve()));
  };
  return { baseUrl, requests };
}

const quietLogging: ILoggingService = {
  info() {},
  warn() {},
  error() {},
  debug() {},
  security() {},
  setCorrelationId() {},
  getCorrelationId: () => undefined,
  clearCorrelationId() {},
} as unknown as ILoggingService;

function settingsFor(baseUrl: string, model: string, extra: Record<string, unknown> = {}): ISettingsService {
  const values: Record<string, unknown> = {
    'agent.modelSelection': { model, provider: 'openrouter' },
    'agent.retryAttempts': 0,
    'agent.openrouter.apiKey': 'fixture-key',
    'agent.openrouter.baseUrl': `${baseUrl}/api/v1`,
    'agent.openrouter.referrer': 'https://fixture.test',
    'agent.openrouter.title': 'term2-test',
    ...extra,
  };
  return {
    get: (key: string) => values[key] as never,
    getDynamic: () => [],
    set() {},
    setDynamic() {},
    setPersistent() {},
    setPersistentDynamic() {},
  } as unknown as ISettingsService;
}

async function openRouterModel(baseUrl: string, model: string, traffic?: IProviderTraffic) {
  const logging = traffic
    ? ({ ...quietLogging, providerTraffic: traffic } as unknown as ILoggingService)
    : quietLogging;
  return getProvider('openrouter')!.createStreamedModel!(model, {
    settingsService: settingsFor(baseUrl, model),
    loggingService: logging,
    retryAttempts: 0,
  });
}

const user = (text: string) => ({
  type: 'message' as const,
  role: 'user' as const,
  content: [{ type: 'text' as const, text }],
});
const tool = { name: 'fixture', description: 'Fixture tool.', parameters: { type: 'object', properties: {} } };
const baseRequest = (overrides: Partial<StreamedModelTurnRequest> = {}): StreamedModelTurnRequest =>
  ({ input: [user('hi')], tools: [], ...overrides } as StreamedModelTurnRequest);

const chunk = (delta: Record<string, unknown>, extra: Record<string, unknown> = {}) => ({
  id: 'gen-1',
  object: 'chat.completion.chunk',
  provider: 'CoreWeave',
  choices: [{ index: 0, delta, finish_reason: null }],
  ...extra,
});
const finish = (extra: Record<string, unknown> = {}) => ({
  id: 'gen-1',
  provider: 'CoreWeave',
  choices: [{ index: 0, delta: {}, finish_reason: 'stop' }],
  usage: { prompt_tokens: 10, completion_tokens: 4, total_tokens: 14, cost: 0.00012 },
  ...extra,
});

async function collect<T>(stream: AsyncIterable<T>): Promise<T[]> {
  const events: T[] = [];
  for await (const event of stream) events.push(event);
  return events;
}

describe('OpenRouter over the owned chat-completions adapter', () => {
  it('sends selected effort as reasoning:{effort} and never as reasoning_effort', async () => {
    const gateway = await startGateway([{ frames: [chunk({ content: 'ok' }), finish()] }]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    await collect(model.stream(baseRequest({ reasoning: { effort: 'high' } })));
    const body = gateway.requests[0]!.body;
    expect(body.reasoning).toEqual({ effort: 'high' });
    expect(body).not.toHaveProperty('reasoning_effort');
  });

  it('sends no reasoning object for the default effort', async () => {
    const gateway = await startGateway([{ frames: [chunk({ content: 'ok' }), finish()] }]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    await collect(model.stream(baseRequest({ reasoning: { effort: 'default' } })));
    expect(gateway.requests[0]!.body).not.toHaveProperty('reasoning');
  });

  it('lets explicit reasoning override the selected effort and strips every option wrapper from the wire', async () => {
    const gateway = await startGateway([{ frames: [chunk({ content: 'ok' }), finish()] }]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    await collect(
      model.stream(
        baseRequest({
          reasoning: { effort: 'high' },
          providerOptions: {
            openrouter: { reasoning: { effort: 'low' }, transforms: ['middle-out'] },
            providerOptions: { openrouter: { user: 'fixture-user' } },
          },
        }),
      ),
    );
    const body = gateway.requests[0]!.body;
    expect(body.reasoning).toEqual({ effort: 'low' });
    expect(body.transforms).toEqual(['middle-out']);
    expect(body.user).toBe('fixture-user');
    expect(body).not.toHaveProperty('openrouter');
    expect(body).not.toHaveProperty('providerOptions');
  });

  it('lets top-level reasoning win and later namespaced values win the rest', async () => {
    const gateway = await startGateway([{ frames: [chunk({ content: 'ok' }), finish()] }]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    await collect(
      model.stream(
        baseRequest({
          providerOptions: {
            reasoning: { effort: 'minimal' },
            openrouter: { reasoning: { effort: 'low' }, top_k: 1 },
            providerOptions: { openrouter: { top_k: 5 } },
          },
        }),
      ),
    );
    const body = gateway.requests[0]!.body;
    expect(body.reasoning).toEqual({ effort: 'minimal' });
    expect(body.top_k).toBe(5);
  });

  it('sends tool_choice only when tools exist', async () => {
    const gateway = await startGateway([{ frames: [chunk({ content: 'ok' }), finish()] }]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    await collect(model.stream(baseRequest({ toolChoice: 'none' })));
    expect(gateway.requests[0]!.body).not.toHaveProperty('tool_choice');
    await collect(model.stream(baseRequest({ toolChoice: 'none', tools: [tool] })));
    expect(gateway.requests[1]!.body).toMatchObject({
      tool_choice: 'none',
      tools: [{ function: { name: 'fixture' } }],
    });
  });

  it('preserves the key, base URL, and referrer/title headers', async () => {
    const gateway = await startGateway([{ frames: [chunk({ content: 'ok' }), finish()] }]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    await collect(model.stream(baseRequest()));
    const request = gateway.requests[0]!;
    expect(request.url).toBe('/api/v1/chat/completions');
    expect(request.headers.authorization).toBe('Bearer fixture-key');
    expect(request.headers['http-referer']).toBe('https://fixture.test');
    expect(request.headers['x-title']).toBe('term2-test');
    expect(request.headers['x-openrouter-title']).toBe('term2-test');
  });

  it('streams text, reasoning, reasoning_details, usage cost, and reports the upstream provider on completion', async () => {
    const gateway = await startGateway([
      {
        frames: [
          chunk({
            role: 'assistant',
            reasoning: 'Thinking.',
            reasoning_details: [{ type: 'reasoning.text', text: 'Thinking.', format: 'unknown', index: 0 }],
          }),
          chunk({ content: 'Hel' }),
          chunk({ content: 'lo' }),
          finish(),
        ],
      },
    ]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    const events = await collect(model.stream(baseRequest()));
    const completion = events.at(-1) as any;
    expect(completion).toMatchObject({
      type: 'completion',
      costUsd: 0.00012,
      usage: { inputTokens: 10, outputTokens: 4 },
      providerMetadata: { openrouter: { provider: 'CoreWeave' } },
    });
    expect(
      events
        .filter((e: any) => e.type === 'text_delta')
        .map((e: any) => e.text)
        .join(''),
    ).toBe('Hello');
    expect(events.some((e: any) => e.type === 'reasoning_delta' && e.text === 'Thinking.')).toBe(true);
    const opaque = completion.output.find((item: any) => item.type === 'provider_opaque');
    expect(opaque.item.reasoning_details).toEqual([
      { type: 'reasoning.text', text: 'Thinking.', format: 'unknown', index: 0 },
    ]);
  });

  it('does not report an upstream provider for other chat-completions adapters', async () => {
    const gateway = await startGateway([{ frames: [chunk({ content: 'ok' }), finish()] }]);
    const client = new OpenAI({ apiKey: 'k', baseURL: `${gateway.baseUrl}/v1`, maxRetries: 0 });
    const model = new OpenAIChatCompletionsModel(client, 'gateway-model', undefined, 'openai-compatible');
    const events = await collect(model.stream(baseRequest()));
    expect(events.at(-1)).not.toHaveProperty('providerMetadata');
  });

  it('replays reasoning_details and the reasoning text on a tool continuation', async () => {
    const reasoningDetails = [{ type: 'reasoning.text', text: 'Plan.', format: 'unknown', index: 0 }];
    const gateway = await startGateway([
      {
        frames: [
          chunk({ role: 'assistant', reasoning: 'Plan.', reasoning_details: reasoningDetails }),
          chunk({
            tool_calls: [{ index: 0, id: 'call_1', type: 'function', function: { name: 'fixture', arguments: '{}' } }],
          }),
          finish({ choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }] }),
        ],
      },
      { frames: [chunk({ content: 'done' }), finish()] },
    ]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    const first = await collect(model.stream(baseRequest({ tools: [tool] })));
    const output = (first.at(-1) as any).output as any[];
    const call = output.find((item) => item.type === 'tool_call');
    const reasoning = output.find((item) => item.type === 'reasoning');
    const opaque = output.find((item) => item.type === 'provider_opaque');
    expect(call).toBeDefined();
    await collect(
      model.stream(
        baseRequest({
          tools: [tool],
          input: [
            user('hi'),
            { type: 'reasoning', text: reasoning.text },
            opaque,
            { type: 'tool_call', id: call.id, name: call.name, arguments: call.arguments },
            { type: 'tool_result', id: call.id, output: 'ok' },
            user('continue'),
          ],
        }),
      ),
    );
    const assistant = gateway.requests[1]!.body.messages.find((m: any) => m.role === 'assistant');
    expect(assistant).toMatchObject({ reasoning: 'Plan.', reasoning_details: reasoningDetails, content: null });
    expect(assistant.tool_calls).toHaveLength(1);
  });

  it('filters unsigned Anthropic and Gemini reasoning_details and annotates Claude cache breakpoints', async () => {
    const gateway = await startGateway([{ frames: [chunk({ content: 'ok' }), finish()] }]);
    const model = await openRouterModel(gateway.baseUrl, 'anthropic/claude-sonnet');
    await collect(
      model.stream(
        baseRequest({
          input: [
            user('first'),
            {
              type: 'provider_opaque',
              provider: 'openrouter',
              item: {
                reasoning_details: [
                  { type: 'reasoning.text', text: 'unsigned', format: 'anthropic-claude-v1' },
                  { type: 'reasoning.text', text: 'signed', format: 'anthropic-claude-v1', signature: 'sig' },
                ],
              },
            },
            { type: 'message', role: 'assistant', content: [{ type: 'text', text: 'ack' }] },
            user('second'),
          ],
        }),
      ),
    );
    const messages = gateway.requests[0]!.body.messages;
    const details = messages.flatMap((m: any) => m.reasoning_details ?? []);
    expect(details.map((d: any) => d.text)).toEqual(['signed']);
    const lastUser = [...messages].reverse().find((m: any) => m.role === 'user');
    expect(JSON.stringify(lastUser)).toContain('cache_control');
  });

  it('keeps retry ownership in the caller: one HTTP attempt per request and classified upstream errors', async () => {
    const gateway = await startGateway([
      {
        status: 429,
        headers: { 'content-type': 'application/json', 'retry-after': '1' },
        rawBody: JSON.stringify({ error: { message: 'slow down' } }),
      },
    ]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    const failure = await collect(model.stream(baseRequest())).catch((error) => error);
    expect(gateway.requests).toHaveLength(1);
    expect(failure).toBeInstanceOf(OpenRouterError);
    expect(failure).toMatchObject({ status: 429, message: 'slow down' });
    expect(isTransientRetryableError(failure)).toBe(true);
  });

  it('classifies a non-retryable HTTP 400 as non-transient and keeps provider detail', async () => {
    const gateway = await startGateway([
      {
        status: 400,
        headers: { 'content-type': 'application/json' },
        rawBody: JSON.stringify({
          error: {
            message: 'Provider returned error',
            code: 400,
            metadata: { provider_name: 'Venice', raw: { message: 'Context too long' } },
          },
        }),
      },
    ]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    const failure = await collect(model.stream(baseRequest())).catch((error) => error);
    expect(failure).toBeInstanceOf(OpenRouterError);
    expect(failure.message).toBe('[Venice] Context too long');
    expect(failure.status).toBe(400);
    expect(isTransientRetryableError(failure)).toBe(false);
  });

  it.each([
    {
      metadata: { provider_name: 'Venice', raw: '{"message":"Model is at capacity"}' },
      expected: '[Venice] Model is at capacity',
    },
    { metadata: { provider_name: 'Venice', raw: null }, expected: '[Venice] Provider returned error' },
    { metadata: { provider_name: 'Venice', raw: { detail: 'quota exhausted' } }, expected: '[Venice] quota exhausted' },
    { metadata: { raw: 'plain upstream text' }, expected: 'plain upstream text' },
  ])('folds in-band upstream detail into the message ($expected)', async ({ metadata, expected }) => {
    const gateway = await startGateway([
      {
        frames: [chunk({ content: ' ' }), { error: { message: 'Provider returned error', code: 502, metadata } }],
      },
    ]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    const failure = await collect(model.stream(baseRequest())).catch((error) => error);
    expect(failure).toBeInstanceOf(OpenRouterError);
    expect(failure.status).toBe(502);
    expect(failure.message).toBe(expected);
    expect(isTransientRetryableError(failure)).toBe(true);
  });

  it('settles an in-band error on a held-open stream when no traffic recorder is configured', async () => {
    const gateway = await startGateway([
      { frames: [chunk({ content: ' ' }), { error: { message: 'boom', code: 502 } }], holdOpenAfterFrames: true },
    ]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b');
    // sleep-ok: observes that the held-open stream does NOT settle within 5 s; a held-open socket has no
    // readiness signal, and the race returns as soon as the error settles, so the window is only paid on failure.
    const outcome = await Promise.race([
      collect(model.stream(baseRequest())).then(
        () => 'completed',
        (error) => `threw:${(error as Error).message}`,
      ),
      new Promise((resolve) => setTimeout(() => resolve('timed-out'), 5_000)),
    ]);
    expect(outcome).toBe('threw:boom');
  });

  it('retains the closed error frame for an active traffic recorder', async () => {
    let settleRecorded: { resolve(text: string): void; reject(error: unknown): void } | undefined;
    const recordedText = new Promise<string>((resolve, reject) => {
      settleRecorded = { resolve, reject };
    });
    const traffic: IProviderTraffic = {
      recordRequestStart() {},
      async recordResponseReceived(input: any) {
        try {
          settleRecorded!.resolve(await input.response.text());
        } catch (error) {
          settleRecorded!.reject(error);
        }
      },
      recordResponseClosed() {},
      recordRequestFailed() {},
    } as unknown as IProviderTraffic;
    const gateway = await startGateway([
      { frames: [chunk({ content: ' ' }), { error: { message: 'boom', code: 502 } }] },
    ]);
    const model = await openRouterModel(gateway.baseUrl, 'openai/gpt-oss-20b', traffic);
    await collect(model.stream(baseRequest())).catch(() => undefined);
    expect(await recordedText).toContain('"message":"boom"');
  });
});

// Keep the fetch composer under test explicit: an unrecorded composer must not clone bodies.
describe('fetch composer without a traffic recorder', () => {
  it('passes the response through without cloning it', async () => {
    const gateway = await startGateway([{ frames: [chunk({ content: 'ok' }), finish()] }]);
    const fetchFn = createProviderFetch({
      providerId: 'probe',
      defaultModel: 'm',
      deps: { loggingService: { providerTraffic: undefined } as unknown as ILoggingService },
    });
    const response = await fetchFn(`${gateway.baseUrl}/v1/x`, { method: 'POST', body: '{}' });
    expect(response.bodyUsed).toBe(false);
    await response.body?.cancel();
  });
});
