/**
 * OpenRouter's built-in provider. Requests go through the application-owned
 * chat-completions adapter (`OpenAIChatCompletionsModel`) with OpenRouter's
 * wire rules: a `reasoning` object instead of `reasoning_effort`, provider
 * options flattened into the body, the upstream provider reported in completion
 * metadata, and upstream error detail. Retries stay with RetryingModel.
 */
import OpenAI from 'openai';
import { RetryingModel } from './retrying-model.js';
import { registerProvider } from './registry.js';
import type { ProviderDeps, ProviderFetch } from './registry.js';
import { createProviderFetch } from './fetch/composer.js';
import type { FetchMiddleware } from './fetch/compose.js';
import { addCacheControlToLastTwoMessages } from './anthropic-chat-caching.js';
import { createOpenAICompatibleMiddleware } from './openai-compatible-middleware.js';
import {
  OpenAIChatCompletionsModel,
  toChatToolChoice,
  type ChatCompletionsDialect,
} from './openai-chat-completions-model.js';
import { normalizeBaseUrl } from './common/openai-compatible-utils.js';
import { NULL_SESSION_CONTEXT_SERVICE } from '../traffic-context.js';
import type { StreamedModelTurn, StreamedModelTurnRequest } from '../streamed-model-turn.js';

const DEFAULT_BASE_URL = 'https://openrouter.ai/api/v1';
const DEFAULT_REFERRER = 'https://github.com/qduc/term2';
const DEFAULT_TITLE = 'term2';

function createOpenRouterStreamedModel(deps: ProviderDeps, model: string): StreamedModelTurn | null {
  const { settingsService, loggingService, sessionContextService } = deps;
  const apiKey = settingsService.get('agent.openrouter.apiKey') || process.env.OPENROUTER_API_KEY;
  if (!apiKey) return null;

  const referrer = settingsService.get('agent.openrouter.referrer') || DEFAULT_REFERRER;
  const title = settingsService.get('agent.openrouter.title') || DEFAULT_TITLE;
  const client = new OpenAI({
    apiKey,
    baseURL: normalizeBaseUrl(settingsService.get('agent.openrouter.baseUrl') || DEFAULT_BASE_URL),
    // RetryingModel owns retries. The SDK model this replaced never retried a stream itself.
    maxRetries: 0,
    // HTTP-Referer and X-Title are the configured referrer and title; X-OpenRouter-Title
    // is the spelling the previous SDK also sent.
    defaultHeaders: { 'HTTP-Referer': referrer, 'X-Title': title, 'X-OpenRouter-Title': title },
    fetch: createProviderFetch({
      providerId: 'openrouter',
      defaultModel: settingsService.get('agent.modelSelection').model || model,
      deps: {
        loggingService,
        sessionContextService: sessionContextService ?? NULL_SESSION_CONTEXT_SERVICE,
        onDispatched: deps.onDispatched,
      },
      middlewares: [
        createOpenAICompatibleMiddleware(),
        openRouterPreprocessingMiddleware,
        openRouterErrorDetailMiddleware,
      ],
    }),
  });
  return new OpenAIChatCompletionsModel(client, model, undefined, 'openrouter', openRouterChatDialect);
}

function sanitizeOpenRouterReasoningDetails(messages: any[]): void {
  const requiresSignature = new Set(['google-gemini-v1', 'anthropic-claude-v1']);
  for (const message of messages) {
    if (!Array.isArray(message?.reasoning_details)) {
      continue;
    }
    message.reasoning_details = message.reasoning_details.filter((detail: any) => {
      if (detail?.type !== 'reasoning.text') {
        return true;
      }
      if (!requiresSignature.has(detail?.format)) {
        return true;
      }
      return Boolean(detail?.signature);
    });
  }
}

export const openRouterPreprocessingMiddleware: FetchMiddleware = async (ctx, next) => {
  if (typeof ctx.init?.body === 'string') {
    try {
      const body = JSON.parse(ctx.init.body);
      if (Array.isArray(body?.messages)) {
        sanitizeOpenRouterReasoningDetails(body.messages);
        addCacheControlToLastTwoMessages(body.messages, body.model);
        ctx.init = { ...ctx.init, body: JSON.stringify(body) };
      }
    } catch {
      /* fall through */
    }
  }
  return next(ctx);
};

/**
 * Puts OpenRouter's upstream detail into a failed HTTP response's error message.
 * The OpenAI client builds its error text from that message, so the status,
 * headers and retry classification of the response are left as they were.
 */
const openRouterErrorDetailMiddleware: FetchMiddleware = async (ctx, next) => {
  const response = await next(ctx);
  if (response.ok) return response;
  const text = await response.text();
  const rebuild = (body: string) =>
    new Response(body, { status: response.status, statusText: response.statusText, headers: response.headers });
  let body: unknown;
  try {
    body = JSON.parse(text);
  } catch {
    return rebuild(text);
  }
  const error = isRecord(body) ? body.error : undefined;
  const detail = describeOpenRouterError(error);
  if (!detail || !isRecord(error)) return rebuild(text);
  return rebuild(JSON.stringify({ ...(body as Record<string, unknown>), error: { ...error, message: detail } }));
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

const asRecord = (value: unknown): Record<string, unknown> => (isRecord(value) ? value : {});

/**
 * Builds the message for an OpenRouter error object: `[provider] detail`, where
 * the detail is the upstream provider's own message when `metadata.raw` carries
 * one, else the error's message. A null or unrecognised `raw` falls back.
 */
function describeOpenRouterError(error: unknown): string | undefined {
  if (!isRecord(error) || !isRecord(error.metadata)) return undefined;
  const message = typeof error.message === 'string' ? error.message : undefined;
  const provider = error.metadata.provider_name;
  const providerTag = typeof provider === 'string' && provider ? `[${provider}]` : undefined;
  const raw = upstreamRawMessage(error.metadata.raw);
  const detail = raw && raw !== message ? raw : message;
  return [providerTag, detail].filter(Boolean).join(' ') || undefined;
}

function upstreamRawMessage(raw: unknown): string | undefined {
  if (typeof raw === 'string') {
    try {
      const parsed: unknown = JSON.parse(raw);
      return isRecord(parsed) ? upstreamRawMessage(parsed) : raw;
    } catch {
      return raw;
    }
  }
  if (!isRecord(raw)) return undefined;
  for (const field of ['message', 'error', 'detail', 'details', 'msg']) {
    const value = raw[field];
    if (typeof value === 'string' && value.length > 0) return value;
    if (isRecord(value)) {
      const nested = upstreamRawMessage(value);
      if (nested) return nested;
    }
  }
  return undefined;
}

/**
 * OpenRouter reasoning and provider options. Options may sit at the top level,
 * under `openrouter`, or under `providerOptions.openrouter`. The namespaced
 * spellings are flattened into the body with the later one winning; a top-level
 * `reasoning` wins over both, and explicit reasoning wins over the selected effort.
 * The wrapper keys themselves are never sent.
 */
function openRouterRequestFields(request: StreamedModelTurnRequest): Record<string, unknown> {
  const {
    providerOptions: wrapped,
    openrouter,
    reasoning: topLevelReasoning,
    ...topLevel
  } = asRecord(request.providerOptions);
  const namespaced = { ...asRecord(openrouter), ...asRecord(asRecord(wrapped).openrouter) };
  const effort = request.reasoning?.effort;
  const reasoning =
    topLevelReasoning ?? namespaced.reasoning ?? (effort && effort !== 'default' ? { effort } : undefined);
  const fields: Record<string, unknown> = {
    ...(request.toolChoice !== undefined ? { tool_choice: toChatToolChoice(request.toolChoice) } : {}),
    ...topLevel,
    ...namespaced,
    ...(reasoning !== undefined ? { reasoning } : {}),
  };
  // tool_choice without tools is rejected upstream, whichever spelling supplied it.
  if (!request.tools.length) delete fields.tool_choice;
  return fields;
}

const openRouterChatDialect: ChatCompletionsDialect = {
  requestFields: openRouterRequestFields,
  upstreamProvider: (chunk) => {
    const provider = asRecord(chunk).provider;
    return typeof provider === 'string' && provider.trim() ? provider.trim() : undefined;
  },
  errorDetail: describeOpenRouterError,
};

async function fetchOpenRouterModels(
  deps: ProviderDeps,
  fetchImpl: ProviderFetch = fetch,
): Promise<Array<{ id: string; name?: string }>> {
  const { settingsService } = deps;

  const baseUrl = settingsService.get('agent.openrouter.baseUrl') || 'https://openrouter.ai/api/v1';
  const apiKey = settingsService.get('agent.openrouter.apiKey') || process.env.OPENROUTER_API_KEY;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (apiKey) {
    headers.Authorization = `Bearer ${apiKey}`;
  }

  const response = await fetchImpl(`${baseUrl}/models`, { headers });
  if (!response.ok) {
    throw new Error(`OpenRouter models request failed (${response.status})`);
  }

  const body = await response.json();
  const twoYearsAgo = new Date();
  twoYearsAgo.setUTCFullYear(twoYearsAgo.getUTCFullYear() - 2);
  const minimumCreatedAt = twoYearsAgo.getTime() / 1000;
  const filteredData = (body?.data || []).filter(
    (item: any) =>
      Array.isArray(item?.supported_parameters) &&
      item.supported_parameters.includes('tools') &&
      typeof item.created === 'number' &&
      Number.isFinite(item.created) &&
      item.created >= minimumCreatedAt,
  );

  if (!Array.isArray(filteredData)) return [];

  return filteredData
    .map((item: any) => {
      const id = item?.id || item?.model || '';
      const name = item?.name || item?.display_name || item?.description;
      return id ? { id, name } : null;
    })
    .filter(Boolean) as Array<{ id: string; name?: string }>;
}

// Register OpenRouter provider
registerProvider(
  {
    id: 'openrouter',
    label: 'OpenRouter',
    createStreamedModel: async (model, deps): Promise<StreamedModelTurn> => {
      const streamedModel = createOpenRouterStreamedModel(deps, model);
      if (!streamedModel) throw new Error('OpenRouter API key is not configured');
      const retryAttempts = deps.retryAttempts ?? deps.settingsService.get('agent.retryAttempts') ?? 2;
      return new RetryingModel(streamedModel, {
        retryAttempts,
        loggingService: deps.loggingService,
        onRetry: deps.onRetry,
      });
    },
    fetchModels: fetchOpenRouterModels,
    sensitiveSettingKeys: [
      'agent.openrouter.apiKey',
      'agent.openrouter.baseUrl',
      'agent.openrouter.referrer',
      'agent.openrouter.title',
    ],
    capabilities: {
      supportsFlexServiceTier: true,
      supportsConversationChaining: false,
    },
  },
  { builtin: true },
);
