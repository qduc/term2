import { APIError } from 'openai';
import { OpenAICompatibleError } from './common/provider-errors.js';
import { OpenAIChatCompletionsModel } from './openai-chat-completions-model.js';
import type { StreamedModelTurnRequest } from '../streamed-model-turn.js';

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

/**
 * Builds OpenRouter's request fields from caller options and the selected effort.
 *
 * Options may sit at the top level, under `openrouter`, or under
 * `providerOptions.openrouter`. They are flattened in that order, so later
 * namespaced values win. The option wrapper keys are consumed here and never
 * reach the wire. Reasoning is OpenRouter's `reasoning` object: an explicit
 * `reasoning` option wins over the selected effort, and a top-level one wins
 * over namespaced ones. `default` effort sends no reasoning at all.
 */
function openRouterRequestFields(request: StreamedModelTurnRequest): Record<string, unknown> {
  const options = (request.providerOptions ?? {}) as Record<string, unknown>;
  const { openrouter: directNamespace, providerOptions: wrapper, reasoning: topLevelReasoning, ...topLevel } = options;
  const wrappedNamespace = isRecord(wrapper) && isRecord(wrapper.openrouter) ? wrapper.openrouter : {};
  const { reasoning: namespacedReasoning, ...namespaced } = {
    ...(isRecord(directNamespace) ? directNamespace : {}),
    ...wrappedNamespace,
  };
  const explicitReasoning = topLevelReasoning ?? namespacedReasoning;
  const effort = request.reasoning?.effort;
  const reasoning =
    explicitReasoning != null ? explicitReasoning : effort && effort !== 'default' ? { effort } : undefined;
  return { ...topLevel, ...namespaced, ...(reasoning !== undefined ? { reasoning } : {}) };
}

/**
 * Upstream detail from OpenRouter's `error.metadata`: the routed provider's name
 * and its raw error. A null `raw` is skipped. A string is used verbatim and any
 * other value is serialized as JSON.
 */
export function openRouterErrorDetail(error: unknown): string | undefined {
  const record = isRecord(error) ? error : undefined;
  const nested = record && isRecord(record.error) ? record.error : undefined;
  const metadata = isRecord(record?.metadata)
    ? record.metadata
    : isRecord(nested?.metadata)
    ? nested.metadata
    : undefined;
  if (!metadata) return undefined;
  const parts: string[] = [];
  const provider = typeof metadata.provider_name === 'string' ? metadata.provider_name.trim() : '';
  if (provider) parts.push(`provider: ${provider}`);
  const raw = metadata.raw;
  if (raw !== undefined && raw !== null) {
    const text = typeof raw === 'string' ? raw : typeof raw === 'object' ? JSON.stringify(raw) : String(raw);
    if (text.trim()) parts.push(`raw: ${text}`);
  }
  return parts.length > 0 ? `upstream ${parts.join('; ')}` : undefined;
}

/**
 * The owned chat-completions adapter, speaking OpenRouter's dialect: `reasoning`
 * objects, flattened provider options, upstream routing reported on each chunk,
 * and upstream error detail.
 */
export class OpenRouterChatCompletionsModel extends OpenAIChatCompletionsModel {
  constructor(client: any, model: string) {
    super(client, model, undefined, 'openrouter');
  }

  protected override optionFields(request: StreamedModelTurnRequest): Record<string, unknown> {
    return openRouterRequestFields(request);
  }

  /**
   * The OpenAI SDK throws an in-band `error` frame as an `APIError` with no
   * status, and its message drops the upstream metadata. Route that body back
   * through this dialect's error normalization so the detail and status survive.
   */
  protected override chunks(response: AsyncIterable<any>): AsyncIterable<any> {
    const normalize = (error: unknown) => this.normalizeError(error);
    return (async function* () {
      try {
        yield* response;
      } catch (error) {
        if (error instanceof APIError && error.status === undefined && error.error != null) {
          throw normalize(error.error);
        }
        throw error;
      }
    })();
  }

  /** OpenRouter rejects `tool_choice` on a request that declares no tools. */
  protected override toolChoiceFields(request: StreamedModelTurnRequest): Record<string, unknown> {
    return request.tools.length > 0 ? super.toolChoiceFields(request) : {};
  }

  /** The routed upstream provider rides on every chunk; it is completion metadata for OpenRouter only. */
  protected override observedCompletionMetadata(chunk: any): Record<string, unknown> | undefined {
    const provider = typeof chunk?.provider === 'string' ? chunk.provider.trim() : '';
    return provider ? { openrouter: { provider } } : undefined;
  }

  protected override normalizeError(error: unknown): OpenAICompatibleError {
    const normalized = super.normalizeError(error);
    const detail = openRouterErrorDetail(error);
    if (!detail) return normalized;
    return new OpenAICompatibleError(
      `${normalized.message} (${detail})`,
      normalized.status,
      normalized.headers,
      normalized.responseBody,
    );
  }
}
