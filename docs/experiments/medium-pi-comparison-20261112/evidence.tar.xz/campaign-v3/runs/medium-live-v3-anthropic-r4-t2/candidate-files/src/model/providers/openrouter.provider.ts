import OpenAI from 'openai';
import { RetryingModel } from './retrying-model.js';
import { registerProvider } from './registry.js';
import type { ProviderDeps, ProviderFetch } from './registry.js';
import { createProviderFetch } from './fetch/composer.js';
import type { FetchMiddleware } from './fetch/compose.js';
import { addCacheControlToLastTwoMessages } from './anthropic-chat-caching.js';
import { NULL_SESSION_CONTEXT_SERVICE } from '../traffic-context.js';
import type { StreamedModelTurn } from '../streamed-model-turn.js';
import { OpenRouterChatCompletionsModel, openRouterErrorDetail } from './openrouter-chat-completions-model.js';

const DEFAULT_REFERRER = 'https://github.com/qduc/term2';
const DEFAULT_TITLE = 'term2';

function createOpenRouterModel(deps: ProviderDeps, model: string): StreamedModelTurn | null {
  const { settingsService, loggingService, sessionContextService } = deps;
  const apiKey = settingsService.get('agent.openrouter.apiKey') || process.env.OPENROUTER_API_KEY;
  if (!apiKey) return null;

  const referrer = settingsService.get('agent.openrouter.referrer') || DEFAULT_REFERRER;
  const title = settingsService.get('agent.openrouter.title') || DEFAULT_TITLE;
  const client = new OpenAI({
    baseURL: settingsService.get('agent.openrouter.baseUrl') || 'https://openrouter.ai/api/v1',
    apiKey,
    defaultHeaders: {
      'HTTP-Referer': referrer,
      'X-Title': title,
      'X-OpenRouter-Title': title,
    },
    // RetryingModel owns retries for this provider. The SDK path it replaces
    // never retried at the fetch level, so the client must not add a second layer.
    maxRetries: 0,
    fetch: createProviderFetch({
      providerId: 'openrouter',
      defaultModel: settingsService.get('agent.modelSelection').model || model,
      deps: {
        loggingService,
        sessionContextService: sessionContextService ?? NULL_SESSION_CONTEXT_SERVICE,
        onDispatched: deps.onDispatched,
      },
      middlewares: [openRouterPreprocessingMiddleware, openRouterErrorDetailMiddleware],
    }),
  });
  return new OpenRouterChatCompletionsModel(client, model);
}

function sanitizeOpenRouterReasoningDetails(messages: any[]): void {
  const requiresSignature = new Set(['google-gemini-v1', 'anthropic-claude-v1']);
  for (const message of messages) {
    if (!Array.isArray(message?.reasoning_details)) {
      continue;
    }
    message.reasoning_details = message.reasoning_details.filter((detail: any) => {
      if (detail?.type !== 'reasoning.text') {
        return true;
      }
      if (!requiresSignature.has(detail?.format)) {
        return true;
      }
      return Boolean(detail?.signature);
    });
  }
}

/**
 * The OpenAI SDK builds an HTTP error message from `error.message` alone, which
 * would drop the upstream detail in `error.metadata`. Fold that detail into the
 * message. The body keeps its shape, so `APIError.error` still carries metadata.
 */
const openRouterErrorDetailMiddleware: FetchMiddleware = async (ctx, next) => {
  const response = await next(ctx);
  if (response.ok) return response;
  const text = await response.text();
  const headers = new Headers(response.headers);
  headers.delete('content-length');
  return new Response(enrichOpenRouterErrorBody(text) ?? text, {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
};

function enrichOpenRouterErrorBody(text: string): string | undefined {
  let body: any;
  try {
    body = JSON.parse(text);
  } catch {
    return undefined;
  }
  const error = body?.error;
  const detail = openRouterErrorDetail(error);
  if (!detail || typeof error?.message !== 'string') return undefined;
  return JSON.stringify({ ...body, error: { ...error, message: `${error.message} (${detail})` } });
}

export const openRouterPreprocessingMiddleware: FetchMiddleware = async (ctx, next) => {
  if (typeof ctx.init?.body === 'string') {
    try {
      const body = JSON.parse(ctx.init.body);
      if (Array.isArray(body?.messages)) {
        sanitizeOpenRouterReasoningDetails(body.messages);
        addCacheControlToLastTwoMessages(body.messages, body.model);
        ctx.init = { ...ctx.init, body: JSON.stringify(body) };
      }
    } catch {
      /* fall through */
    }
  }
  return next(ctx);
};

async function fetchOpenRouterModels(
  deps: ProviderDeps,
  fetchImpl: ProviderFetch = fetch,
): Promise<Array<{ id: string; name?: string }>> {
  const { settingsService } = deps;

  const baseUrl = settingsService.get('agent.openrouter.baseUrl') || 'https://openrouter.ai/api/v1';
  const apiKey = settingsService.get('agent.openrouter.apiKey') || process.env.OPENROUTER_API_KEY;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (apiKey) {
    headers.Authorization = `Bearer ${apiKey}`;
  }

  const response = await fetchImpl(`${baseUrl}/models`, { headers });
  if (!response.ok) {
    throw new Error(`OpenRouter models request failed (${response.status})`);
  }

  const body = await response.json();
  const twoYearsAgo = new Date();
  twoYearsAgo.setUTCFullYear(twoYearsAgo.getUTCFullYear() - 2);
  const minimumCreatedAt = twoYearsAgo.getTime() / 1000;
  const filteredData = (body?.data || []).filter(
    (item: any) =>
      Array.isArray(item?.supported_parameters) &&
      item.supported_parameters.includes('tools') &&
      typeof item.created === 'number' &&
      Number.isFinite(item.created) &&
      item.created >= minimumCreatedAt,
  );

  if (!Array.isArray(filteredData)) return [];

  return filteredData
    .map((item: any) => {
      const id = item?.id || item?.model || '';
      const name = item?.name || item?.display_name || item?.description;
      return id ? { id, name } : null;
    })
    .filter(Boolean) as Array<{ id: string; name?: string }>;
}

// Register OpenRouter provider
registerProvider(
  {
    id: 'openrouter',
    label: 'OpenRouter',
    createStreamedModel: async (model, deps): Promise<StreamedModelTurn> => {
      const streamedModel = createOpenRouterModel(deps, model);
      if (!streamedModel) throw new Error('OpenRouter API key is not configured');
      const retryAttempts = deps.retryAttempts ?? deps.settingsService.get('agent.retryAttempts') ?? 2;
      return new RetryingModel(streamedModel, {
        retryAttempts,
        loggingService: deps.loggingService,
        onRetry: deps.onRetry,
      });
    },
    fetchModels: fetchOpenRouterModels,
    sensitiveSettingKeys: [
      'agent.openrouter.apiKey',
      'agent.openrouter.baseUrl',
      'agent.openrouter.referrer',
      'agent.openrouter.title',
    ],
    capabilities: {
      supportsFlexServiceTier: true,
      supportsConversationChaining: false,
    },
  },
  { builtin: true },
);
