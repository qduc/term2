import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  getAllProviders,
  getProvider,
  unregisterProvider,
  upsertProvider,
  type ProviderDefinition,
} from '../../src/model/providers/registry.js';
import '../../src/model/providers/index.js';
import { createOpenAICompatibleProviderDefinition } from '../../src/model/providers/openai-compatible.provider.js';
import { RetryingModel } from '../../src/model/providers/retrying-model.js';
import { isTransientRetryableError } from '../../src/model/failure/retry-error-classification.js';
import type { ILoggingService, ISettingsService } from '../../src/shared/service-interfaces.js';
import { startFakeProviderHttpServer, type FakeProviderHttpServer } from './fake-provider-http-server.js';
import { readFixtureEnvelope } from './fixture-envelope.js';
import { fixtureRequest, fixtureTool, multiTurnFixture } from './provider-wire-fixtures.js';

type Protocol = 'chat-completions' | 'responses' | 'anthropic' | 'google';
type RuntimeProviderType = 'openai-compatible' | 'anthropic' | 'google' | 'opencode' | 'llama.cpp';

interface ProviderCase {
  name: string;
  registryId: string;
  model: string;
  protocol: Protocol;
  expectedRoles: readonly string[];
  runtimeType?: RuntimeProviderType;
  basePath?: string;
  providerOptions: Record<string, unknown>;
}

const providerCases: readonly ProviderCase[] = [
  {
    name: 'OpenAI Responses HTTP',
    registryId: 'openai',
    model: 'gpt-fixture',
    protocol: 'responses',
    expectedRoles: ['user', 'assistant', 'user'],
    providerOptions: { extraBody: { prompt_cache_key: 'fixture-cache' } },
  },
  {
    name: 'Chat Completions',
    registryId: 'fixture-chat-completions',
    model: 'chat-fixture',
    protocol: 'chat-completions',
    expectedRoles: ['user', 'assistant', 'user'],
    runtimeType: 'openai-compatible',
    providerOptions: { response_format: { type: 'text' } },
  },
  {
    name: 'Anthropic',
    registryId: 'fixture-anthropic',
    model: 'claude-fixture',
    protocol: 'anthropic',
    expectedRoles: ['user', 'assistant', 'user'],
    runtimeType: 'anthropic',
    providerOptions: { anthropic: { topK: 7 } },
  },
  {
    name: 'Google',
    registryId: 'fixture-google',
    model: 'gemini-fixture',
    protocol: 'google',
    expectedRoles: ['user', 'model', 'user'],
    runtimeType: 'google',
    providerOptions: {
      google: { safetySettings: [{ category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' }] },
    },
  },
  {
    name: 'OpenRouter',
    registryId: 'openrouter',
    model: 'fixture/provider',
    protocol: 'chat-completions',
    expectedRoles: ['user', 'assistant', 'user'],
    providerOptions: { transforms: ['middle-out'], reasoning: { effort: 'medium' } },
  },
] as const;

let server: FakeProviderHttpServer | undefined;
const runtimeProviderIds = new Set<string>();

afterEach(async () => {
  await server?.close();
  server = undefined;
  for (const id of runtimeProviderIds) unregisterProvider(id);
  runtimeProviderIds.clear();
  vi.unstubAllGlobals();
});

describe('provider boundary contracts through the registry', () => {
  it.each(['llama.cpp', 'openai-compatible'] as const)(
    '%s keeps reasoning translation scoped to its adapter',
    async (runtimeType) => {
      const providerCase: ProviderCase = { ...providerCases[1]!, runtimeType };
      server = await startFakeProviderHttpServer({ scenario: 'success', protocol: 'chat-completions' });
      const settings = createSettings(providerCase);
      registerRuntimeProvider(providerCase, settings);
      const model = await getProvider(providerCase.registryId)!.createStreamedModel!(providerCase.model, {
        settingsService: settings,
        loggingService: quietLogging,
      });
      const events = await collect(model.stream({ ...requestFor(providerCase), reasoning: { effort: 'minimal' } }));
      const request = server.requests.at(-1)!;
      const body = request.body as Record<string, any>;
      expect(events.at(-1)).toMatchObject({ type: 'completion' });
      expect(request.headers['x-opencode-session']).toBeUndefined();
      if (runtimeType === 'llama.cpp') {
        expect(body.reasoning_effort).toBeUndefined();
        expect(body.chat_template_kwargs).toEqual({
          reasoning_effort: 'low',
          enable_thinking: false,
          thinking_mode: 'disabled',
          reasoning_budget: 0,
        });
      } else {
        expect(body.reasoning_effort).toBe('minimal');
        expect(body.chat_template_kwargs).toBeUndefined();
      }
    },
  );

  it.each([
    { protocol: 'chat-completions' as const, model: 'deepseek-fixture' },
    { protocol: 'responses' as const, model: 'gpt-fixture' },
    { protocol: 'anthropic' as const, model: 'qwen-fixture' },
  ])('OpenCode $protocol preserves session affinity across recreated models', async ({ protocol, model }) => {
    const providerCase: ProviderCase = {
      ...providerCases[1]!,
      protocol,
      model,
      runtimeType: 'opencode',
      basePath: '/zen/go/v1',
    };
    server = await startFakeProviderHttpServer({ scenario: 'success', protocol });
    const settings = createSettings(providerCase);
    registerRuntimeProvider(providerCase, settings);
    for (let turn = 0; turn < 2; turn++) {
      const streamedModel = await getProvider(providerCase.registryId)!.createStreamedModel!(model, {
        settingsService: settings,
        loggingService: quietLogging,
        sessionContextService: { getContext: () => ({ sessionId: 'adapter-fixture-session' }) } as any,
      });
      const events = await collect(streamedModel.stream(requestFor(providerCase)));
      expect(events.at(-1)).toMatchObject({ type: 'completion' });
    }
    expect(server.requests).toHaveLength(2);
    const session = server.requests[0]!.headers['x-opencode-session'];
    expect(session).toMatch(/^ses_/);
    expect(server.requests[1]!.headers['x-opencode-session']).toBe(session);
  });

  it.each([
    {
      index: 2,
      options: { anthropic: { thinking: { type: 'enabled', budgetTokens: 6000 } } },
      expected: { thinking: { type: 'enabled', budget_tokens: 6000 } },
    },
    {
      index: 3,
      options: { google: { thinkingConfig: { thinkingBudget: 6000, includeThoughts: false } } },
      expected: { generationConfig: { thinkingConfig: { thinkingBudget: 6000, includeThoughts: false } } },
    },
    { index: 4, options: { openrouter: { reasoning: { effort: 'low' } } }, expected: { reasoning: { effort: 'low' } } },
  ])(
    'SDK adapter $index preserves explicit reasoning settings over selected effort',
    async ({ index, options, expected }) => {
      const providerCase = providerCases[index]!;
      server = await startFakeProviderHttpServer({ scenario: 'success', protocol: providerCase.protocol });
      const settings = createSettings(providerCase);
      registerRuntimeProvider(providerCase, settings);
      const model = await getProvider(providerCase.registryId)!.createStreamedModel!(providerCase.model, {
        settingsService: settings,
        loggingService: quietLogging,
      });
      const events = await collect(
        model.stream({ ...requestFor(providerCase), providerOptions: options, reasoning: { effort: 'high' } }),
      );
      expect(events.at(-1)).toMatchObject({ type: 'completion' });
      expect(server.requests.at(-1)!.body).toMatchObject(expected);
    },
  );

  it.each([
    { retryDelay: '39.676606339s', expected: 39677 },
    { retryDelay: '59.999s', expected: 59999 },
    { retryDelay: '60s', expected: 60000 },
    { retryDelay: '60.001s', expected: undefined },
    { retryDelay: '120s', expected: undefined },
    { retryDelay: '-1s', expected: 500 },
    { retryDelay: 'not-a-duration', expected: 500 },
    {
      message: 'Quota exceeded. https://ai.google.dev/gemini-api/docs/rate-limits. Please retry in 9.592042673s.',
      expected: 9593,
    },
    { retryAfter: '2.5', expected: 2500 },
  ])('honors bounded Google quota delays through the real SDK: %j', async ({ expected, ...googleRateLimit }) => {
    const providerCase = providerCases[3]!;
    server = await startFakeProviderHttpServer({ scenario: 'success', protocol: 'google', googleRateLimit });
    const settings = createSettings(providerCase);
    registerRuntimeProvider(providerCase, settings);
    const providerModel = await getProvider(providerCase.registryId)!.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    let failure: unknown;
    try {
      await collect(providerModel.stream(requestFor(providerCase)));
    } catch (error) {
      failure = error;
    }
    expect(failure).toBeDefined();
    expect(isTransientRetryableError(failure)).toBe(expected !== undefined);
    if (expected === undefined) {
      const model = new RetryingModel(
        {
          ...providerModel,
          async *stream() {
            throw failure;
          },
        },
        {
          retryAttempts: 1,
          sleep: async () => {
            throw new Error('must not sleep');
          },
        },
      );
      await expect(collect(model.stream(requestFor(providerCase)))).rejects.toBe(failure);
      expect(server.requests).toHaveLength(1);
      return;
    }
    const delays: number[] = [];
    let attempts = 0;
    const model = new RetryingModel(
      {
        ...providerModel,
        async *stream(request) {
          if (attempts++ === 0) throw failure;
          yield* providerModel.stream(request);
        },
      },
      {
        retryAttempts: 1,
        random: () => 0,
        sleep: async (ms) => {
          delays.push(ms);
        },
      },
    );
    const events = await collect(model.stream(requestFor(providerCase)));
    // Invalid hints retain the provider wrapper's existing randomized fallback.
    expect(delays).toEqual([expected === 500 ? 0 : expected]);
    expect(events.at(-1)).toMatchObject({ type: 'completion' });
    expect(server.requests).toHaveLength(2);
  });
  it('keeps the built-in registry surface available', () => {
    for (const id of ['openai', 'openrouter']) {
      expect(getProvider(id)?.createStreamedModel, id).toBeTypeOf('function');
    }
    expect(getAllProviders().length).toBeGreaterThanOrEqual(3);
  });

  it('pilot Chat Completions provider replays a synthetic chat-completions fixture through the registry', async () => {
    // Machinery pilot: chat-pilot.json is hand-authored (not a real-traffic
    // recording), so this proves the record → sanitize → replay pipeline
    // end-to-end only. The generic fixture path remains synthetic; the real
    // OpenCode Chat Completions path below exercises the live wire shape.
    const fixture = await readFixtureEnvelope(new URL('./fixtures/fixture/chat-pilot.json', import.meta.url).pathname);
    server = await startFakeProviderHttpServer({ fixture });
    const providerCase = providerCases[1]!;
    const settings = createSettings(providerCase);
    registerRuntimeProvider(providerCase, settings);
    const provider = getProvider(providerCase.registryId)!;
    const model = await provider.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    const events = await collect(model.stream(requestFor(providerCase)));
    expect(events.filter((event) => event.type === 'text_delta')).toEqual([{ type: 'text_delta', text: 'hello' }]);
    expect(events.at(-1)).toMatchObject({ type: 'completion' });
    server.assertReplayValid();
  });

  it('real OpenAI Responses capture replays tool continuation through the built-in registry', async () => {
    const fixture = await readFixtureEnvelope(
      new URL('./fixtures/openai/tool-continuation-v1.json', import.meta.url).pathname,
    );
    server = await startFakeProviderHttpServer({ fixture });
    const providerCase = { ...providerCases[0]!, model: 'o3-mini' };
    const settings = createSettings(providerCase);
    installOpenAiHttpRedirect(providerCase);
    const provider = getProvider('openai')!;
    const model = await provider.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    const initial = {
      ...fixtureRequest,
      input: [
        {
          type: 'message',
          role: 'user',
          content: [{ type: 'text', text: 'Use the fixture tool and then summarize its result.' }],
        },
      ],
    } as any;
    const firstEvents = await collect(model.stream(initial));
    const call =
      (firstEvents.find((event: any) => event.type === 'tool_call') as any) ??
      firstEvents.flatMap((event: any) => event.output ?? []).find((item: any) => item.type === 'tool_call');
    expect(call).toMatchObject({ id: expect.any(String), name: fixtureTool.name });

    const continuation = {
      ...initial,
      input: [
        ...initial.input,
        { type: 'tool_call', id: call.id, name: call.name, arguments: call.arguments },
        { type: 'tool_result', id: call.id, output: { ok: true, value: 1 } },
        {
          type: 'message',
          role: 'user',
          content: [
            { type: 'text', text: 'The fixture tool returned its deterministic result. Give the final summary.' },
          ],
        },
      ],
    } as any;
    const secondEvents = await collect(model.stream(continuation));
    const allEvents = [...firstEvents, ...secondEvents];
    expect(
      allEvents
        .flatMap((event: any) => (event.type === 'tool_call' ? [event] : event.output ?? []))
        .filter((event: any) => event.type === 'tool_call'),
    ).toHaveLength(1);
    expect(secondEvents.filter((event) => event.type === 'text_delta').length).toBeGreaterThan(0);
    expect(secondEvents.at(-1)).toMatchObject({ type: 'completion' });
    expect(
      fixture.turns.flatMap((turn) =>
        turn.frames.filter((frame) => frame.kind === 'sse-event').map((frame) => frame.event),
      ),
    ).toContain('response.function_call_arguments.delta');
    expect(
      fixture.turns.flatMap((turn) =>
        turn.frames.filter((frame) => frame.kind === 'sse-event').map((frame) => frame.event),
      ),
    ).toContain('response.completed');
    server.assertReplayValid();
  });

  it('real OpenRouter capture replays tool continuation through the built-in registry', async () => {
    const fixture = await readFixtureEnvelope(
      new URL('./fixtures/openrouter/tool-continuation-v1.json', import.meta.url).pathname,
    );
    server = await startFakeProviderHttpServer({ fixture });
    const providerCase = { ...providerCases[4]!, model: 'openai/gpt-oss-20b', providerOptions: {} };
    const baseSettings = createSettings(providerCase);
    const settings = {
      ...baseSettings,
      get: (key: string) =>
        ({
          'agent.openrouter.baseUrl': `${server!.baseUrl}/api/v1`,
          'agent.openrouter.referrer': 'https://github.com/qduc/term2',
          'agent.openrouter.title': 'term2',
        }[key] ?? baseSettings.get(key)),
    } as ISettingsService;
    const provider = getProvider('openrouter')!;
    const model = await provider.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    const initial = {
      ...fixtureRequest,
      reasoning: { effort: 'default' },
      input: [
        {
          type: 'message',
          role: 'user',
          content: [{ type: 'text', text: 'Use the fixture tool and then summarize its result.' }],
        },
      ],
    } as any;
    const firstEvents = await collect(model.stream(initial));
    const call =
      (firstEvents.find((event: any) => event.type === 'tool_call') as any) ??
      firstEvents.flatMap((event: any) => event.output ?? []).find((item: any) => item.type === 'tool_call');
    expect(call).toMatchObject({ id: expect.any(String), name: fixtureTool.name });

    const continuation = {
      ...initial,
      input: [
        ...initial.input,
        { type: 'tool_call', id: call.id, name: call.name, arguments: call.arguments },
        { type: 'tool_result', id: call.id, output: JSON.stringify({ ok: true, value: 1 }) },
        {
          type: 'message',
          role: 'user',
          content: [
            { type: 'text', text: 'The fixture tool returned its deterministic result. Give the final summary.' },
          ],
        },
      ],
    } as any;
    const secondEvents = await collect(model.stream(continuation));
    const allEvents = [...firstEvents, ...secondEvents];
    const toolCalls = allEvents
      .flatMap((event: any) => (event.type === 'tool_call' ? [event] : event.output ?? []))
      .filter((event: any) => event.type === 'tool_call');
    expect(new Set(toolCalls.map((event: any) => event.id))).toHaveLength(1);
    expect(secondEvents.filter((event) => event.type === 'text_delta').length).toBeGreaterThan(0);
    expect(secondEvents.at(-1)).toMatchObject({ type: 'completion' });
    expect(fixture.turns.flatMap((turn) => turn.frames).some((frame) => frame.kind === 'sse-event')).toBe(true);
    // The recorded frames name CoreWeave as the routed upstream and stream reasoning_details.
    expect(secondEvents.at(-1)).toMatchObject({
      providerMetadata: { openrouter: { provider: 'CoreWeave' } },
      costUsd: expect.any(Number),
    });
    expect(secondEvents.at(-1)).toMatchObject({
      output: expect.arrayContaining([
        expect.objectContaining({
          type: 'provider_opaque',
          provider: 'openrouter',
          item: expect.objectContaining({ reasoning_details: expect.any(Array) }),
        }),
      ]),
    });
    server.assertReplayValid();
  });

  it('real OpenCode Chat Completions capture replays tool continuation through the registry', async () => {
    const fixture = await readFixtureEnvelope(
      new URL('./fixtures/opencode/tool-continuation-v1.json', import.meta.url).pathname,
    );
    server = await startFakeProviderHttpServer({ fixture });
    const providerCase: ProviderCase = {
      ...providerCases[1]!,
      name: 'OpenCode Chat Completions',
      registryId: 'fixture-opencode-chat',
      model: 'deepseek-v4-flash',
      runtimeType: 'opencode',
      basePath: '/zen/go/v1',
      providerOptions: {},
    };
    const settings = createSettings(providerCase);
    registerRuntimeProvider(providerCase, settings);
    const provider = getProvider(providerCase.registryId)!;
    const model = await provider.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    const initial = {
      ...fixtureRequest,
      input: [
        {
          type: 'message',
          role: 'user',
          content: [{ type: 'text', text: 'Use the fixture tool and then summarize its result.' }],
        },
      ],
    } as any;
    const firstEvents = await collect(model.stream(initial));
    const call =
      (firstEvents.find((event: any) => event.type === 'tool_call') as any) ??
      firstEvents.flatMap((event: any) => event.output ?? []).find((item: any) => item.type === 'tool_call');
    expect(call).toMatchObject({ id: expect.any(String), name: fixtureTool.name });

    const continuation = {
      ...initial,
      input: [
        ...initial.input,
        { type: 'tool_call', id: call.id, name: call.name, arguments: call.arguments },
        { type: 'tool_result', id: call.id, output: JSON.stringify({ ok: true, value: 1 }) },
        {
          type: 'message',
          role: 'user',
          content: [
            { type: 'text', text: 'The fixture tool returned its deterministic result. Give the final summary.' },
          ],
        },
      ],
    } as any;
    const secondEvents = await collect(model.stream(continuation));
    const allEvents = [...firstEvents, ...secondEvents];
    const toolCalls = allEvents
      .flatMap((event: any) => (event.type === 'tool_call' ? [event] : event.output ?? []))
      .filter((event: any) => event.type === 'tool_call');
    expect(new Set(toolCalls.map((event: any) => event.id))).toHaveLength(1);
    expect(secondEvents.filter((event) => event.type === 'text_delta').length).toBeGreaterThan(0);
    expect(secondEvents.at(-1)).toMatchObject({ type: 'completion' });
    expect(fixture.turns.flatMap((turn) => turn.frames).some((frame) => frame.kind === 'sse-event')).toBe(true);
    server.assertReplayValid();
  });

  it('real OpenCode Anthropic capture replays tool continuation through the registry', async () => {
    const fixture = await readFixtureEnvelope(
      new URL('./fixtures/opencode/tool-continuation-v1-anthropic.json', import.meta.url).pathname,
    );
    server = await startFakeProviderHttpServer({ fixture });
    const providerCase: ProviderCase = {
      ...providerCases[2]!,
      name: 'OpenCode Anthropic',
      registryId: 'fixture-opencode-anthropic',
      model: 'minimax-m3',
      runtimeType: 'opencode',
      basePath: '/zen/go/v1',
      providerOptions: {},
    };
    const settings = createSettings(providerCase);
    registerRuntimeProvider(providerCase, settings);
    const provider = getProvider(providerCase.registryId)!;
    const model = await provider.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    const initial = {
      ...fixtureRequest,
      input: [
        {
          type: 'message',
          role: 'user',
          content: [{ type: 'text', text: 'Use the fixture tool and then summarize its result.' }],
        },
      ],
    } as any;
    const firstEvents = await collect(model.stream(initial));
    const call =
      (firstEvents.find((event: any) => event.type === 'tool_call') as any) ??
      firstEvents.flatMap((event: any) => event.output ?? []).find((item: any) => item.type === 'tool_call');
    expect(call).toMatchObject({ id: expect.any(String), name: fixtureTool.name });

    const continuation = {
      ...initial,
      input: [
        ...initial.input,
        { type: 'tool_call', id: call.id, name: call.name, arguments: call.arguments },
        { type: 'tool_result', id: call.id, output: JSON.stringify({ ok: true, value: 1 }) },
        {
          type: 'message',
          role: 'user',
          content: [
            { type: 'text', text: 'The fixture tool returned its deterministic result. Give the final summary.' },
          ],
        },
      ],
    } as any;
    const secondEvents = await collect(model.stream(continuation));
    const allEvents = [...firstEvents, ...secondEvents];
    const toolCalls = allEvents
      .flatMap((event: any) => (event.type === 'tool_call' ? [event] : event.output ?? []))
      .filter((event: any) => event.type === 'tool_call');
    expect(new Set(toolCalls.map((event: any) => event.id))).toHaveLength(1);
    expect(secondEvents.filter((event) => event.type === 'text_delta').length).toBeGreaterThan(0);
    expect(secondEvents.at(-1)).toMatchObject({ type: 'completion' });
    expect(
      fixture.turns.flatMap((turn) =>
        turn.frames.filter((frame) => frame.kind === 'sse-event').map((frame) => frame.data),
      ),
    ).toEqual(
      expect.arrayContaining([expect.stringContaining('message_start'), expect.stringContaining('message_stop')]),
    );
    server.assertReplayValid();
  });

  it('real Google capture replays tool continuation through the registry', async () => {
    const fixture = await readFixtureEnvelope(
      new URL('./fixtures/google/tool-continuation-v1.json', import.meta.url).pathname,
    );
    // The old recording predates signature-preserving replay. Keep its response
    // frames, but expect the returned (redacted) signature on the continuation.
    const continuationFrame = fixture.turns[1]!.frames.find((frame) => frame.kind === 'http-request');
    if (!continuationFrame || continuationFrame.kind !== 'http-request') throw new Error('Missing continuation');
    const continuationBody = continuationFrame.body as {
      contents: Array<{ parts: Array<{ functionCall?: unknown; thoughtSignature?: string }> }>;
    };
    const signedCall = continuationBody.contents.flatMap((message) => message.parts).find((part) => part.functionCall);
    if (!signedCall) throw new Error('Missing recorded function call');
    signedCall.thoughtSignature = '[REDACTED]';
    server = await startFakeProviderHttpServer({ fixture });
    const providerCase = { ...providerCases[3]!, model: 'gemini-2.5-flash' };
    const settings = createSettings(providerCase);
    registerRuntimeProvider(providerCase, settings);
    const provider = getProvider(providerCase.registryId)!;
    const model = await provider.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    const initial = {
      ...fixtureRequest,
      input: [
        {
          type: 'message',
          role: 'user',
          content: [{ type: 'text', text: 'Use the fixture tool and then summarize its result.' }],
        },
      ],
    } as any;
    const firstEvents = await collect(model.stream(initial));
    const call =
      (firstEvents.find((event: any) => event.type === 'tool_call') as any) ??
      firstEvents.flatMap((event: any) => event.output ?? []).find((item: any) => item.type === 'tool_call');
    expect(call).toMatchObject({
      id: expect.any(String),
      name: fixtureTool.name,
      providerMetadata: { google: { thoughtSignature: '[REDACTED]' } },
    });
    expect(firstEvents.at(-1)?.output).toContainEqual(call);

    const continuation = {
      ...initial,
      input: [
        ...initial.input,
        call,
        { type: 'tool_result', id: call.id, output: JSON.stringify({ ok: true, value: 1 }) },
        {
          type: 'message',
          role: 'user',
          content: [
            { type: 'text', text: 'The fixture tool returned its deterministic result. Give the final summary.' },
          ],
        },
      ],
    } as any;
    const secondEvents = await collect(model.stream(continuation));
    const allEvents = [...firstEvents, ...secondEvents];
    const toolCalls = allEvents
      .flatMap((event: any) => (event.type === 'tool_call' ? [event] : event.output ?? []))
      .filter((event: any) => event.type === 'tool_call');
    expect(new Set(toolCalls.map((event: any) => event.id))).toHaveLength(1);
    expect(secondEvents.filter((event) => event.type === 'text_delta').length).toBeGreaterThan(0);
    expect(secondEvents.at(-1)).toMatchObject({ type: 'completion' });
    expect(
      fixture.turns.flatMap((turn) =>
        turn.frames.filter((frame) => frame.kind === 'sse-event').map((frame) => frame.data),
      ),
    ).toEqual(expect.arrayContaining([expect.stringContaining('functionCall'), expect.stringContaining('STOP')]));
    server.assertReplayValid();
  });

  it.each(providerCases)('$name succeeds with one authoritative completion', async (providerCase) => {
    const result = await runProviderCase(providerCase, 'success');
    const completions = result.events.filter((event) => event.type === 'completion');

    expect(completions).toHaveLength(1);
    expect(result.events.at(-1)).toBe(completions[0]);
    expect(completions[0]).toMatchObject({ type: 'completion', output: [{ type: 'message' }] });
    expect(completions[0]?.output?.[0]?.content?.[0]?.text).toBe('hello');
    // Assert the delivered text rather than the whole event: a delta's part id
    // is fixture-specific (an Anthropic content-block index is present, a
    // Responses fixture without an item_id is not). Part identity is pinned by
    // the provider unit tests.
    expect(result.events.filter((event) => event.type === 'text_delta').map((event) => event.text)).toEqual(['hello']);
  });

  it.each(providerCases)(
    '$name preserves request roles, tools, reasoning, and provider options',
    async (providerCase) => {
      const result = await runProviderCase(providerCase, 'success');
      assertRequestShape(providerCase, result.body);
    },
  );

  it.each(providerCases)(
    '$name propagates a provider error instead of fabricating completion',
    async (providerCase) => {
      const result = await runProviderCaseExpectingError(providerCase);

      expect(result.error).toBeInstanceOf(Error);
      expect(result.error.message).not.toContain('hello');
      expect(result.events).toEqual([]);
    },
  );

  it('replays OpenAI-compatible native reasoning_content through the registry tool continuation boundary', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'reasoning', protocol: 'chat-completions' });
    const providerCase: ProviderCase = {
      name: 'Reasoning continuation fixture',
      registryId: 'fixture-openai-compatible-reasoning',
      model: 'thinking-fixture',
      protocol: 'chat-completions',
      expectedRoles: [],
      runtimeType: 'openai-compatible',
      providerOptions: {},
    };
    const settings = createSettings(providerCase);
    registerRuntimeProvider(providerCase, settings);
    const provider = getProvider(providerCase.registryId)!;
    const model = await provider.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    const initial = {
      ...fixtureRequest,
      input: [{ type: 'message', role: 'user', content: [{ type: 'text', text: 'look up fixture' }] }],
    } as any;
    const first = await collect(model.stream(initial));
    const reasoning = first.flatMap((event: any) => event.output ?? []).find((item: any) => item.type === 'reasoning');
    const opaque = first
      .flatMap((event: any) => event.output ?? [])
      .find((item: any) => item.type === 'provider_opaque');
    expect(reasoning).toEqual({
      type: 'reasoning',
      text: 'Need native reasoning.',
    });
    expect(opaque).toEqual({
      type: 'provider_opaque',
      provider: 'fixture-openai-compatible-reasoning',
      item: { reasoning_content: 'Need native reasoning.' },
    });

    await collect(
      model.stream({
        ...initial,
        input: [
          ...initial.input,
          {
            type: 'reasoning',
            text: reasoning.text,
          },
          {
            type: 'provider_opaque',
            provider: 'fixture-openai-compatible-reasoning',
            item: { reasoning_content: 'Need native reasoning.' },
          },
          { type: 'tool_call', id: 'call_reasoning', name: fixtureTool.name, arguments: '{}' },
          { type: 'tool_result', id: 'call_reasoning', output: 'fixture result' },
        ],
      }),
    );

    expect(server.requests).toHaveLength(2);
    expect((server.requests[1]!.body as any).messages).toContainEqual({
      role: 'assistant',
      content: null,
      reasoning_content: 'Need native reasoning.',
      tool_calls: [{ id: 'call_reasoning', type: 'function', function: { name: fixtureTool.name, arguments: '{}' } }],
    });
  });

  it('captures OpenRouter-style delta.reasoning and replays it through the registry tool continuation boundary', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'reasoning-field', protocol: 'chat-completions' });
    const providerCase: ProviderCase = {
      name: 'Gateway reasoning continuation fixture',
      registryId: 'fixture-openai-compatible-reasoning-field',
      model: 'thinking-fixture',
      protocol: 'chat-completions',
      expectedRoles: [],
      runtimeType: 'openai-compatible',
      providerOptions: {},
    };
    const settings = createSettings(providerCase);
    registerRuntimeProvider(providerCase, settings);
    const provider = getProvider(providerCase.registryId)!;
    const model = await provider.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    const initial = {
      ...fixtureRequest,
      input: [{ type: 'message', role: 'user', content: [{ type: 'text', text: 'look up fixture' }] }],
    } as any;
    const first = await collect(model.stream(initial));
    const reasoning = first.flatMap((event: any) => event.output ?? []).find((item: any) => item.type === 'reasoning');
    const opaque = first
      .flatMap((event: any) => event.output ?? [])
      .find((item: any) => item.type === 'provider_opaque');
    expect(reasoning).toEqual({
      type: 'reasoning',
      text: 'Need gateway reasoning.',
    });
    expect(opaque).toEqual({
      type: 'provider_opaque',
      provider: 'fixture-openai-compatible-reasoning-field',
      item: { reasoning: 'Need gateway reasoning.' },
    });

    await collect(
      model.stream({
        ...initial,
        input: [
          ...initial.input,
          {
            type: 'reasoning',
            text: reasoning.text,
          },
          {
            type: 'provider_opaque',
            provider: 'fixture-openai-compatible-reasoning-field',
            item: { reasoning: 'Need gateway reasoning.' },
          },
          { type: 'tool_call', id: 'call_reasoning', name: fixtureTool.name, arguments: '{}' },
          { type: 'tool_result', id: 'call_reasoning', output: 'fixture result' },
        ],
      }),
    );

    expect(server.requests).toHaveLength(2);
    expect((server.requests[1]!.body as any).messages).toContainEqual({
      role: 'assistant',
      content: null,
      reasoning: 'Need gateway reasoning.',
      tool_calls: [{ id: 'call_reasoning', type: 'function', function: { name: fixtureTool.name, arguments: '{}' } }],
    });
  });

  it('reassembles Chat Completions tool fragments with the authoritative tool ID', async () => {
    const providerCase = providerCases[1]!;
    const result = await runProviderCase(providerCase, 'tool-fragments');
    const toolEvents = result.events.filter((event) => event.type === 'tool_call');
    const completion = result.events.find((event) => event.type === 'completion');

    expect(toolEvents).toEqual([{ type: 'tool_call', id: 'call_fake', name: 'fixture', arguments: '{"a":1}' }]);
    expect(completion).toMatchObject({
      output: [{ type: 'tool_call', id: 'call_fake', name: 'fixture', arguments: '{"a":1}' }],
    });
  });

  it('retries an in-band 502 that follows trivial whitespace and succeeds', async () => {
    const providerCase = providerCases[4]!;
    server = await startFakeProviderHttpServer({ scenario: 'in-band-error-retry', protocol: providerCase.protocol });
    const settings = createSettings(providerCase);
    installOpenAiHttpRedirect(providerCase);
    registerRuntimeProvider(providerCase, settings);

    const provider = getProvider(providerCase.registryId)!;
    const providerModel = await provider.createStreamedModel!(providerCase.model, {
      settingsService: settings,
      loggingService: quietLogging,
    });
    const model = new RetryingModel(providerModel, { retryAttempts: 1, sleep: async () => {} });
    const events = await collect(model.stream(requestFor(providerCase)));

    expect(events.filter((event) => event.type === 'text_delta').map((event) => event.text)).toEqual(['hello']);
    expect(events.at(-1)).toMatchObject({ type: 'completion' });
    expect(server.requests).toHaveLength(2);
  });
});

describe('OpenRouter chat-completions boundary through the registry', () => {
  const openRouterCase = providerCases[4]!;

  it('sends the selected effort as reasoning.effort, never as reasoning_effort', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'success', protocol: 'chat-completions' });
    const model = await openRouterModel();
    const events = await collect(
      model.stream({ ...requestFor(openRouterCase), providerOptions: {}, reasoning: { effort: 'high' } }),
    );
    expect(events.at(-1)).toMatchObject({ type: 'completion' });
    const body = server.requests.at(-1)!.body as Record<string, unknown>;
    expect(body.reasoning).toEqual({ effort: 'high' });
    expect(body).not.toHaveProperty('reasoning_effort');
    expect(body).not.toHaveProperty('openrouter');
    expect(body).not.toHaveProperty('providerOptions');
  });

  it('omits reasoning for the default effort and sends attribution headers and bearer auth', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'success', protocol: 'chat-completions' });
    const model = await openRouterModel();
    await collect(
      model.stream({ ...requestFor(openRouterCase), providerOptions: {}, reasoning: { effort: 'default' } }),
    );
    const request = server.requests.at(-1)!;
    expect(request.body).not.toHaveProperty('reasoning');
    expect(request.headers['http-referer']).toBe('https://fixture.test');
    expect(request.headers['x-title']).toBe('provider-contract-test');
    expect(request.headers.authorization).toBe('Bearer fixture-key');
  });

  it('flattens option spellings: later namespaces win, and top-level reasoning wins', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'success', protocol: 'chat-completions' });
    const model = await openRouterModel();
    const shared = {
      transforms: ['top'],
      shared: 'top',
      openrouter: { shared: 'namespaced', nestedOnly: 1, reasoning: { max_tokens: 100 } },
      providerOptions: {
        openrouter: { shared: 'nested', reasoning: { effort: 'low' } },
        anthropic: { ignored: true },
      },
    };
    await collect(
      model.stream({ ...requestFor(openRouterCase), providerOptions: shared, reasoning: { effort: 'high' } }),
    );
    const body = server.requests.at(-1)!.body as Record<string, any>;
    expect(body).toMatchObject({ transforms: ['top'], shared: 'nested', nestedOnly: 1, reasoning: { effort: 'low' } });
    expect(body).not.toHaveProperty('ignored');
    expect(body).not.toHaveProperty('anthropic');
    expect(body).not.toHaveProperty('openrouter');
    expect(body).not.toHaveProperty('providerOptions');

    await collect(
      model.stream({
        ...requestFor(openRouterCase),
        providerOptions: { ...shared, reasoning: { max_tokens: 50 } },
        reasoning: { effort: 'high' },
      }),
    );
    expect((server.requests.at(-1)!.body as Record<string, any>).reasoning).toEqual({ max_tokens: 50 });
  });

  it('sends tool_choice only alongside tools', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'success', protocol: 'chat-completions' });
    const model = await openRouterModel();
    await collect(model.stream({ ...requestFor(openRouterCase), tools: [], toolChoice: 'required' }));
    expect(server.requests.at(-1)!.body).not.toHaveProperty('tool_choice');
    await collect(model.stream({ ...requestFor(openRouterCase), toolChoice: 'none' }));
    expect(server.requests.at(-1)!.body).toMatchObject({ tool_choice: 'none', tools: [expect.any(Object)] });
  });

  it('reports the routed upstream provider and cost on OpenRouter completions only', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'upstream-provider', protocol: 'chat-completions' });
    const settings = createSettings(openRouterCase);
    const openRouterEvents = await collect((await openRouterModel(settings)).stream(requestFor(openRouterCase)));
    expect(openRouterEvents.at(-1)).toMatchObject({
      type: 'completion',
      costUsd: 0.0001,
      providerMetadata: { openrouter: { provider: 'CoreWeave' } },
    });

    const chatCase = { ...providerCases[1]!, runtimeType: 'openai-compatible' as const };
    registerRuntimeProvider(chatCase, createSettings(chatCase));
    const chatModel = await getProvider(chatCase.registryId)!.createStreamedModel!(chatCase.model, {
      settingsService: createSettings(chatCase),
      loggingService: quietLogging,
    });
    const chatEvents = await collect(chatModel.stream(requestFor(chatCase)));
    expect(chatEvents.at(-1)).toMatchObject({ type: 'completion' });
    expect(chatEvents.at(-1)).not.toHaveProperty('providerMetadata');
  });

  it('retains upstream error detail from error.metadata, skipping a null raw value', async () => {
    const cases = [
      {
        raw: { type: 'overloaded_error' },
        expected: 'Model is at capacity (upstream Anthropic: {"type":"overloaded_error"})',
      },
      { raw: 'slow down', expected: 'Model is at capacity (upstream Anthropic: slow down)' },
      { raw: null, expected: 'Model is at capacity (upstream Anthropic)' },
    ];
    for (const { raw, expected } of cases) {
      server = await startFakeProviderHttpServer({
        scenario: 'in-band-error',
        protocol: 'chat-completions',
        inBandError: { code: 502, message: 'Model is at capacity', metadata: { provider_name: 'Anthropic', raw } },
      });
      const model = await openRouterModel();
      const failure = await streamFailure(model.stream(requestFor(openRouterCase)));
      expect(failure).toMatchObject({ status: 502, message: expected });
      expect(server.requests).toHaveLength(1);
      await server.close();
      server = undefined;
    }
  });

  it('does not add OpenRouter upstream detail to other chat-completions providers', async () => {
    server = await startFakeProviderHttpServer({
      scenario: 'in-band-error',
      protocol: 'chat-completions',
      inBandError: { code: 502, message: 'Model is at capacity', metadata: { provider_name: 'Anthropic', raw: 'x' } },
    });
    const chatCase = { ...providerCases[1]!, runtimeType: 'openai-compatible' as const };
    registerRuntimeProvider(chatCase, createSettings(chatCase));
    const chatModel = await getProvider(chatCase.registryId)!.createStreamedModel!(chatCase.model, {
      settingsService: createSettings(chatCase),
      loggingService: quietLogging,
    });
    const failure = await streamFailure(chatModel.stream(requestFor(chatCase)));
    expect(failure.message).toBe('Model is at capacity');
  });

  it('settles a held-open in-band error without a traffic recorder', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'in-band-error-held-open', protocol: 'chat-completions' });
    const model = await openRouterModel();
    let timer: NodeJS.Timeout | undefined;
    // sleep-ok: absence of settlement (a regression hangs on the unread clone); the race ends as soon as the stream rejects, so 5 s only bounds the failing case and is far above a healthy in-band error's sub-second settle
    const outcome = await Promise.race([
      streamFailure(model.stream(requestFor(openRouterCase))),
      new Promise<'timed out'>((resolve) => {
        timer = setTimeout(() => resolve('timed out'), 5_000);
      }),
    ]);
    clearTimeout(timer);
    expect(outcome).not.toBe('timed out');
    expect(outcome).toMatchObject({
      message: 'Model is at capacity (upstream Anthropic: {"type":"overloaded_error"})',
    });
  });

  it('retains the in-band error frame in a recorded closed error stream', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'in-band-error', protocol: 'chat-completions' });
    const recorded: string[] = [];
    const providerTraffic = {
      recordRequestStart() {},
      async recordResponseReceived({ response }: { response: Response }) {
        recorded.push(await response.text());
      },
      recordResponseClosed() {},
      recordRequestFailed() {},
    };
    const model = await openRouterModel(createSettings(openRouterCase), {
      ...quietLogging,
      providerTraffic,
    } as unknown as ILoggingService);
    const failure = await streamFailure(model.stream(requestFor(openRouterCase)));
    expect(failure.message).toContain('Model is at capacity');
    await vi.waitFor(() => expect(recorded).toHaveLength(1));
    expect(recorded[0]).toContain('"Model is at capacity"');
  });

  it('replays OpenRouter reasoning_details with unsigned Gemini entries dropped and cache breakpoints on Claude', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'success', protocol: 'chat-completions' });
    const model = await openRouterModel(createSettings(openRouterCase), quietLogging, 'anthropic/claude-fixture');
    await collect(
      model.stream({
        ...requestFor(openRouterCase),
        providerOptions: {},
        input: [
          { type: 'message', role: 'user', content: [{ type: 'text', text: 'first' }] },
          { type: 'message', role: 'assistant', content: [{ type: 'text', text: 'answer' }] },
          {
            type: 'provider_opaque',
            provider: 'openrouter',
            item: {
              reasoning_details: [
                { type: 'reasoning.text', format: 'google-gemini-v1', index: 0, text: 'unsigned' },
                { type: 'reasoning.text', format: 'anthropic-claude-v1', index: 1, text: 'signed', signature: 'sig' },
              ],
            },
          },
          { type: 'message', role: 'user', content: [{ type: 'text', text: 'second' }] },
        ] as any,
      }),
    );
    const body = server.requests.at(-1)!.body as Record<string, any>;
    const assistant = body.messages.find((message: any) => message.role === 'assistant');
    expect(assistant.reasoning_details).toEqual([
      { type: 'reasoning.text', format: 'anthropic-claude-v1', index: 1, text: 'signed', signature: 'sig' },
    ]);
    expect(body.messages.at(-1).content.at(-1)).toMatchObject({
      text: 'second',
      cache_control: { type: 'ephemeral' },
    });
  });

  it('replays legacy reasoning as assistant text after a provider switch', async () => {
    server = await startFakeProviderHttpServer({ scenario: 'success', protocol: 'chat-completions' });
    const model = await openRouterModel();
    await collect(
      model.stream({
        ...requestFor(openRouterCase),
        providerOptions: {},
        input: [
          { type: 'message', role: 'user', content: [{ type: 'text', text: 'first' }] },
          { type: 'reasoning', text: 'legacy thought', providerMetadata: { anthropic: { signature: 'other' } } },
          { type: 'message', role: 'assistant', content: [{ type: 'text', text: 'answer' }] },
          { type: 'message', role: 'user', content: [{ type: 'text', text: 'second' }] },
        ] as any,
      }),
    );
    // Plain assistant text, merged into the same turn's answer as the SDK lane did.
    expect((server.requests.at(-1)!.body as Record<string, any>).messages).toContainEqual({
      role: 'assistant',
      content: [
        { type: 'text', text: 'legacy thought' },
        { type: 'text', text: 'answer' },
      ],
    });
  });
});

async function openRouterModel(
  settings: ISettingsService = createSettings(providerCases[4]!),
  loggingService: ILoggingService = quietLogging,
  model = 'fixture/provider',
) {
  return getProvider('openrouter')!.createStreamedModel!(model, { settingsService: settings, loggingService });
}

async function streamFailure(stream: AsyncIterable<unknown>): Promise<Error & { status?: number }> {
  try {
    await collect(stream);
  } catch (error) {
    return error as Error & { status?: number };
  }
  throw new Error('provider stream unexpectedly completed');
}

async function runProviderCase(providerCase: ProviderCase, scenario: 'success' | 'tool-fragments') {
  server = await startFakeProviderHttpServer({ scenario, protocol: providerCase.protocol });
  const settings = createSettings(providerCase);
  installOpenAiHttpRedirect(providerCase);
  registerRuntimeProvider(providerCase, settings);

  const provider = getProvider(providerCase.registryId);
  expect(provider?.createStreamedModel, providerCase.registryId).toBeTypeOf('function');
  const model = await provider!.createStreamedModel!(providerCase.model, {
    settingsService: settings,
    loggingService: quietLogging,
  });
  const events = await collect(model.stream(requestFor(providerCase)));

  expect(server.requests).toHaveLength(1);
  return { body: server.requests[0]!.body as Record<string, any>, events };
}

async function runProviderCaseExpectingError(providerCase: ProviderCase) {
  server = await startFakeProviderHttpServer({ scenario: 'error', protocol: providerCase.protocol });
  const settings = createSettings(providerCase);
  installOpenAiHttpRedirect(providerCase);
  registerRuntimeProvider(providerCase, settings);

  const provider = getProvider(providerCase.registryId);
  expect(provider?.createStreamedModel, providerCase.registryId).toBeTypeOf('function');
  const model = await provider!.createStreamedModel!(providerCase.model, {
    settingsService: settings,
    loggingService: quietLogging,
  });

  const events: unknown[] = [];
  let error: Error | undefined;
  try {
    for await (const event of model.stream(requestFor(providerCase))) events.push(event);
  } catch (caught) {
    error = caught instanceof Error ? caught : new Error(String(caught));
  }

  expect(server.requests).toHaveLength(1);
  return { error: error ?? new Error('provider stream unexpectedly completed'), events };
}

function requestFor(providerCase: ProviderCase) {
  return {
    ...fixtureRequest,
    input: multiTurnFixture,
    providerOptions: providerCase.providerOptions,
  };
}

function assertRequestShape(providerCase: ProviderCase, body: Record<string, any>) {
  if (providerCase.protocol !== 'google') expect(body.model).toBe(providerCase.model);
  expect(body.tools?.[0] ?? body.toolConfig?.functionCallingConfig).toBeDefined();

  if (providerCase.protocol === 'responses') {
    expect(body.input.filter((item: any) => item.type === 'message').map((item: any) => item.role)).toEqual(
      providerCase.expectedRoles,
    );
    expect(body.input).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ type: 'message', role: 'user' }),
        expect.objectContaining({ type: 'message', role: 'assistant' }),
      ]),
    );
    expect(body.tools[0]).toMatchObject({ name: fixtureTool.name, parameters: fixtureTool.parameters });
    expect(body.reasoning).toEqual({ effort: 'medium' });
    expect(body.prompt_cache_key).toBe('fixture-cache');
    expect(body.input.every((item: any) => item.type !== 'tool_call' && item.type !== 'tool_result')).toBe(true);
    return;
  }

  if (providerCase.protocol === 'chat-completions') {
    expect(body.messages.map((message: any) => message.role)).toEqual(providerCase.expectedRoles);
    expect(body.tools[0]).toMatchObject({ type: 'function', function: { name: fixtureTool.name } });
    if (providerCase.registryId === 'openrouter') {
      expect(body.transforms).toEqual(['middle-out']);
      expect(body.reasoning).toBeDefined();
    } else {
      expect(body.response_format).toEqual({ type: 'text' });
    }
    return;
  }

  if (providerCase.protocol === 'anthropic') {
    expect(body.messages.map((message: any) => message.role)).toEqual(providerCase.expectedRoles);
    expect(body.tools[0]).toMatchObject({ name: fixtureTool.name, input_schema: fixtureTool.parameters });
    expect(body.thinking).toEqual({ type: 'enabled', budget_tokens: 4096 });
    return;
  }

  expect(body.contents.map((message: any) => message.role)).toEqual(providerCase.expectedRoles);
  expect(body.tools[0].functionDeclarations[0]).toMatchObject({ name: fixtureTool.name });
  expect(body.generationConfig.thinkingConfig).toEqual({ thinkingBudget: 4096, includeThoughts: true });
  expect(body.safetySettings).toEqual([{ category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' }]);
}

function registerRuntimeProvider(providerCase: ProviderCase, settings: ISettingsService) {
  if (!providerCase.runtimeType) return;
  const definition: ProviderDefinition = createOpenAICompatibleProviderDefinition({
    name: providerCase.registryId,
    label: providerCase.name,
    type: providerCase.runtimeType,
    baseUrl: fixtureBaseUrl(providerCase),
    apiKey: 'fixture-key',
  });
  upsertProvider(definition);
  runtimeProviderIds.add(providerCase.registryId);
  expect(settings.getDynamic('providers')).toEqual(
    expect.arrayContaining([expect.objectContaining({ id: providerCase.registryId })]),
  );
}

function fixtureBaseUrl(providerCase: ProviderCase): string {
  const suffix =
    providerCase.basePath ??
    (providerCase.protocol === 'google' ? '/v1beta' : providerCase.runtimeType === 'opencode' ? '/zen/v1' : '');
  return `${server!.baseUrl}${suffix}`;
}

function createSettings(providerCase: ProviderCase): ISettingsService {
  const values: Record<string, unknown> = {
    'agent.modelSelection': { model: providerCase.model, provider: providerCase.registryId },
    'agent.retryAttempts': 0,
    'agent.transport': 'http',
    'agent.openai.apiKey': 'fixture-key',
    'agent.openrouter.apiKey': 'fixture-key',
    'agent.openrouter.baseUrl': server?.baseUrl,
    'agent.openrouter.referrer': 'https://fixture.test',
    'agent.openrouter.title': 'provider-contract-test',
  };
  const providers = providerCase.runtimeType
    ? [
        {
          id: providerCase.registryId,
          name: providerCase.name,
          type: providerCase.runtimeType,
          baseUrl: fixtureBaseUrl(providerCase),
          apiKey: 'fixture-key',
        },
      ]
    : [];
  return {
    get: (key: string) => values[key] as never,
    getDynamic: (key: string) => (key === 'providers' ? providers : undefined),
    set() {},
    setDynamic() {},
    setPersistent() {},
    setPersistentDynamic() {},
  } as ISettingsService;
}

const quietLogging: ILoggingService = {
  info() {},
  warn() {},
  error() {},
  debug() {},
  security() {},
  setCorrelationId() {},
  getCorrelationId() {
    return undefined;
  },
  clearCorrelationId() {},
};

function installOpenAiHttpRedirect(providerCase: ProviderCase) {
  if (providerCase.registryId !== 'openai') return;
  const nativeFetch = globalThis.fetch;
  vi.stubGlobal('fetch', (input: RequestInfo | URL, init?: RequestInit) => {
    const originalUrl = input instanceof URL ? input : new URL(String(input));
    const targetUrl = new URL(`${originalUrl.pathname}${originalUrl.search}`, server!.baseUrl);
    return nativeFetch(targetUrl, init);
  });
}

async function collect<T>(stream: AsyncIterable<T>): Promise<T[]> {
  const events: T[] = [];
  for await (const event of stream) events.push(event);
  return events;
}
