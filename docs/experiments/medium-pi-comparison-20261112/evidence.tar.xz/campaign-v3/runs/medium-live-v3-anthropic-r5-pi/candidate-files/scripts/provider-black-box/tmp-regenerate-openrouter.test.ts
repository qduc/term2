// TEMPORARY (untracked): regenerates request frames for openrouter/tool-continuation-v1.json
// from the migrated adapter's actual wire output. Response frames are not touched.
import { it, expect } from 'vitest';
import { writeFile, readFile } from 'node:fs/promises';
import '../../src/model/providers/index.js';
import { getProvider } from '../../src/model/providers/registry.js';
import { startFakeProviderHttpServer } from './fake-provider-http-server.js';
import { readFixtureEnvelope } from './fixture-envelope.js';
import { fixtureRequest, fixtureTool } from './provider-wire-fixtures.js';

const FIXTURE = new URL('./fixtures/openrouter/tool-continuation-v1.json', import.meta.url).pathname;
const OUT = process.env.REGEN_OUT ?? '/tmp/openrouter-regen.json';

it('regenerates request frames', async () => {
  const raw = JSON.parse(await readFile(FIXTURE, 'utf8'));
  const fixture = await readFixtureEnvelope(FIXTURE);
  const server = await startFakeProviderHttpServer({ fixture });
  try {
    const values: Record<string, unknown> = {
      'agent.modelSelection': { model: 'openai/gpt-oss-20b', provider: 'openrouter' },
      'agent.retryAttempts': 0,
      'agent.openrouter.apiKey': 'fixture-key',
      'agent.openrouter.baseUrl': `${server.baseUrl}/api/v1`,
      'agent.openrouter.referrer': 'https://github.com/qduc/term2',
      'agent.openrouter.title': 'term2',
    };
    const settings = {
      get: (key: string) => values[key] as never,
      getDynamic: () => undefined,
      set() {},
      setDynamic() {},
      setPersistent() {},
      setPersistentDynamic() {},
    } as any;
    const logging = {
      info() {},
      warn() {},
      error() {},
      debug() {},
      security() {},
      setCorrelationId() {},
      getCorrelationId() {
        return undefined;
      },
      clearCorrelationId() {},
    } as any;
    const model = await getProvider('openrouter')!.createStreamedModel!('openai/gpt-oss-20b', {
      settingsService: settings,
      loggingService: logging,
    });
    const collect = async (stream: AsyncIterable<any>) => {
      const out: any[] = [];
      for await (const e of stream) out.push(e);
      return out;
    };
    const initial = {
      ...fixtureRequest,
      reasoning: { effort: 'default' },
      input: [
        { type: 'message', role: 'user', content: [{ type: 'text', text: 'Use the fixture tool and then summarize its result.' }] },
      ],
    } as any;
    const first = await collect(model.stream(initial));
    const call =
      (first.find((e: any) => e.type === 'tool_call') as any) ??
      first.flatMap((e: any) => e.output ?? []).find((i: any) => i.type === 'tool_call');
    expect(call).toMatchObject({ name: fixtureTool.name });
    const continuation = {
      ...initial,
      input: [
        ...initial.input,
        { type: 'tool_call', id: call.id, name: call.name, arguments: call.arguments },
        { type: 'tool_result', id: call.id, output: JSON.stringify({ ok: true, value: 1 }) },
        {
          type: 'message',
          role: 'user',
          content: [{ type: 'text', text: 'The fixture tool returned its deterministic result. Give the final summary.' }],
        },
      ],
    } as any;
    await collect(model.stream(continuation));
    expect(server.requests).toHaveLength(2);

    // Map raw response ids back to the fixture's placeholders so the stored frames stay sanitized.
    const placeholders: Record<string, string> = raw.placeholders;
    const toPlaceholders = (text: string) => {
      let out = text;
      for (const [rawId, placeholder] of Object.entries(placeholders)) out = out.split(rawId).join(placeholder);
      return out;
    };
    const turns = raw.turns.filter((t: any) => t.frames.some((f: any) => f.kind === 'http-request'));
    turns.forEach((turn: any, i: number) => {
      const actual = server.requests[i]!;
      const frame = turn.frames.find((f: any) => f.kind === 'http-request');
      const body = JSON.parse(toPlaceholders(JSON.stringify(actual.body)));
      const headers: Record<string, string> = {
        authorization: '[REDACTED]',
        'content-type': String(actual.headers['content-type']),
        'http-referer': String(actual.headers['http-referer']),
        'x-title': String(actual.headers['x-title']),
      };
      frame.headers = headers;
      frame.body = body;
      frame.method = actual.method;
      frame.urlPath = actual.url;
    });
    await writeFile(OUT, `${JSON.stringify(raw, null, 2)}\n`, 'utf8');
    console.log('WROTE', OUT, 'failures:', server.comparisonFailures.length);
  } finally {
    await server.close();
  }
}, 60_000);
