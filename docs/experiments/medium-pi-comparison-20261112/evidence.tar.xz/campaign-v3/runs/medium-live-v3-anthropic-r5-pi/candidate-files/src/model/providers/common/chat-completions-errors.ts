import { OpenAICompatibleError } from './provider-errors.js';

/**
 * Normalizes an in-band chat-completions error object (an `error` frame, or an
 * error carried on a `finish_reason: "error"` choice) into the error the retry
 * policy classifies by status.
 *
 * `errorDetailOf` lets a gateway add its own upstream detail to the message
 * without changing the status mapping; ordinary providers pass nothing.
 */
export function normalizeChatCompletionError(
  error: unknown,
  errorDetailOf?: (error: unknown) => string | undefined,
): OpenAICompatibleError {
  const record = isRecord(error) ? error : undefined;
  const nested = record && isRecord(record.error) ? record.error : undefined;
  const code = record?.code ?? record?.status ?? record?.statusCode ?? nested?.code ?? nested?.status;
  const numericStatus =
    typeof code === 'number' && Number.isInteger(code)
      ? code
      : typeof code === 'string' && /^\d+$/.test(code.trim())
      ? Number(code)
      : undefined;
  const symbolicCode = typeof code === 'string' ? code.toLowerCase() : '';
  const status =
    numericStatus ??
    (symbolicCode.includes('rate_limit') || symbolicCode.includes('too_many_requests')
      ? 429
      : symbolicCode.includes('invalid')
      ? 400
      : symbolicCode.includes('auth')
      ? 401
      : symbolicCode.includes('permission')
      ? 403
      : symbolicCode.includes('not_found')
      ? 404
      : 502);
  const baseMessage =
    (typeof record?.message === 'string' && record.message) ||
    (typeof nested?.message === 'string' && nested.message) ||
    (typeof error === 'string' ? error : 'OpenAI-compatible provider returned an in-band error');
  const detail = errorDetailOf?.(error);
  const message = detail ? `${baseMessage} (${detail})` : baseMessage;
  let responseBody: string | undefined;
  try {
    responseBody = JSON.stringify(error);
  } catch {
    responseBody = undefined;
  }
  return new OpenAICompatibleError(message, status, {}, responseBody);
}

/**
 * The OpenAI SDK parses an in-band `error` frame itself and throws it as an
 * `APIError` with no HTTP status and the frame's payload on `.error`, before the
 * chat adapter sees the chunk. Re-raise that throw as the adapter's own error so
 * the status and gateway detail survive. Other throws pass through unchanged, and
 * cancellation still reaches the SDK through `return()`.
 */
export async function* normalizeSdkInBandErrors<T>(
  stream: AsyncIterable<T>,
  errorDetailOf?: (error: unknown) => string | undefined,
): AsyncGenerator<T> {
  try {
    yield* stream;
  } catch (error) {
    if (isRecord(error) && error.status === undefined && error.error != null) {
      throw normalizeChatCompletionError(error.error, errorDetailOf);
    }
    throw error;
  }
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);
