import type { ChatCompletionsDialect } from './openai-chat-completions-model.js';
import type { StreamedModelProviderOptions, StreamedModelTurnRequest } from '../streamed-model-turn.js';

/**
 * OpenRouter's conventions on the shared chat-completions wire.
 *
 * The shared adapter sends `reasoning_effort` and `tool_choice` unconditionally,
 * and reports no upstream provider. OpenRouter instead takes `reasoning: { effort }`,
 * accepts provider options at three levels, and names the routed upstream provider
 * on every chunk. Those rules live here so the shared adapter stays vendor-neutral.
 */

type Options = Record<string, unknown>;

/** Option keys that wrap other options; they are never body fields. */
const WRAPPER_KEYS = new Set(['openrouter', 'providerOptions', 'reasoning']);
const MAX_RAW_DETAIL_LENGTH = 500;

const isRecord = (value: unknown): value is Options =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

/**
 * Flattens the three spellings of OpenRouter options into one body: top-level
 * fields, then `openrouter`, then `providerOptions.openrouter`, so later namespaced
 * values win. Reasoning is resolved separately: an explicit top-level `reasoning`
 * wins over any namespaced reasoning.
 */
function flattenOpenRouterOptions(providerOptions: StreamedModelProviderOptions | undefined): {
  body: Options;
  reasoning: unknown;
} {
  const source: Options = { ...(providerOptions ?? {}) };
  const nested = isRecord(source.providerOptions) ? source.providerOptions : {};
  const { reasoning: namespacedReasoning, ...namespacedBody } = {
    ...(isRecord(source.openrouter) ? source.openrouter : {}),
    ...(isRecord(nested.openrouter) ? nested.openrouter : {}),
  };
  const topLevelBody = Object.fromEntries(Object.entries(source).filter(([key]) => !WRAPPER_KEYS.has(key)));
  return {
    body: { ...topLevelBody, ...namespacedBody },
    reasoning: source.reasoning ?? namespacedReasoning,
  };
}

/**
 * Translates the application request into OpenRouter's body shape. An explicit
 * reasoning option replaces the selected effort; otherwise a non-default effort
 * becomes `reasoning: { effort }`. `tool_choice` is sent only alongside tools.
 */
function prepareOpenRouterRequest(request: StreamedModelTurnRequest): StreamedModelTurnRequest {
  const { reasoning: _selectedEffort, toolChoice, ...rest } = request;
  const { body, reasoning: explicitReasoning } = flattenOpenRouterOptions(request.providerOptions);
  const effort = request.reasoning?.effort;
  const reasoning = explicitReasoning ?? (effort && effort !== 'default' ? { effort } : undefined);
  return {
    ...rest,
    ...(toolChoice !== undefined && request.tools.length ? { toolChoice } : {}),
    providerOptions: { ...body, ...(reasoning != null ? { reasoning } : {}) },
  };
}

/** The upstream provider OpenRouter reports on a streamed chunk, when present. */
function upstreamProviderOf(chunk: unknown): string | undefined {
  const provider = isRecord(chunk) && typeof chunk.provider === 'string' ? chunk.provider.trim() : '';
  return provider || undefined;
}

/**
 * Upstream routing detail from `error.metadata`: the provider OpenRouter routed
 * to and its raw error (a string, or a JSON object). A null or absent `raw`
 * contributes nothing rather than the word "null".
 */
function openRouterErrorDetail(error: unknown): string | undefined {
  const metadata = isRecord(error) && isRecord(error.metadata) ? error.metadata : undefined;
  const provider = typeof metadata?.provider_name === 'string' ? metadata.provider_name.trim() : '';
  const raw = rawErrorDetail(metadata?.raw);
  if (!provider && !raw) return undefined;
  return [provider ? `upstream ${provider}` : '', raw].filter(Boolean).join(': ');
}

function rawErrorDetail(raw: unknown): string {
  const text =
    typeof raw === 'string' ? raw.trim() : typeof raw === 'object' && raw !== null ? JSON.stringify(raw) : '';
  return text.length > MAX_RAW_DETAIL_LENGTH ? `${text.slice(0, MAX_RAW_DETAIL_LENGTH)}…` : text;
}

/** The chat-completions dialect for the built-in OpenRouter provider. */
export const openRouterChatDialect: ChatCompletionsDialect = {
  prepareRequest: prepareOpenRouterRequest,
  upstreamProviderOf,
  completionMetadata: (upstreamProvider) => ({ openrouter: { provider: upstreamProvider } }),
  errorDetailOf: openRouterErrorDetail,
};
