/**
 * Accumulates unmodeled Chat Completions delta fields for exact continuation replay.
 * String deltas concatenate; indexed arrays merge fragments into their logical entries,
 * preserving complete reasoning_details records instead of replaying fragments separately.
 */
export function accumulateChatCompletionContinuityField(
  target: Record<string, unknown>,
  key: string,
  value: unknown,
): void {
  if (typeof value === 'string') {
    const existing = typeof target[key] === 'string' ? (target[key] as string) : '';
    target[key] = existing + value;
    return;
  }
  if (Array.isArray(value)) {
    const existing = Array.isArray(target[key]) ? (target[key] as unknown[]) : [];
    target[key] = mergeIndexedEntries(existing, value);
    return;
  }
  target[key] = value;
}

function mergeIndexedEntries(existing: unknown[], incoming: unknown[]): unknown[] {
  const result = [...existing];
  for (const entry of incoming) {
    const index = isRecord(entry) ? entry.index : undefined;
    const matchAt =
      typeof index === 'number'
        ? result.findIndex((candidate) => isRecord(candidate) && candidate.index === index)
        : -1;
    if (matchAt === -1) {
      result.push(isRecord(entry) ? { ...entry } : entry);
      continue;
    }
    result[matchAt] = mergeEntryFields(result[matchAt] as Record<string, unknown>, entry as Record<string, unknown>);
  }
  return result;
}

/** Merge payload fragments while retaining the repeated entry descriptors. */
function mergeEntryFields(base: Record<string, unknown>, incoming: Record<string, unknown>): Record<string, unknown> {
  const merged = { ...base };
  for (const [key, value] of Object.entries(incoming)) {
    if (typeof value === 'string' && typeof merged[key] === 'string' && merged[key] !== value) {
      merged[key] = (merged[key] as string) + value;
      continue;
    }
    merged[key] = value;
  }
  return merged;
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);
