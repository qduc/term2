# Built-in OpenRouter provider

`src/model/providers/openrouter.provider.ts` registers the `openrouter` built-in
and constructs the application-owned `OpenAIChatCompletionsModel` against
`https://openrouter.ai/api/v1` (or `agent.openrouter.baseUrl`). Credentials come
from `agent.openrouter.apiKey` or `OPENROUTER_API_KEY`. The configured referrer
and title are sent as `HTTP-Referer` and `X-Title` headers.

The adapter keeps OpenRouter-specific behavior at this provider boundary:
request preprocessing sanitizes signed reasoning details and applies Anthropic
cache breakpoints; provider options are flattened for the OpenRouter wire;
selected reasoning effort is sent as `reasoning: { effort }`, unless an explicit
reasoning option overrides it. Streamed upstream provider names are exposed as
completion metadata under `openrouter.provider_name`. Other Chat Completions
providers do not receive this metadata behavior.

The shared adapter owns chat message conversion, streaming text/reasoning,
reasoning-details continuity, tool calls and replay, usage/cost extraction,
in-band errors, and request cancellation. `RetryingModel` remains the retry
owner; the OpenAI transport client is configured with retries disabled.
Provider-boundary integration coverage is in
`scripts/provider-black-box/provider-contract.test.ts` and uses loopback fixtures,
not live OpenRouter requests.
