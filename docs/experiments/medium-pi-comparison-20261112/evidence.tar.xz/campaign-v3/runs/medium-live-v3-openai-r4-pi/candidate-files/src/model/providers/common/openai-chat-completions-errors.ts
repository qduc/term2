import { OpenAICompatibleError } from './provider-errors.js';

/** Normalize in-band OpenAI-compatible errors while retaining gateway diagnostics. */
export function normalizeChatCompletionError(error: unknown): OpenAICompatibleError {
  const record = isRecord(error) ? error : undefined;
  const nested = record && isRecord(record.error) ? record.error : undefined;
  const code = record?.code ?? record?.status ?? record?.statusCode ?? nested?.code ?? nested?.status;
  const numericStatus =
    typeof code === 'number' && Number.isInteger(code)
      ? code
      : typeof code === 'string' && /^\d+$/.test(code.trim())
      ? Number(code)
      : undefined;
  const symbolicCode = typeof code === 'string' ? code.toLowerCase() : '';
  const status =
    numericStatus ??
    (symbolicCode.includes('rate_limit') || symbolicCode.includes('too_many_requests')
      ? 429
      : symbolicCode.includes('invalid')
      ? 400
      : symbolicCode.includes('auth')
      ? 401
      : symbolicCode.includes('permission')
      ? 403
      : symbolicCode.includes('not_found')
      ? 404
      : 502);
  const metadata =
    (record && isRecord(record.metadata) ? record.metadata : undefined) ??
    (nested && isRecord(nested.metadata) ? nested.metadata : undefined);
  const raw = metadata?.raw;
  const rawDetail = typeof raw === 'string' ? raw : raw != null ? safeJson(raw) : undefined;
  const upstream = nonEmptyString(metadata?.provider_name);
  const messageBase =
    (typeof record?.message === 'string' && record.message) ||
    (typeof nested?.message === 'string' && nested.message) ||
    (typeof error === 'string' ? error : 'OpenAI-compatible provider returned an in-band error');
  const message = `${messageBase}${upstream ? ` (upstream: ${upstream})` : ''}${rawDetail ? `: ${rawDetail}` : ''}`;
  return new OpenAICompatibleError(message, status, {}, rawDetail ?? safeJson(error));
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function safeJson(value: unknown): string | undefined {
  try {
    return JSON.stringify(value);
  } catch {
    return undefined;
  }
}

function nonEmptyString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}
