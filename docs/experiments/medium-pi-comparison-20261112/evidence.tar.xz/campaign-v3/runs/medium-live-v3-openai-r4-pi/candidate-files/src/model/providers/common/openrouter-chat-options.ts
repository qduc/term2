import type { StreamedModelTurnRequest } from '../../streamed-model-turn.js';

/** Flatten OpenRouter's direct and wrapped option namespaces into wire fields. */
export function openRouterRequestOptions(request: StreamedModelTurnRequest): Record<string, unknown> {
  const options = request.providerOptions ?? {};
  const direct = isRecord(options) ? options : {};
  const namespaced = isRecord(direct.openrouter) ? direct.openrouter : {};
  const wrapped = isRecord(direct.providerOptions) ? direct.providerOptions : {};
  const wrappedNamespaced = isRecord(wrapped.openrouter) ? wrapped.openrouter : {};
  const flattened = { ...direct, ...namespaced, ...wrappedNamespaced };
  delete flattened.openrouter;
  delete flattened.providerOptions;
  const explicitReasoning =
    direct.reasoning !== undefined
      ? direct.reasoning
      : namespaced.reasoning !== undefined
      ? namespaced.reasoning
      : wrappedNamespaced.reasoning;
  if (explicitReasoning !== undefined) flattened.reasoning = explicitReasoning;
  else if (request.reasoning?.effort && request.reasoning.effort !== 'default') {
    flattened.reasoning = { effort: request.reasoning.effort };
  }
  return flattened;
}

export function nonEmptyString(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
