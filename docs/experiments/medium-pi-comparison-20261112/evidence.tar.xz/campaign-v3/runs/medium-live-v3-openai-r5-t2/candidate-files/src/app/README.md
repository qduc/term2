# Direct app interfaces

This directory wires concrete source services into the native Session. It does
not own provider advancement, task lifecycle, or accepted history. The following
contracts cover its settings and executable tool assembly boundaries.

## Settings and runtime generations

`ProfileSelection` in `tool-contract.ts` carries the model registry dependencies
and a concrete `LoggingService`. The app also passes that logger to the source
`SettingsService`, which configures it; the model registry's narrower
`ILoggingService` contract alone is not sufficient for app assembly.

The direct CLI's headless, interactive, model-listing and shared ACP/server
bootstrap paths let `SettingsService` own logger construction, passing
`loggingServiceOptions` for session context and retrieving the same logger via
`getLoggingService()`. Settings loading uses a silent bootstrap logger until
the validated, merged `logging.disableLogging` policy is known. An explicit
disable option or `DISABLE_LOGGING=true` still disables capture even if the
stored setting is false. Do not construct and inject an enabled logger before
settings load: its file transport creates files immediately, and its provider
traffic store fixes its enabled state at construction. Session runtime bindings
may reuse the already-resolved logger; canonical conversation persistence is
separate and remains enabled. This is startup policy, not a runtime toggle.

`createSettingsService` (`settings.ts`) constructs the concrete
`SettingsService`. The settings owner retains its directory, logger,
and persistence policies.

`createDirectRuntimes` in `application-runtime.ts` builds session-owned
settings and tool generations. `approvalAlwaysAsks` pins the session's saved
shell auto-approval mode to `off`; `requireSandbox` pins `sandbox.enabled:true`
after restoring session configuration. ACP sets both options. These overrides
are in-memory policy and do not rewrite user preferences. ACP v1 can select
another approval mode through the app's idle configuration scope. It rebuilds
the session's policy and sandbox settings together. The choice stays in the
live runtime. In Ask and Assisted, a local foreground shell receives its
invocation-scoped escape capability only after the distinct one-time grant.
`persistSessionConfiguration:false` also keeps native configuration changes
session-local; ACP opts out while the terminal UI retains saved defaults. The
native generation's install step records settings through `SessionSettingsService`,
whose ordinary writes save through to the global owner. A client-side promise
of session-local selection therefore requires this opt-out at the install step,
not merely an isolated settings snapshot or unchanged initial launch settings.
`createDirectConfigSettings` in `config-settings.ts` produces a read-only, source-schema-validated settings
snapshot; it does not persist selection changes. Its
`prepareDirectSessionConfigurationCommand` validates HTTP selection intent,
retains request identity and expected revision, and rejects unknown or empty
mutations. Reasoning effort has three validators, each reading a source-owned
list rather than its own copy: HTTP configuration uses the output object of the
source agent settings preprocess schema, while the `--reasoning` flag
(`cli.ts`) and the TUI's `/effort` command (`launch-tui-commands.ts`)
check against `VALID_REASONING_EFFORTS`.

`DirectGlobalConfiguration` in `host-config-settings.ts` implements the
host's public `SettingsProjection` rather than maintaining another projection
type. Reads redact values through `safeValue`; writes enforce the allowlist,
revision, and persistence result before returning a new projection. The public
value union is not permission to serialize arbitrary settings objects.

`createDirectTuiSettings` in `launch-tui-settings.ts` acknowledges hidden profile
compatibility aliases without switching or clearing history. Dropped/unknown
selections remain errors. Its `/auto-approve` and `/sandbox` commands save the applied
preference through `DirectApplication.saveApprovalPreference`, using the global
settings owner for targeted file updates rather than persisting session model or
profile overrides. A rejected rebuild does not save; an uncertain rebuild does
not claim success. A failed file write leaves the applied session value visible
and reports that saving failed. Other direct TUI setting changes remain
session-only. The sandbox preference is retained configuration, not a claim of
direct sandbox execution support. Restart still explicitly carries the live
approval/sandbox values in its exec environment.
Interactive startup enables the source settings owner's ordinary file creation,
recovery and schema/default migrations as well as explicit preference saves.
CLI profile/model/reasoning overrides still opt out of persistence. Headless,
ACP and serve startup persistence policy is unchanged.

On CLI resume or fork, resolved explicit model/provider and reasoning flags are
passed separately from launch defaults. `applyLaunchConfiguration` opens the target
and submits a native idle-only configure command before the client connects.
The accepted selection is durable in that session (only the copied session for a
fork). `launch-configuration.ts` scopes launcher authority to this application's
exact session and selected model, then restores ordinary model authorization. It
keeps the runtime's settings writes out of the global defaults; ordinary interactive
configuration still saves normally. No explicit fields, or model/effort fields
equal to restored selection intent, means no configure command. This keeps restart replay byte-identical; reasoning
intent equality is distinct from equality of its model-resolved effective value.
Explicit reasoning wins over a model suffix, which wins over saved reasoning;
a model-only override retains the saved reasoning intent. Ordinary resume retains
the accepted effective request, including cold-catalog reasoning and temperature.

`cli.ts` is the process entrypoint: the Discord bridge's numeric
or numeric-string `process.exitCode` is normalized to the numeric `main` result.

`startDirectHooks` owns one public root lifecycle per app, not per durable native
leaf. First attachment starts it (including an empty resumed leaf); `/clear`,
session switching and client disconnects do not end it. App shutdown drains the
host before emitting the single root end and closing the shared hook runner.
Session observers still retain their native turn/tool correlation; they cannot
close the shared runner. This preserves the root lifecycle contract used by
Herdr registration without treating a new native leaf as a new process.

## Interactive startup admission

For a fresh CLI launch with `--goal`, an otherwise admitted interactive start
must persist its native `session_started` and launcher `goal_changed` facts before
refusing a missing terminal. `cli.ts` retains its earlier argument, resume and
home-directory refusals; those are not admitted starts. `runTui` uses the same
Session creation and `setGoal` path as terminal launches, then checks terminal
availability before reading the background colour answer, control sockets or Ink.
The colour query itself goes out earlier: `launch.ts` runs `launch-tui-terminal.ts`
(home-directory confirmation, then the query) before the TUI's modules load, so
the reply, or the timeout of a terminal that never answers, overlaps startup.
Without a TTY no query is sent. `launchTui` does not open MCP for a non-TTY start.
A no-goal CLI terminal refusal still creates no conversation. Do not restore an
early unconditional terminal return in `cli.ts`: it silently loses the
user-authored goal.

## Startup loading

`dist/src/app/cli.js` is a loader (`scripts/bundle-loader.mjs`) for one esbuild
bundle beside it, `cli.bundle.cjs` (`scripts/bundle-entry.mjs`). Every package
left external, and every builtin, that the bundle's top level requires is loaded
before any term2 code runs, whichever command was given; bundled modules
initialize when their importer does. So a package needed only by one mode
or on demand is imported where it is used: `ssh2` (`SSHService`), the sandbox
  runtime (`shell-sandbox-runner.ts`), the MCP SDK (`tools/mcp/mcp-sdk.ts`), and
  `@qduc/web-fetch`. That last one is external: its jsdom stays
out of the bundle and finds its own worker file, which it could not do when it
was bundled. `launch.ts` loads each launcher, the headless one included, only for its
mode. Until 2026-11-07 they were static imports, paid on every start; see
[the measurements](../../docs/plans/engineering/measurements/test-suite-speed-2026-10-22.md#cli-cold-start-2026-11-07).
`dist/cli.js`, the installed `term2`, enables Node's compile cache in term2's cache
directory before importing the loader.

Node's compile cache keeps only the code V8 compiled when it first compiled a
file, so a bundle loaded through it recompiled every lazily compiled function
(module initializers, Ink, React, the first frame) on each start. The loader
compiles the bundle with `vm.Script` instead, and writes the script's V8 code
cache to `term2-bundle/` inside whatever compile cache directory Node reports.
It writes the cache 2 s after start as `<bundle>.settled`, which covers an idle
TUI, or at exit as `<bundle>.exit` when a short run (`--help`, a headless run)
found no usable cache. A settled cache is never rewritten. V8 checks only a
cache's header and the length of its source, so the file name holds the bundle's
size and CRC32, and each file starts with a CRC32 of its data, checked before V8
sees it. Without that check, a cache damaged past its header crashed V8 (exit 133)
on every start, and a same-length bundle could run another's bytecode. A cache
that fails either check, or that V8 rejects, is deleted. Without a compile cache
directory (`NODE_DISABLE_COMPILE_CACHE`, no `NODE_COMPILE_CACHE` when launched
directly), or on a Node without `module.getCompileCacheDir`, the vm loader
constant or `zlib.crc32`, the bundle is `require()`d as an ordinary CommonJS
module. Dynamic `import()` from the script goes through
`vm.constants.USE_MAIN_CONTEXT_DEFAULT_LOADER`; the loader takes the first such
import itself, so Node's one-time ExperimentalWarning for that constant is
dropped and never reaches the terminal.

The bundle pins `react`, `react-reconciler` and `scheduler` to their
production builds. They used to pick a build from `NODE_ENV` at runtime, so the
test suites (`NODE_ENV=test`) ran React's development build, which users do not
run.

## Native CLI conversation discovery

`cli-conversations.ts` lists existing native logical lineages through the shared
[derived catalogue](../session/native-catalogue.md), without opening a
writable Session or creating a runtime. `--resume ls` and `--resume list` show the
last ten matching conversations. `--resume last` and bare `--resume` select the
matching lineage with the newest accepted fact timestamp (not copied-file mtime),
with logical ID as the deterministic tie-breaker. Rotated physical logs list once.
Discovery filters local paths and SSH endpoint identities before selection; the
store/runtime still enforce the current workspace grant on writable open.

Exact native IDs and lowercase raw UUID aliases are resolved before the non-TTY
follow-up-prompt check, so missing
and foreign-project references report their real diagnostic. Model labels
use the latest accepted configuration where present. Goal/profile restoration is
still Session/runtime-owned: discovery neither rewrites facts nor substitutes
launcher defaults. A resumed generation restores accepted effective reasoning and
temperature independently of selection intent; same-model graph refreshes and
rollovers retain those effective values, including an absent temperature. A
model, profile, or explicit setting change can resolve a new effective request.
This matters when model discovery is cold: recalculating from local settings can
otherwise silently change a resumed request. No native log-format changes, legacy log reads, or migration
fallback are part of this boundary. A raw exact UUID normalizes to `conv_<uuid>`,
the standalone migrator's deterministic ID; it succeeds only when that native log
exists and matches the current workspace. Partial, uppercase and otherwise
noncanonical IDs do not alias. Discovery does not read the private provenance map
or old store. Listings count current visible native user messages, deduplicate
observed/derived display by message ID, and do not count hidden restoration input.
They omit text previews so warm listing needs metadata rather than log replay.

`DirectApplication.sessionAccount(sessionId, providerId)` reads the attached
session's current root Model registry. TUI account lists and removal warnings use
that getter, so selecting another stored account does not relabel a registry that
still authenticates with its original pin. Configured generations install their
account getter with the rest of their runtime and retain the logical session's
authentication pin store. Advisory registries share that pin while keeping their
history and cache identity separate. The application owns a credential refresh
coordinator shared across those session stores: sessions sharing a credential file
serialize refreshes and reread their own pinned account inside that queue. Failed
refreshes release the queue so later requests can retry. Independent application
instances/processes require coordination at their shared credential-store owner.

`cli-account-commands.ts` owns global account/catalog ports as well as login and model-catalog subcommands, including
source OAuth prompts and catalogue diagnostics. They do not open a conversation;
`cli.ts` retains process startup, mode selection and signal ownership.

Dropped workflow profiles (Plan, Pair, Mentor, Orchestrator; #149) cannot be selected
through CLI, TUI, native configure, or HTTP. Saved settings and session metadata
fall back to Bare at runtime, without rewriting historical facts or the settings
file. CLI help hides profile inputs; Bare/Standard/Full/Lite aliases remain parseable for compatibility. The direct
tool surface keeps root goal checks but no longer installs goal proposal or
startup workflow notices. On restore, the store expects the identity the runtime
will install: current Bare for these retired profiles, and the current version and
digest for any other built-in, whose prompt edits change its digest between
releases. A stored profile that does not resolve keeps exact validation, as do the
reasoning and temperature checks.
Generic request notices remain supported; retry only reapplies a saved notice
when its original mode matches the current mode, so dropped workflows stay off.

## Tools and delegation

`src/delegation/direct/subagent-tools.ts` owns child preparation, invocation scope and
prepared Session launch authority. Its injected app ports adapt physical tool
contexts, local execution contexts and source registries. Session retains durable
admission and billing remains app-owned. Delegation's `subagent-callbacks.ts` adapts source delegation
callbacks and projects accepted task status/results with actual execution evidence;
it does not introduce a task lifecycle registry or grant child authority.

Local surfaces use the native `LocalExecutionContext` in `tool-contract.ts` for a home/lease, retained
across configured generations. Worktree tools use the existing git inventory and
running-shell guards; `enter`/`exit` never publish a process-wide root. Native
source-tool contexts read that lease for each execution. Child tool graphs
snapshot the current root at admission so a later parent switch cannot retarget
a running child. Bare, read-only, and SSH surfaces do not offer local worktree tools.
The source context stays frozen; native leases must not alter its old-CLI behavior.
Legacy command-safety helpers that default to the process-global root do not
follow these local leases: sibling-worktree reads can require extra approval.
Sandbox configuration and file tools receive the explicit execution root; do not
restore global publication to avoid those extra prompts.

`lib/agent-model-settings.ts` owns provider capability resolution and the
model-facing request settings built from a settings snapshot: output allocation,
retry/stream limits, explicit reasoning/temperature, flex tier and compaction.
`lib/agent-factory.ts` keeps agent/tool graph assembly and invocation wrapping.

`createApprovalModelClient` in `lib/approval-model.ts` bridges the existing
approval evaluator to one tool-free model request. It retains the surface's
cancellation signal and explicit affinity, accepts only a completed model turn,
and prefers completed assistant text over streamed deltas.

`createToolSurface` in `tool-surface.ts` builds the offered tools and matching
execution and approval capabilities together. Source tool and headless approval callbacks
run with their local session’s current workspace root scoped to that async call;
concurrent sessions never retarget the legacy process-wide root. It keeps a mutable copy of the
source's readonly graph for native capability replacement; the source still
owns its original graph. Replacement rebinds the script registry. Memory leaves are adapted into that script graph before the shared source
`isDirectlyCallable` predicate filters their top-level presentation when the
actual surface offers `run_code`; otherwise the leaves remain directly callable. The source
tool spec keeps `description` live: `run_code` binds its catalog after initial
surface assembly, and a copied string silently omits native memory leaves.
`config-memory.ts` re-adapts the captured leaves on configuration even
when none is top-level. Late source-leaf adaptation retains the raw approval
policy and interceptors registered by `buildAgentTools`; it must not re-register
the wrapped `needsApproval` interrupt marker as the authorization predicate.
Bare suppresses inline memory guidance without changing
access, personal-context opt-in, snapshots, or the local-only store boundary.
When Session owns memory tools/context, `promptMemoryEnabled` builds a
description-only source capability with a marker in the prompt. Source memory
tools remain absent and no second store read occurs; Session substitutes its one
accepted guidance/global-context snapshot at `planDirectInstructions`, so a
populated index and the empty-index wording are both resolved from the real
snapshot rather than guessed.
MCP capture in `mcp-source.ts` reserves the executable `describe` name from the
run-code runtime, the same owner used by tool assembly.

`configure_task_check_in` preserves the source's synchronous `target` callback
contract and maps seconds to native scheduler milliseconds. Returning a Promise
here serializes as `{}` in the source tool, while an `id` parameter loses named
aliases; the adapter uses `ConfigureTaskCheckInParams` from the tool schema to keep
that boundary explicit.

`createDirectSubagentTools` in `src/delegation/direct/subagent-tools.ts` exposes source callback
contracts over Session's admitted nested requests and task controls:

- Built-in roles use the session pool selector once per spawn; custom role
  definitions load without being passed to that built-in-only selector.
- Prompt construction passes actual offered definitions, search policy,
  settings, execution context, and skills to source `buildInstructions`.
- Foreground callbacks request foreground execution and return results, not
  background admission handles. Result projection rejects a background receipt
  in these result-only lanes. Background launch returns an accepted run ID,
  role, and the original prepared task input.
- Results preserve accepted outcome and execution evidence. Native budget
  exhaustion maps to the source's budget interruption; known interruption
  causes are preserved. An interruption with no supplied cause stays
  unclassified: the adapter must not invent a provider-continuation cause or
  imply an approval pause. Native task lifecycle remains Session-owned.
- The source prompt builder in `src/delegation/subagents/role-loader.ts` omits
  local memory guidance and context for remote execution. Those optional memory
  sections must not be dereferenced on the remote path.

The compile-time seam matters: changing source callback signatures, schemas, or
host projection types must be reconciled here, not hidden with casts or invented
terminal data. A successful typecheck establishes contract compatibility, not
provider execution, approval/reconnect behavior, or continuation parity.

Native subagent task IDs use the source codename vocabulary so model-targeted
handles remain pronounceable; they are still the Session's canonical task IDs,
not aliases layered over UUIDs. `subagent-tools.ts` inherits output
allocation through the same configured-setting/catalog policy as the source
runner; an explicit role allocation still wins. `itemToInput` canonicalizes
text-only assistant context without rewriting accepted Items or live deltas.
`directTaskNotice` renders accepted child outcomes in the source completion
wording, while persistence keeps native task/branch facts and delivery receipts.

### Async child questions

`createDirectSubagentTools` passes the real source `ask_orchestrator` callback
only for background launches; the source factory still excludes mentor and
reviewer. Foreground/result-only children do not acquire the capability, even
if later moved to background. The callback reaches the executing child's
`ToolContext.app.askOrchestrator`, not a user question or a legacy subagent registry.

`DirectBackgroundTasks` owns one correlated pending question per task. Session
accepts `task_question_opened` together with a planning notice; its existing
idle `drainBackgroundNotifications` admits the orchestrator's silent turn.
The orchestrator must reply before waiting for the child's result. This path
does not preempt an active root turn. `send_message` with a matching `reply_to`
accepts the closure before resolving the exact child call. Wrong IDs and
uncorrelated steering cannot consume it; ordinary steering outside a question
remains unsupported. Stop, settlement and writer failure reject pending waits;
process-loss recovery records interruption and never reconstructs a waiter.
Public task snapshots carry `pendingQuestion` separately from user interactions.

### Local shell task bridge

The default surface follows the frozen old CLI's existing session mode:
local interactive sessions receive the shell registry/output capability; batch
and SSH sessions do not. `createToolSurface` uses the existing `interactive`
signal, not a new feature flag. The unchanged old/direct batch goldens pin prompt
text, shell and `run_code` schemas, and advertised tools only for that mode;
interactive shell jobs require their own actual-session verification.
Subagent background controls are not shell-job controls.

`createDirectShellTools` adapts the source shell's prepared runner to the
engine-injected `ToolContext.app.shellTasks` port. The adapter does not instantiate
the source lifecycle registry: the native Session admits a `kind: 'shell'` task
before running a command, and the source job ID is that task's canonical ID.
Foreground leases use the same task when moved to background. Source command
policy and pre-execution approvals still run before this admission; the bridge
does not grant approval or add a second engine loop. SSH background shell remains
unavailable through this local bridge.

Session stop/close and `/restart stop` wait for the prepared runner **and its
cleanup**, including cleanup of a background admission cancelled before kickoff.
An abort request alone is not a terminal receipt. Shell controls reject other
Sessions' IDs and non-shell tasks; monitor cancellation also resolves the watch's
job through the invoking Session, since a retained surface can serve several
Sessions. The shell adapter keeps only live watch/output
callbacks; terminal state and formatted process results live in Session facts.
Monitor firings use the admitted launch handle's `notify` callback, retaining its
physical execution identity even when a later monitor invocation schedules replay.
Resolving ambient execution identity at timer delivery can instead attribute the
launcher's notification to the monitor and silently fail Session's ownership check.
Synchronous controls still resolve the invoking Session. Monitor firings enter
the existing durable background-notice lane. Raw progress
and watch buffers do not survive process loss; unfinished recovered tasks become
interrupted, not reattached subprocesses. Sandbox post-execution pauses are not
introduced by this bridge.

## Control socket and `/settings`

The direct CLI supports the standalone `control` client and `--control-socket=<name>` interactive startup. Both use the private `XDG_RUNTIME_DIR` advertisement and the same socket protocol; the help must not mark control, or any other dispatched subcommand, as unavailable. A socket is opt-in, not started by a normal launch.

The direct `/settings` command presents a category index and three-item category pages (`/settings <category> [page]`) with descriptions and redacted secret values instead of dumping all settings into the unscrollable notice. Existing `/settings <key> [value]` and reset routes remain the editing interface and retain their session/restart restrictions.

## ACP session resources

`createAcpSessions` in `acp/acp-sessions.ts` owns ACP-supplied MCP managers per native
session. `open` validates the full list, starts connections with explicit cwd,
environment and HTTP headers, and installs the immutable source through initial
creation or an exact accepted native configure receipt. An async-local candidate
is visible only to that creation/configuration, not sibling sessions. MCP calls
remain script-only and require the ordinary native permission exchange. No
client-supplied credentials are persisted in settings. ACP selects the manager’s
`httpRedirect:error` policy so forwarded HTTP headers cannot follow redirects.

Failed preparation leaves the existing source intact. After native acceptance,
the source stays owned even if obtaining a fresh Host view fails. Older managers
are retained until explicit Session drain because older tool generations may
still reference them. `drain` rejects new setup and waits for admitted setup
operations before `app.close`; `shutdown` then closes managers. Host
`closeSession` releases native work/attachments without deleting retained logs.
A reopened session replaces the old entry in `createDirectMcpRefresh` so later
catalog notifications target the new runtime.
