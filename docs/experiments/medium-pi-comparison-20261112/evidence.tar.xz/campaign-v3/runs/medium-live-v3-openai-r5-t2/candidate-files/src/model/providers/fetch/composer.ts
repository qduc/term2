import { composeFetch, FetchMiddleware } from './compose.js';
import { createLoggingMiddleware } from './logging-middleware.js';
import { createRateLimitMiddleware } from './rate-limit-middleware.js';
import type { ILoggingService } from '../../../shared/service-interfaces.js';

export type CreateProviderFetchOptions = {
  providerId: string;
  defaultModel: string;
  deps: {
    loggingService: ILoggingService;
    sessionContextService?: any;
    onDispatched?: () => void;
  };
  middlewares?: FetchMiddleware[];
  fetchImpl?: typeof fetch;
};

export function createProviderFetch({
  providerId,
  defaultModel,
  deps,
  middlewares = [],
  fetchImpl = fetch,
}: CreateProviderFetchOptions): typeof fetch {
  const dispatchFetch: typeof fetch = (input, init) => {
    const response = fetchImpl(input, init);
    deps.onDispatched?.();
    return response;
  };
  const logging = deps.loggingService.providerTraffic
    ? [
        createLoggingMiddleware({
          provider: providerId,
          model: defaultModel,
          providerTraffic: deps.loggingService.providerTraffic,
        }),
      ]
    : [];
  return composeFetch(dispatchFetch, [
    // Preprocessing and decorators execute first (outermost)
    ...middlewares,
    // Do not tee the response body when no recorder consumes the clone. Apart
    // from wasting memory, an unread tee branch can hold an in-band error stream
    // open; active recorders retain the response clone and its terminal frame.
    ...logging,
    // Rate-limit runs innermost so it checks the raw response and throws before
    // the SDK can process a 429 with retry-after > 60s
    createRateLimitMiddleware(),
  ]);
}
