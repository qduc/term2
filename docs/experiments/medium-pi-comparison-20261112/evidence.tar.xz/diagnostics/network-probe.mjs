import fs from 'node:fs';
const result={nodeUseEnvProxy:process.env.NODE_USE_ENV_PROXY??null,method:'GET',path:'/v1/models',paidInference:false,at:new Date().toISOString()};
try{const r=await fetch('https://api.openai.com/v1/models',{headers:{authorization:`Bearer ${process.env.OPENAI_API_KEY}`},signal:AbortSignal.timeout(12000)});result.status=r.status;result.providerRequestId=r.headers.get('x-request-id');await r.body.cancel();}catch(e){result.error=e.message;result.causeCode=e.cause?.code??null;result.causeName=e.cause?.name??null;}
console.log(JSON.stringify(result));
fs.writeFileSync(process.argv[2],JSON.stringify(result,null,2)+'\n');
