import { testCliPath } from '../../tests/helpers/terminal-e2e.js';
// Each entry file registers one scenario group. Vitest's default file isolation
// evaluates this module separately for each group: the active fixture resources
// and afterEach cleanup below are never shared across concurrent files. Cases
// within each group remain sequential, with their original assertions/deadlines.

import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { execFile } from 'node:child_process';
import { promisify, stripVTControlCharacters } from 'node:util';
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { Socket } from 'node:net';
import { afterEach, describe, expect, it } from 'vitest';
import { WebSocketServer, type WebSocket } from 'ws';
import {
  createIsolatedWorkspaceLease,
  DEFAULT_TIMEOUT_MS,
  writePtyTextAndSubmit,
  type IsolatedWorkspaceLease,
  type PtyChildDriver,
} from './provider-test-harness.js';

const MODEL = 'gpt-5.6-luna';
const FIRST_RESPONSE_ID = 'resp-first';
const SECOND_RESPONSE_ID = 'resp-second';
const TOOL_RESPONSE_ID = 'resp-tool-producing';
const TOOL_RESUMED_RESPONSE_ID = 'resp-tool-resumed';
const TOOL_CALL_ID = 'call-fixture-approval';
const TOOL_ITEM_ID = 'item-fixture-approval';
const TOOL_ARGUMENTS_PARTS = ['{"command":"pwd",', '"sandbox":"unsandboxed"}'] as const;
const TOOL_ARGUMENTS = TOOL_ARGUMENTS_PARTS.join('');
const BACKGROUND_SHELL_CALL_ID = 'call-fixture-background-shell';
const BACKGROUND_SHELL_ITEM_ID = 'item-fixture-background-shell';
// The test releases this shell after observing the launch acknowledgement, so
// completion remains a distinct notification without a fixed sleep.
const BACKGROUND_SHELL_ARGUMENTS = JSON.stringify({
  command: 'while [ ! -e .term2-background-shell-release ]; do sleep 0.05; done',
  background: true,
});

type ProviderId = 'openai' | 'codex';
type Transport = 'http' | 'websocket';
type FixtureMode =
  | 'multi-turn'
  | 'approval'
  | 'session-search'
  | 'nested-shell'
  | 'background-shell'
  | 'native-error'
  | 'incomplete'
  | 'abnormal-close'
  | 'abnormal-close-retry'
  | 'runaway-output';

interface ProviderTransportCase {
  readonly provider: ProviderId;
  readonly transport: Transport;
}

const providerTransportCases: readonly ProviderTransportCase[] = [
  { provider: 'openai', transport: 'http' },
  { provider: 'openai', transport: 'websocket' },
  { provider: 'codex', transport: 'http' },
  { provider: 'codex', transport: 'websocket' },
] as const;

interface CapturedResponsesRequest {
  readonly transport: Transport;
  readonly path: string;
  readonly headers: Record<string, string | string[] | undefined>;
  readonly body: Record<string, unknown>;
}

interface ServedResponse {
  readonly request: CapturedResponsesRequest;
  readonly terminalType?: 'response.completed' | 'response.failed' | 'response.incomplete';
  readonly responseId?: string;
  readonly closedAbnormally: boolean;
}

interface ResponsesFixtureServer {
  readonly baseUrl: string;
  readonly websocketUrl: string;
  readonly requests: CapturedResponsesRequest[];
  readonly served: ServedResponse[];
  readonly websocketConnectionCount: number;
  waitForRequests(
    predicate: (requests: readonly CapturedResponsesRequest[]) => boolean,
    timeoutMs?: number,
  ): Promise<void>;
  releaseRetry(): void;
  close(): Promise<void>;
}

let activeServer: ResponsesFixtureServer | undefined;
let activeWorkspace: IsolatedWorkspaceLease | undefined;
let activeChild: PtyChildDriver | undefined;

afterEach(async () => {
  const child = activeChild;
  const workspace = activeWorkspace;
  const server = activeServer;
  activeChild = undefined;
  activeWorkspace = undefined;
  activeServer = undefined;

  try {
    if (workspace) await writeFile(join(workspace.root, '.term2-background-shell-release'), 'released');
    await child?.cleanup({ timeoutMs: 2_000 });
  } finally {
    try {
      await server?.close();
    } finally {
      await cleanupWorkspace(workspace);
    }
  }
});

export function registerResponsesContinuityScenarios(): void {
  describe('application-owned Responses lifecycle through the shipped CLI', () => {
    it.each(providerTransportCases)(
      '$provider $transport preserves two-turn response chaining',
      async (providerCase) => {
        const server = await startResponsesFixtureServer({
          mode: 'multi-turn',
          retainWebSocket: providerCase.provider === 'codex',
        });
        activeServer = server;
        const workspace = await createWorkspace(server, providerCase);
        activeWorkspace = workspace;
        const child = await startCli(workspace);
        activeChild = child;

        const firstIdle = await child.waitForIdleInput();
        await writePrompt(child, 'first user turn');
        await waitForRequests(server, child, (requests) => normalRequests(requests).length >= 1);
        await waitForIdleAfterResponse(child, firstIdle, 'FIRST-RESPONSE');
        await waitForRequests(server, child, () => server.served.some((item) => item.responseId === FIRST_RESPONSE_ID));

        await writePrompt(child, 'second user turn');
        await waitForRequests(server, child, (requests) => normalRequests(requests).length >= 2);
        await child.waitForVisibleOutput('SECOND-RESPONSE');

        const requests = normalRequests(server.requests);
        expect(requests).toHaveLength(2);
        // The opening turn is cold for every provider and transport: nothing to chain onto.
        expect(requests[0]?.body.previous_response_id).toBeUndefined();
        expect(requests[1]?.body.previous_response_id).toBe(FIRST_RESPONSE_ID);
        expect(
          server.served
            .filter((item) => item.request.body.generate !== false && item.terminalType === 'response.completed')
            .map((item) => item.responseId),
        ).toEqual([FIRST_RESPONSE_ID, SECOND_RESPONSE_ID]);
        expect(requests.every((request) => request.body.model === MODEL)).toBe(true);
        if (providerCase.provider === 'codex') {
          // This is the production CLI → configuration → application-loop →
          // registry seam. Both Codex transports must retain the session-scoped
          // request options, while OpenAI cases above prove they are not generic
          // Responses fields.
          for (const request of requests) {
            expect(request.body.prompt_cache_key).toEqual(expect.any(String));
            expect(request.body.prompt_cache_key).not.toBe('');
            expect(request.body.include).toEqual(expect.arrayContaining(['reasoning.encrypted_content']));
          }
        } else {
          expect(
            requests.every(
              (request) =>
                Array.isArray(request.body.include) && request.body.include.includes('reasoning.encrypted_content'),
            ),
          ).toBe(true);
        }
      },
    );

    it('codex websocket replays full history when the completed response socket is replaced', async () => {
      const server = await startResponsesFixtureServer({ mode: 'multi-turn' });
      activeServer = server;
      const workspace = await createWorkspace(server, { provider: 'codex', transport: 'websocket' }, undefined, 1);
      activeWorkspace = workspace;
      const child = await startCli(workspace);
      activeChild = child;
      const firstIdle = await child.waitForIdleInput();
      await writePrompt(child, 'first reconnect turn');
      await waitForIdleAfterResponse(child, firstIdle, 'FIRST-RESPONSE');
      await writePrompt(child, 'second reconnect turn');
      await child.waitForVisibleOutput('SECOND-RESPONSE');
      const requests = normalRequests(server.requests);
      expect(requests).toHaveLength(2);
      expect(server.websocketConnectionCount).toBe(2);
      expect(requests[1]?.body.previous_response_id).toBeUndefined();
      const input = JSON.stringify(requests[1]?.body.input);
      expect(input).toContain('first reconnect turn');
      expect(input).toContain('FIRST-RESPONSE');
      expect(input).toContain('second reconnect turn');
    });

    it('codex websocket preserves completed tool pairs when the producing socket is replaced', async () => {
      const server = await startResponsesFixtureServer({ mode: 'approval' });
      activeServer = server;
      const workspace = await createWorkspace(server, { provider: 'codex', transport: 'websocket' }, undefined, 1);
      activeWorkspace = workspace;
      const child = await startCli(workspace);
      activeChild = child;
      await child.waitForIdleInput();
      await writePrompt(child, 'run the reconnect approval fixture');
      await child.waitForVisibleOutput('Allow this action?');
      await writeApprovalShortcut(child, 'y');
      await child.waitForVisibleOutput('APPROVED-FINAL');

      const requests = normalRequests(server.requests);
      expect(requests).toHaveLength(2);
      expect(server.websocketConnectionCount).toBe(2);
      const continuation = requests[1]!;
      expect(continuation.body.previous_response_id).toBeUndefined();
      const input = continuation.body.input as Array<Record<string, unknown>>;
      expect(input.filter((item) => item.type === 'function_call' && item.call_id === TOOL_CALL_ID)).toHaveLength(1);
      const results = toolResultItems(continuation);
      expect(results).toHaveLength(1);
      expect(results[0]?.call_id).toBe(TOOL_CALL_ID);
      expect(toolResultText(continuation)).toContain(workspace.root);
    });

    it('session_search through run_code rebuilds the catalogue and finds migrated tool output', async () => {
      const server = await startResponsesFixtureServer({ mode: 'session-search', retainWebSocket: true });
      activeServer = server;
      const workspace = await createWorkspace(server, { provider: 'codex', transport: 'websocket' }, 'session-search');
      activeWorkspace = workspace;
      const child = await startCli(workspace);
      activeChild = child;
      const idle = await child.waitForIdleInput();
      await writePrompt(child, 'search prior tool output');
      await waitForIdleAfterResponse(child, idle, 'SECOND-RESPONSE');
      const requests = normalRequests(server.requests);
      expect(requests).toHaveLength(2);
      expect(requests[1]!.body.previous_response_id).toBe(TOOL_RESPONSE_ID);
      const outputs = toolResultItems(requests[1]);
      expect(outputs).toHaveLength(1);
      expect(outputs[0]!.call_id).toBe(TOOL_CALL_ID);
      const result = toolResultText(requests[1]!);
      expect(result).toContain(SESSION_SEARCH_FIXTURE_ID);
      expect(result).toContain('No healthy model in agent.balancedModel pool');
      expect(result).not.toContain('timed out');
      const output = String(outputs[0]!.output);
      expect(output).toMatch(/^Result:\n\{/);
      const search = JSON.parse(output.split('\n')[1]!);
      expect(search.results[0]).toMatchObject({
        sessionId: SESSION_SEARCH_FIXTURE_ID,
        kind: 'tool',
        messageIndex: 1,
        snippet: { text: expect.stringContaining('No healthy model in agent.balancedModel pool'), truncated: true },
      });
      expect(search.scope).toBe(workspace.root);
      expect(search.unavailable).toBe(0);
      expect(search.charsUsed).toBeLessThanOrEqual(7000);
    });

    it.each(['openai', 'codex'] as const)(
      '%s-websocket.retained-connection keeps two chained turns on one retained connection',
      async (provider) => {
        const server = await startResponsesFixtureServer({
          mode: 'multi-turn',
          retainWebSocket: true,
          rejectReconnect: true,
        });
        activeServer = server;
        const workspace = await createWorkspace(server, { provider, transport: 'websocket' });
        activeWorkspace = workspace;
        const child = await startCli(workspace);
        activeChild = child;

        const firstIdle = await child.waitForIdleInput();
        await writePrompt(child, 'first persistent websocket turn');
        await waitForRequests(server, child, (requests) => normalRequests(requests).length >= 1);
        await waitForIdleAfterResponse(child, firstIdle, 'FIRST-RESPONSE');
        const secondIdle = await child.waitForIdleInput();
        await writePrompt(child, 'second persistent websocket turn');
        await waitForRequests(server, child, (requests) => normalRequests(requests).length >= 2);
        await waitForIdleAfterResponse(child, secondIdle, 'SECOND-RESPONSE');

        const requests = normalRequests(server.requests);
        expect(requests).toHaveLength(2);
        expect(requests.every((request) => request.transport === 'websocket')).toBe(true);
        expect(server.websocketConnectionCount).toBe(1);
        expect(requests[1]?.body.previous_response_id).toBe(FIRST_RESPONSE_ID);
      },
    );
  });
}

export function registerResponsesToolScenarios(): void {
  describe('application-owned Responses lifecycle through the shipped CLI', () => {
    it.each(providerTransportCases)(
      '$provider $transport resumes an approved tool from its producing response',
      async (providerCase) => {
        const server = await startResponsesFixtureServer({
          mode: 'approval',
          retainWebSocket: providerCase.provider === 'codex',
        });
        activeServer = server;
        const workspace = await createWorkspace(server, providerCase);
        activeWorkspace = workspace;
        const child = await startCli(workspace);
        activeChild = child;

        await child.waitForIdleInput();
        await writePrompt(child, 'run the approval fixture');
        await waitForRequests(server, child, (requests) => normalRequests(requests).length >= 1);
        await child.waitForVisibleOutput('Allow this action?');
        await writeApprovalShortcut(child, 'y');
        await waitForRequests(server, child, (requests) => toolResultRequests(requests).length >= 1);
        await child.waitForVisibleOutput('APPROVED-FINAL');

        assertApprovalResume(server, providerCase, 'approved');
        expect(child.getVisibleOutput()).not.toContain('Approval Rejected');
      },
    );

    it.each(providerTransportCases)(
      '$provider $transport resumes a rejected tool exactly once',
      async (providerCase) => {
        const server = await startResponsesFixtureServer({
          mode: 'approval',
          retainWebSocket: providerCase.provider === 'codex',
        });
        activeServer = server;
        const workspace = await createWorkspace(server, providerCase);
        activeWorkspace = workspace;
        const child = await startCli(workspace);
        activeChild = child;

        await child.waitForIdleInput();
        await writePrompt(child, 'run the rejection fixture');
        await waitForRequests(server, child, (requests) => normalRequests(requests).length >= 1);
        await child.waitForVisibleOutput('Allow this action?');
        await writeApprovalShortcut(child, 'n');
        await child.waitForVisibleOutput('Why?');
        await writePrompt(child, 'fixture rejection');
        await waitForRequests(server, child, (requests) => toolResultRequests(requests).length >= 1);
        await child.waitForVisibleOutput('REJECTED-FINAL');

        assertApprovalResume(server, providerCase, 'rejected');
        expect(child.getVisibleOutput()).toContain('fixture rejection');
      },
    );

    it.each(['y', 'n'] as const)(
      'shipped CLI resolves nested shell approval %s and returns one outer tool result',
      async (answer) => {
        const server = await startResponsesFixtureServer({ mode: 'nested-shell' });
        activeServer = server;
        const workspace = await createWorkspace(server, { provider: 'openai', transport: 'http' }, 'nested-shell');
        activeWorkspace = workspace;
        const child = await startCli(workspace);
        activeChild = child;
        await child.waitForIdleInput();
        await writePrompt(child, 'run shell inside the script');
        await child.waitForVisibleOutput('Allow this action?');
        expect(toolResultRequests(server.requests)).toHaveLength(0);
        await writeApprovalShortcut(child, answer);
        if (answer === 'n') {
          await child.waitForVisibleOutput('Why?');
          await writePrompt(child, 'fixture rejection');
        }
        await child.waitForVisibleOutput(answer === 'y' ? 'APPROVED-FINAL' : 'REJECTED-FINAL');
        const requests = normalRequests(server.requests);
        expect(requests).toHaveLength(2);
        const results = toolResultItems(requests[1]);
        expect(results).toHaveLength(1);
        expect(results[0]?.call_id).toBe(TOOL_CALL_ID);
        const output = toolResultText(requests[1]!);
        if (answer === 'y') expect(output).toContain(workspace.root);
        else {
          expect(output).toContain('fixture rejection');
          expect(output).not.toContain('exit 0');
        }
      },
    );

    it('OpenAI HTTP returns a background shell launch acknowledgement before its late completion notification', async () => {
      const providerCase: ProviderTransportCase = { provider: 'openai', transport: 'http' };
      const server = await startResponsesFixtureServer({ mode: 'background-shell' });
      activeServer = server;
      const workspace = await createWorkspace(server, providerCase, 'background-shell');
      activeWorkspace = workspace;
      const child = await startCli(workspace);
      activeChild = child;

      await child.waitForIdleInput();
      await writePrompt(child, 'launch the background shell fixture');
      await child.waitForVisibleOutput('Allow this action?');
      await writeApprovalShortcut(child, 'y');
      await waitForRequests(server, child, (requests) => normalRequests(requests).length >= 2);
      await child.waitForVisibleOutput('BACKGROUND-LAUNCH-FINAL');
      const launchContinuation = normalRequests(server.requests)[1];
      const results = toolResultItems(launchContinuation);
      expect(results).toHaveLength(1);
      expect(results[0]).toMatchObject({ type: 'function_call_output', call_id: BACKGROUND_SHELL_CALL_ID });
      const acknowledgement = parseFunctionResultOutput(results[0]);
      expect(acknowledgement).toMatchObject({ jobId: expect.any(String), status: 'running' });
      await writeFile(join(workspace.root, '.term2-background-shell-release'), 'released');
      await waitForRequests(server, child, (requests) => normalRequests(requests).length >= 3, 10_000);
      await child.waitForVisibleOutput('BACKGROUND-COMPLETION-FINAL');

      const requests = normalRequests(server.requests);
      // A background completion is a separate notification turn, never a second
      // function result for the original tool call.
      expect(
        requests.flatMap(toolResultItems).filter((item) => item.call_id === BACKGROUND_SHELL_CALL_ID),
      ).toHaveLength(1);
      expect(toolResultItems(requests[2])).toEqual([]);

      await child.terminate({ timeoutMs: 2_000 });
    });
  });
}

export function registerResponsesFailureScenarios(): void {
  describe('application-owned Responses terminal failure lifecycle', () => {
    it.each(providerTransportCases)('$provider $transport surfaces native terminal failure', async (providerCase) => {
      await runFailureScenario(providerCase, 'native-error');
    });

    it.each(providerTransportCases)('$provider $transport rejects an incomplete stream', async (providerCase) => {
      await runFailureScenario(providerCase, 'incomplete');
    });

    it.each(providerTransportCases)('$provider $transport stops runaway streamed output', async (providerCase) => {
      await runFailureScenario(providerCase, 'runaway-output');
    });

    it.each(providerTransportCases.filter(({ transport }) => transport === 'websocket'))(
      '$provider websocket rejects an abnormal close without a fabricated completion',
      async (providerCase) => {
        await runFailureScenario(providerCase, 'abnormal-close');
      },
    );

    it.each(providerTransportCases.filter(({ transport }) => transport === 'websocket'))(
      '$provider websocket keeps a failed attempt visible during quiet retry without replaying it',
      async (providerCase) => {
        await runQuietRetryScenario(providerCase);
      },
    );
  });
}

function latestCompleteFrame(output: string): string {
  // Erased PTY frames are not evidence that a message remains on screen.
  const begin = output.lastIndexOf('\x1b[?2026h');
  const end = output.indexOf('\x1b[?2026l', begin);
  return begin < 0 || end < 0 ? '' : stripVTControlCharacters(output.slice(begin, end));
}

async function runQuietRetryScenario(providerCase: ProviderTransportCase): Promise<void> {
  const server = await startResponsesFixtureServer({ mode: 'abnormal-close-retry' });
  activeServer = server;
  const workspace = await createWorkspace(server, providerCase, 'abnormal-close-retry', 1);
  activeWorkspace = workspace;
  const child = await startCli(workspace);
  activeChild = child;
  const idle = await child.waitForIdleInput();
  await writePrompt(child, 'exercise quiet retry');
  await waitForRequests(server, child, (requests) => normalRequests(requests).length === 2);
  const snapshot = await child.waitForState((state) => {
    const frame = latestCompleteFrame(state.output);
    return frame.includes('PARTIAL') && frame.includes('RECOVERED');
  }, 10_000);
  const frame = latestCompleteFrame(snapshot.output);
  expect(frame.match(/PARTIAL/g)).toHaveLength(1);
  expect(frame).not.toMatch(/retrying|error|failed|Stopped/i);
  const retry = normalRequests(server.requests)[1]!;
  expect(retry.body.previous_response_id).toBeUndefined();
  expect(JSON.stringify(retry.body.input)).not.toContain('PARTIAL');
  expect(server.served.filter((item) => item.closedAbnormally)).toHaveLength(1);
  expect(server.served.some((item) => item.terminalType === 'response.completed')).toBe(false);

  server.releaseRetry();
  const settledIdle = await child.waitForIdleInput({ after: idle });
  await writePrompt(child, 'follow up after quiet retry');
  await waitForRequests(server, child, (requests) => normalRequests(requests).length === 3);
  expect(JSON.stringify(normalRequests(server.requests)[2]!.body.input)).not.toContain('PARTIAL');
  await child.waitForIdleInput({ after: settledIdle });
  const files = (await readdir(workspace.paths.conversationsDir)).filter((file) => file.endsWith('.jsonl'));
  expect(files).toHaveLength(1);
  const facts = (await readFile(join(workspace.paths.conversationsDir, files[0]!), 'utf8'))
    .trim()
    .split('\n')
    .map((line) => JSON.parse(line).fact);
  expect(facts.filter((fact) => fact.type === 'text_delta' && fact.withdrawn)).toHaveLength(1);
  expect(facts.filter((fact) => fact.type === 'turn_ended').map((fact) => fact.outcome)).toEqual([
    'completed',
    'completed',
  ]);
  await child.terminate({ timeoutMs: 2_000 });
  // Settled rows move into Ink Static scrollback and need not appear in every
  // redraw. A new CLI must reconstruct the accepted display from the log.
  const resumed = await startCli(workspace, ['--resume', files[0]!.slice(0, -'.jsonl'.length)]);
  activeChild = resumed;
  await resumed.waitForIdleInput();
  await resumed.waitForVisibleOutput('PARTIAL');
  expect(resumed.getVisibleOutput()).toContain('RECOVERED');
  expect(resumed.getVisibleOutput()).toContain('FOLLOWUP');
  expect(resumed.getVisibleOutput()).not.toContain('Stopped');
  expect(normalRequests(server.requests)).toHaveLength(3);
  await resumed.terminate({ timeoutMs: 2_000 });
}

async function runFailureScenario(
  providerCase: ProviderTransportCase,
  mode: Exclude<FixtureMode, 'multi-turn' | 'approval'>,
) {
  const server = await startResponsesFixtureServer({ mode });
  activeServer = server;
  const workspace = await createWorkspace(server, providerCase, mode);
  activeWorkspace = workspace;
  const child = await startCli(workspace);
  activeChild = child;

  await child.waitForIdleInput();
  await writePrompt(child, `exercise ${mode}`);
  await waitForRequests(server, child, (requests) => normalRequests(requests).length >= 1);
  const failureSignal = mode === 'native-error' ? /error|failed/i : /PARTIAL|error|failed|closed|dropped/i;
  await child.waitForState(
    (snapshot) => failureSignal.test(snapshot.visibleOutput) && !snapshot.visibleOutput.includes('SUCCESS'),
    10_000,
  );
  expect(child.getVisibleOutput()).not.toContain('SUCCESS');
  expect(
    server.served.some((item) => item.request.body.generate !== false && item.terminalType === 'response.completed'),
  ).toBe(false);
  if (mode === 'runaway-output') expect(normalRequests(server.requests)).toHaveLength(1);

  await child.terminate({ timeoutMs: 2_000 });
}

function assertApprovalResume(
  server: ResponsesFixtureServer,
  providerCase: ProviderTransportCase,
  decision: 'approved' | 'rejected',
): void {
  const first = normalRequests(server.requests)[0];
  expect(first).toBeDefined();
  expect(first?.body.previous_response_id).toBeUndefined();

  const resumed = toolResultRequests(server.requests);
  expect(resumed).toHaveLength(1);
  expect(resumed[0]?.body.previous_response_id).toBe(TOOL_RESPONSE_ID);

  const input = Array.isArray(resumed[0]?.body.input) ? resumed[0]?.body.input : [];
  const toolResults = input.filter((item) => isRecord(item) && item.type === 'function_call_output');
  expect(toolResults).toHaveLength(1);
  expect(toolResults[0]).toMatchObject({ type: 'function_call_output', call_id: TOOL_CALL_ID });
  expect(toolResults[0]).not.toHaveProperty('callId');
  if (decision === 'rejected') {
    expect(JSON.stringify(toolResults[0])).toContain('fixture rejection');
  }

  const terminalIds = server.served.filter((item) => item.terminalType).map((item) => item.responseId);
  expect(terminalIds).toContain(TOOL_RESPONSE_ID);
  expect(terminalIds).toContain(TOOL_RESUMED_RESPONSE_ID);
}

// The offline migration (the route to this legacy log) accepts only UUID ids.
const SESSION_SEARCH_FIXTURE_ID = '0f2e6c8a-7a51-4c1e-9d3b-5e8f4a2b6c10';

async function createWorkspace(
  server: ResponsesFixtureServer,
  providerCase: ProviderTransportCase,
  mode?: FixtureMode,
  retryAttempts = 0,
): Promise<IsolatedWorkspaceLease> {
  return createIsolatedWorkspaceLease({
    prefix: `term2-provider-session-${providerCase.provider}-${providerCase.transport}-`,
    env: {
      OPENAI_BASE_URL: server.baseUrl,
      CODEX_BASE_URL: server.baseUrl,
    },
    prepare: async (root, paths) => {
      if (mode === 'session-search') {
        await mkdir(paths.conversationsDir, { recursive: true });
        // The store gets this log through the offline migration, which needs a v3 log with a
        // UUID id and the session's configuration.
        const legacyDir = join(root, 'legacy-conversations');
        await mkdir(legacyDir, { recursive: true });
        const events = [
          {
            type: 'session_init',
            id: SESSION_SEARCH_FIXTURE_ID,
            createdAt: '2026-10-04T00:00:00.000Z',
            projectPath: root,
            provider: providerCase.provider,
            model: MODEL,
            activeProfileId: 'builtin:bare',
          },
          { type: 'user_message', message: { id: 'u', sender: 'user', text: 'prior diagnostic' } },
          {
            type: 'command_message',
            message: {
              id: 'c',
              sender: 'command',
              command: 'diagnostic',
              status: 'completed',
              output: 'No healthy model in agent.balancedModel pool. '.repeat(1600),
            },
          },
        ];
        await writeFile(
          join(legacyDir, `${SESSION_SEARCH_FIXTURE_ID}.jsonl`),
          events
            .map((event, seq) => JSON.stringify({ v: 3, seq: seq + 1, ts: '2026-10-04T00:00:00.000Z', event }))
            .join('\n') + '\n',
        );
        const { stdout } = await promisify(execFile)(process.execPath, [
          join(process.cwd(), 'scripts/migrate-conversations.mjs'),
          '--source-copy',
          legacyDir,
          '--destination',
          paths.conversationsDir,
          '--provenance',
          join(root, 'migration-private', 'map.json'),
        ]).catch((error: { stdout?: string }) => ({ stdout: error.stdout ?? '' }));
        expect(JSON.parse(stdout).codes).toEqual({ MIGRATED: 1 });
        // The native disposable catalogue must rebuild from the migrated log.
        await writeFile(`${paths.conversationsDir}.catalogue.sqlite`, 'unavailable fixture catalogue');
      }
      await mkdir(paths.logDir, { recursive: true });
      await writeFile(
        join(paths.logDir, 'settings.json'),
        JSON.stringify({
          agent: {
            modelSelection: { model: MODEL, provider: providerCase.provider },
            transport: providerCase.transport,
            retryAttempts,
            ...(mode === 'runaway-output' ? { maxStreamOutputChars: 32 } : {}),
            openai: { apiKey: 'fixture-key' },
            codex: {
              websocketFirstFrameTimeoutMs: 2_000,
              websocketInterFrameTimeoutMs: mode === 'abnormal-close-retry' ? DEFAULT_TIMEOUT_MS : 2_000,
            },
          },
          app: { liteMode: mode !== 'nested-shell' },
          shell: { autoApproveMode: 'off' },
          sandbox: { enabled: mode !== 'background-shell', allowNetworking: false },
        }),
      );
      if (providerCase.provider === 'codex') {
        await mkdir(paths.codexHome, { recursive: true });
        await writeFile(
          join(paths.codexHome, 'auth.json'),
          JSON.stringify({
            tokens: {
              access_token: fixtureJwt(),
              refresh_token: 'fixture-refresh-token',
              account_id: 'fixture-account',
            },
          }),
        );
      }
    },
  });
}

async function startCli(workspace: IsolatedWorkspaceLease, args: readonly string[] = []): Promise<PtyChildDriver> {
  return workspace.start({
    command: process.execPath,
    // --lite is required: workspace.root is also HOME, and the CLI home-directory
    // start guard blocks interactive non-lite starts when cwd === homedir.
    // Settings app.liteMode is loaded later and does not bypass that guard.
    args: [testCliPath(join(process.cwd(), 'dist/cli.js')), '--lite', ...args],
    cwd: workspace.root,
    cols: 120,
    rows: 40,
  });
}

async function cleanupWorkspace(workspace: IsolatedWorkspaceLease | undefined): Promise<void> {
  if (!workspace) return;
  try {
    await workspace.cleanup();
  } catch (firstError) {
    try {
      await workspace.cleanup();
    } catch {
      throw firstError;
    }
  }
}

function fixtureJwt(): string {
  const encode = (value: unknown) => Buffer.from(JSON.stringify(value)).toString('base64url');
  return `${encode({ alg: 'none', typ: 'JWT' })}.${encode({ exp: Math.floor(Date.now() / 1_000) + 3_600 })}.fixture`;
}

/**
 * Every captured request, with an assertion that none of them is a warmup.
 *
 * This used to filter `generate:false` legs out. Codex no longer sends them --
 * a warmup immediately before the request it prepares bought a serial round
 * trip and a duplicate, uncached prompt charge -- so filtering would now only
 * serve to hide the reappearance of one.
 */
function normalRequests(requests: readonly CapturedResponsesRequest[]): CapturedResponsesRequest[] {
  expect(requests.filter((request) => request.body.generate === false)).toEqual([]);
  return [...requests];
}

async function waitForRequests(
  server: ResponsesFixtureServer,
  child: PtyChildDriver,
  predicate: (requests: readonly CapturedResponsesRequest[]) => boolean,
): Promise<void> {
  try {
    await server.waitForRequests(predicate);
  } catch (error) {
    throw new Error(
      [
        error instanceof Error ? error.message : String(error),
        `child pid: ${child.pid}`,
        `idle generation: ${child.readIdleGeneration()}`,
        `captured requests: ${server.requests.length}`,
        `served responses: ${server.served.length}`,
        `websocket connections: ${server.websocketConnectionCount}`,
        `child output:\n${child.getVisibleOutput()}`,
      ].join('\n'),
    );
  }
}

async function waitForIdleAfterResponse(child: PtyChildDriver, idle: number, marker: string): Promise<void> {
  await child.waitForVisibleOutput(marker);
  await child.waitForIdleInput({ after: idle });
}

async function writePrompt(child: PtyChildDriver, text: string): Promise<void> {
  await writePtyTextAndSubmit(child, text);
}

/** ApprovalPrompt accepts y/n immediately; they are not text submissions. */
async function writeApprovalShortcut(child: PtyChildDriver, decision: 'y' | 'n'): Promise<void> {
  await child.write(decision);
}

function toolResultRequests(requests: readonly CapturedResponsesRequest[]): CapturedResponsesRequest[] {
  return normalRequests(requests).filter((request) => {
    const input = request.body.input;
    return (
      Array.isArray(input) &&
      input.some(
        (item) => isRecord(item) && (item.type === 'function_call_output' || item.type === 'function_call_result'),
      )
    );
  });
}

function toolResultItems(request: CapturedResponsesRequest | undefined): Array<Record<string, unknown>> {
  const input = request?.body.input;
  return Array.isArray(input)
    ? input.filter(
        (item): item is Record<string, unknown> =>
          isRecord(item) && (item.type === 'function_call_output' || item.type === 'function_call_result'),
      )
    : [];
}

function parseFunctionResultOutput(item: Record<string, unknown>): unknown {
  const output = item.output;
  if (typeof output !== 'string') return output;
  return JSON.parse(output);
}

async function startResponsesFixtureServer(options: {
  mode: FixtureMode;
  retainWebSocket?: boolean;
  rejectReconnect?: boolean;
}): Promise<ResponsesFixtureServer> {
  const requests: CapturedResponsesRequest[] = [];
  const served: ServedResponse[] = [];
  const sockets = new Set<Socket>();
  const clients = new Set<WebSocket>();
  let websocketConnectionCount = 0;
  let releaseRetry!: () => void;
  const retryReleased = new Promise<void>((resolve) => {
    releaseRetry = resolve;
  });
  const httpServer = createServer(async (request, response) => {
    sockets.add(request.socket);
    request.socket.once('close', () => sockets.delete(request.socket));
    const captured = {
      transport: 'http' as const,
      path: request.url ?? '/',
      headers: request.headers,
      body: await readJsonBody(request),
    } satisfies CapturedResponsesRequest;
    requests.push(captured);
    await serveResponse(options.mode, captured, response, undefined, served, false, retryReleased);
  });
  const webSocketServer = new WebSocketServer({ noServer: true });

  httpServer.on('upgrade', (request, socket, head) => {
    webSocketServer.handleUpgrade(request, socket, head, (client) => {
      webSocketServer.emit('connection', client, request);
    });
  });
  webSocketServer.on('connection', (client, request) => {
    if (options.rejectReconnect && clients.size > 0) {
      client.close(1008, 'reconnect rejected');
      return;
    }
    websocketConnectionCount += 1;
    clients.add(client);
    client.once('close', () => clients.delete(client));
    let servedRequest = false;
    client.on('message', (raw) => {
      if (servedRequest && !options.retainWebSocket) return;
      servedRequest = true;
      const captured = {
        transport: 'websocket' as const,
        path: request.url ?? '/',
        headers: request.headers,
        body: parseJsonMessage(raw),
      } satisfies CapturedResponsesRequest;
      requests.push(captured);
      void serveResponse(
        options.mode,
        captured,
        undefined,
        client,
        served,
        options.retainWebSocket === true,
        retryReleased,
      );
    });
  });

  await new Promise<void>((resolve, reject) => {
    httpServer.once('listening', resolve);
    httpServer.once('error', reject);
    httpServer.listen(0, '127.0.0.1');
  });
  const address = httpServer.address();
  if (!address || typeof address === 'string') throw new Error('Responses fixture server did not bind');
  const baseUrl = `http://127.0.0.1:${address.port}`;
  let closePromise: Promise<void> | undefined;

  return {
    baseUrl,
    websocketUrl: `ws://127.0.0.1:${address.port}`,
    get websocketConnectionCount() {
      return websocketConnectionCount;
    },
    requests,
    served,
    releaseRetry,
    waitForRequests: async (predicate, timeoutMs = DEFAULT_TIMEOUT_MS) => {
      const startedAt = Date.now();
      while (!predicate(requests)) {
        if (Date.now() - startedAt >= timeoutMs) {
          throw new Error(`Timed out waiting for captured Responses requests; got ${requests.length}.`);
        }
        await delay(25);
      }
    },
    close: async () => {
      if (closePromise) return closePromise;
      closePromise = (async () => {
        releaseRetry();
        for (const client of clients) {
          try {
            client.close(1001, 'fixture shutdown');
          } catch {
            /* best effort */
          }
          if (client.readyState !== client.CLOSED) client.terminate();
        }
        await new Promise<void>((resolve) => webSocketServer.close(() => resolve()));
        for (const socket of sockets) socket.destroy();
        await new Promise<void>((resolve, reject) => {
          httpServer.close((error) => (error ? reject(error) : resolve()));
        });
      })();
      return closePromise;
    },
  };
}

async function serveResponse(
  mode: FixtureMode,
  request: CapturedResponsesRequest,
  httpResponse: ServerResponse | undefined,
  webSocket: WebSocket | undefined,
  served: ServedResponse[],
  retainWebSocket = false,
  retryReleased?: Promise<void>,
): Promise<void> {
  const pushFrames = (frames: readonly Record<string, unknown>[], abnormalClose = false) =>
    sendFrames(httpResponse, webSocket, frames, abnormalClose, retainWebSocket);
  const isWarmup = request.body.generate === false;
  const hasToolResult = Array.isArray(request.body.input)
    ? request.body.input.some(
        (item) => isRecord(item) && (item.type === 'function_call_output' || item.type === 'function_call_result'),
      )
    : false;
  const normalIndex = countNormalServed(served);

  if (isWarmup) {
    await pushFrames([completedFrame(`resp-warmup-${normalIndex}`, [])]);
    served.push({
      request,
      terminalType: 'response.completed',
      responseId: `resp-warmup-${normalIndex}`,
      closedAbnormally: false,
    });
    return;
  }

  if (mode === 'native-error') {
    const responseId = 'resp-native-error';
    await pushFrames([
      createdFrame(responseId),
      {
        type: 'response.failed',
        response: {
          id: responseId,
          status: 'failed',
          output: [],
          error: { code: 'fixture_error', message: 'Injected native provider failure' },
        },
      },
    ]);
    served.push({ request, terminalType: 'response.failed', responseId, closedAbnormally: false });
    return;
  }

  if (mode === 'abnormal-close-retry' && normalIndex > 0) {
    const responseId = `resp-recovered-${normalIndex}`;
    const text = normalIndex === 1 ? 'RECOVERED' : 'FOLLOWUP';
    if (normalIndex === 1) {
      // Hold the successful terminal frame until the test observes both attempts
      // in the current render. No timing sleep or cumulative-output oracle.
      await sendFrames(
        undefined,
        webSocket,
        [createdFrame(responseId), { type: 'response.output_text.delta', delta: text }],
        false,
        true,
      );
      await retryReleased;
      if (webSocket?.readyState !== webSocket?.OPEN) return;
      await pushFrames([
        { type: 'response.output_text.done', text },
        { type: 'response.output_item.done', item: messageOutput(text) },
        completedFrame(responseId, [messageOutput(text)]),
      ]);
    } else {
      await pushFrames([
        createdFrame(responseId),
        ...messageFrames(text),
        completedFrame(responseId, [messageOutput(text)]),
      ]);
    }
    served.push({ request, terminalType: 'response.completed', responseId, closedAbnormally: false });
    return;
  }

  if (mode === 'incomplete' || mode === 'abnormal-close' || mode === 'abnormal-close-retry') {
    const responseId = `resp-${mode}`;
    const frames = [createdFrame(responseId), { type: 'response.output_text.delta', delta: 'PARTIAL' }];
    await pushFrames(frames, mode !== 'incomplete');
    served.push({ request, closedAbnormally: mode !== 'incomplete' });
    return;
  }

  if (mode === 'runaway-output') {
    const responseId = 'resp-runaway-output';
    await pushFrames([
      createdFrame(responseId),
      ...Array.from({ length: 8 }, () => ({ type: 'response.output_text.delta', delta: 'LOOPLOOP' })),
    ]);
    served.push({ request, responseId, closedAbnormally: false });
    return;
  }

  if ((mode === 'approval' || mode === 'session-search' || mode === 'nested-shell') && !hasToolResult) {
    const responseId = TOOL_RESPONSE_ID;
    await pushFrames(
      mode === 'nested-shell'
        ? toolCallFrames(
            responseId,
            'run_code',
            JSON.stringify({
              description: 'Run nested shell',
              code: `try { return await tools.shell(${TOOL_ARGUMENTS}); } catch (e) { return e.message; }`,
            }),
          )
        : mode === 'session-search'
        ? toolCallFrames(
            responseId,
            'run_code',
            JSON.stringify({
              description: 'Search prior tool output',
              code: 'return await tools.session_search({query: "No healthy model in agent.balancedModel pool", kinds: ["tool"], limit: 5, maxChars: 7000});',
            }),
          )
        : toolCallFrames(responseId),
    );
    served.push({ request, terminalType: 'response.completed', responseId, closedAbnormally: false });
    return;
  }

  if (mode === 'background-shell') {
    const responseId = normalIndex === 0 ? 'resp-background-tool' : `resp-background-${normalIndex}`;
    const text = normalIndex === 1 ? 'BACKGROUND-LAUNCH-FINAL' : 'BACKGROUND-COMPLETION-FINAL';
    const frames =
      normalIndex === 0
        ? backgroundShellToolCallFrames(responseId)
        : [createdFrame(responseId), ...messageFrames(text), completedFrame(responseId, [messageOutput(text)])];
    await pushFrames(frames);
    served.push({ request, terminalType: 'response.completed', responseId, closedAbnormally: false });
    return;
  }

  const responseId =
    mode === 'approval' || mode === 'nested-shell'
      ? TOOL_RESUMED_RESPONSE_ID
      : normalIndex === 0
      ? FIRST_RESPONSE_ID
      : SECOND_RESPONSE_ID;
  const text =
    mode === 'approval' || mode === 'nested-shell'
      ? hasToolResult && toolResultText(request).includes('fixture rejection')
        ? 'REJECTED-FINAL'
        : 'APPROVED-FINAL'
      : normalIndex === 0
      ? 'FIRST-RESPONSE'
      : 'SECOND-RESPONSE';
  await pushFrames([
    createdFrame(responseId),
    ...messageFrames(text),
    completedFrame(responseId, [messageOutput(text)]),
  ]);
  served.push({ request, terminalType: 'response.completed', responseId, closedAbnormally: false });
}

function countNormalServed(served: readonly ServedResponse[]): number {
  return served.filter((item) => item.request.body.generate !== false).length;
}

function toolResultText(request: CapturedResponsesRequest): string {
  const input = Array.isArray(request.body.input) ? request.body.input : [];
  const result = input.find(
    (item) => isRecord(item) && (item.type === 'function_call_output' || item.type === 'function_call_result'),
  );
  return result ? JSON.stringify(result) : '';
}

function createdFrame(responseId: string): Record<string, unknown> {
  return { type: 'response.created', response: { id: responseId, status: 'in_progress', output: [] } };
}

function completedFrame(responseId: string, output: readonly Record<string, unknown>[]): Record<string, unknown> {
  return { type: 'response.completed', response: { id: responseId, status: 'completed', output } };
}

function messageOutput(text: string): Record<string, unknown> {
  return { type: 'message', role: 'assistant', content: [{ type: 'output_text', text }] };
}

function messageFrames(text: string): Record<string, unknown>[] {
  return [
    { type: 'response.output_text.delta', delta: text.slice(0, Math.ceil(text.length / 2)) },
    { type: 'response.output_text.delta', delta: text.slice(Math.ceil(text.length / 2)) },
    { type: 'response.output_text.done', text },
    { type: 'response.output_item.done', item: messageOutput(text) },
  ];
}

function toolCallFrames(responseId: string, name = 'shell', argumentsText = TOOL_ARGUMENTS): Record<string, unknown>[] {
  const item = {
    id: TOOL_ITEM_ID,
    type: 'function_call',
    status: 'in_progress',
    arguments: '',
    call_id: TOOL_CALL_ID,
    name,
  };
  return [
    createdFrame(responseId),
    { type: 'response.output_item.added', item, output_index: 0 },
    ...(argumentsText === TOOL_ARGUMENTS ? TOOL_ARGUMENTS_PARTS : [argumentsText]).map((delta) => ({
      type: 'response.function_call_arguments.delta',
      item_id: TOOL_ITEM_ID,
      call_id: TOOL_CALL_ID,
      delta,
      output_index: 0,
    })),
    {
      type: 'response.function_call_arguments.done',
      item_id: TOOL_ITEM_ID,
      call_id: TOOL_CALL_ID,
      arguments: argumentsText,
      output_index: 0,
    },
    {
      type: 'response.output_item.done',
      item: { ...item, status: 'completed', arguments: argumentsText },
      output_index: 0,
    },
    completedFrame(responseId, [{ ...item, status: 'completed', arguments: argumentsText }]),
  ];
}

function backgroundShellToolCallFrames(responseId: string): Record<string, unknown>[] {
  const item = {
    id: BACKGROUND_SHELL_ITEM_ID,
    type: 'function_call',
    status: 'in_progress',
    arguments: '',
    call_id: BACKGROUND_SHELL_CALL_ID,
    name: 'shell',
  };
  return [
    createdFrame(responseId),
    { type: 'response.output_item.added', item, output_index: 0 },
    {
      type: 'response.function_call_arguments.delta',
      item_id: BACKGROUND_SHELL_ITEM_ID,
      call_id: BACKGROUND_SHELL_CALL_ID,
      delta: BACKGROUND_SHELL_ARGUMENTS,
      output_index: 0,
    },
    {
      type: 'response.function_call_arguments.done',
      item_id: BACKGROUND_SHELL_ITEM_ID,
      call_id: BACKGROUND_SHELL_CALL_ID,
      arguments: BACKGROUND_SHELL_ARGUMENTS,
      output_index: 0,
    },
    {
      type: 'response.output_item.done',
      item: { ...item, status: 'completed', arguments: BACKGROUND_SHELL_ARGUMENTS },
      output_index: 0,
    },
    completedFrame(responseId, [{ ...item, status: 'completed', arguments: BACKGROUND_SHELL_ARGUMENTS }]),
  ];
}

async function sendFrames(
  httpResponse: ServerResponse | undefined,
  webSocket: WebSocket | undefined,
  frames: readonly Record<string, unknown>[],
  abnormalClose = false,
  retainWebSocket = false,
): Promise<void> {
  if (httpResponse) {
    httpResponse.writeHead(200, {
      'content-type': 'text/event-stream',
      connection: 'close',
      'cache-control': 'no-cache',
    });
    for (const frame of frames) httpResponse.write(`data: ${JSON.stringify(frame)}\n\n`);
    if (!abnormalClose) httpResponse.end();
    else httpResponse.destroy();
    return;
  }
  if (!webSocket) throw new Error('Responses fixture has no response channel');
  for (const frame of frames) {
    if (webSocket.readyState !== webSocket.OPEN) return;
    await new Promise<void>((resolve, reject) => {
      webSocket.send(JSON.stringify(frame), (error?: Error) => (error ? reject(error) : resolve()));
    });
  }
  if (abnormalClose) webSocket.terminate();
  else if (!retainWebSocket) webSocket.close(1000, 'fixture complete');
}

async function readJsonBody(request: IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = [];
  for await (const chunk of request) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk)));
  return parseJsonMessage(Buffer.concat(chunks));
}

function parseJsonMessage(raw: Buffer | WebSocket.RawData): Record<string, unknown> {
  const text = Buffer.isBuffer(raw) ? raw.toString('utf8') : raw.toString();
  const parsed: unknown = text ? JSON.parse(text) : {};
  if (!isRecord(parsed)) throw new Error('Responses fixture received a non-object request');
  return parsed;
}

function isRecord(value: unknown): value is Record<string, any> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
