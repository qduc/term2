# Medium Term2 versus Pi — live results

The OpenAI primary cohort is complete. Anthropic inference is running under the
user-approved **$30 cumulative cap**, retaining every old reserve and charge.
Sandbox is OFF and tools always approve. Both runners use the same historical
OpenRouter migration task, frozen rubric, source archive, and medium reasoning.
Models: gpt-6-luna; then claude-haiku-5-5. Term2 is unchanged Bare source d277aa0;
Pi is pinned 1.5.2. No product changes or successful-task efficiency win is claimed.

## OpenAI: five repetitions per runner

| Metric | Term2 Bare | Pi |
| --- | ---: | ---: |
| Accepted completions | 0/5 | 0/5 |
| Requests, mean [min–max] | 74.20 [67.00–86.00] | 85.40 [67.00–110.00] |
| API cost, mean [min–max] | $0.084193 [0.073009–0.097691] | $0.104407 [0.075636–0.156096] |
| API cost, sample SD | $0.011237 | $0.031961 |
| Completed-execution time, mean [min–max] | 10.25 [6.67–14.04] | 11.50 [7.95–18.55] |
| Completed-execution time, sample SD | 2.96 | 4.32 |

API cost and request counts include Pi R5's interrupted original attempt:
11 requests, **$0.015769435**. That cost is also retained in the shared ledger.
Its original wall time and buffered CLI stdout are unknown after the environment
restart. Times above describe the completed executions; Pi R5's full-case time
is censored, not zero. Clean completed-execution mean costs, excluding that
infrastructure retry, are $0.084193 for Term2 and $0.101253 for Pi.

Both runners' generated solutions repeatedly missed upstream error details.
Saved baseline controls passed the string/null error-detail cases, while the
completed OpenAI migrations regress those existing behaviors. All ten attempts
failed the full acceptance rubric, despite passing TypeScript. Spending less on
failed work does not establish the quality/cost goal. Five observations and one
historical task do not support a universal ranking or a formal A/A significance
claim.

## Every completed OpenAI execution

| Rep | Runner | Requests | API cost | CLI minutes | HTTP | Supplemental | Accepted |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | pi | 96 | $0.112860 | 11.37 | 43/43 | 10/15 | No |
| 1 | t2 | 68 | $0.094663 | 14.04 | 43/43 | 9/15 | No |
| 2 | pi | 78 | $0.085343 | 11.63 | 42/43 | 8/15 | No |
| 2 | t2 | 67 | $0.073009 | 6.67 | 42/43 | 11/15 | No |
| 3 | pi | 67 | $0.075636 | 8.00 | 43/43 | 11/15 | No |
| 3 | t2 | 72 | $0.076003 | 7.94 | 42/43 | 10/15 | No |
| 4 | pi | 110 | $0.156096 | 18.55 | 43/43 | 11/15 | No |
| 4 | t2 | 78 | $0.079597 | 10.89 | 42/43 | 10/15 | No |
| 5 | pi | 65 | $0.076329 | 7.95 | 42/43 | 11/15 | No |
| 5 | t2 | 86 | $0.097691 | 11.72 | 42/43 | 10/15 | No |

The execution table's Pi R5 cost excludes its separate interrupted attempt; the
case-level table above includes it. Interrupted attempt metadata, final partial
source, native usage, and recovery lineage are preserved. Completed observations
were never selectively rerun; only the environmentally interrupted case received
a fresh execution ID and workspace.

## Exploratory overhead, excluded from primary comparisons

| Provider | Runner | Requests | Native-usage cost | CLI minutes | Outcome |
| --- | --- | ---: | ---: | ---: | --- |
| OpenAI | Term2 | 56 | $0.052978 | 8.01 | Acceptance failed |
| OpenAI | Pi | 60 | $0.078300 | 7.47 | Old request quota truncated |
| Anthropic | Pi | 60 | $0.879542 | 10.04 | Old request quota truncated |

Total pilot cost: **$1.010820005**. Both Pi pilots attempted a 61st request and
received local HTTP 402; their zero exit codes concealed terminal assistant
errors. All pilots, including the normally completed Term2 pilot, are excluded
from the primary balanced cohort. The primary allowance is 200 requests per run
with the same 20-minute timeout. No grader feedback is supplied to coding agents.

The initial transport-only launch retains five uncertain reservations totaling
$2.91. Older campaign reserves also remain. Costs here apply the protocol's
frozen rates to actual native usage, including caching; they are not invoices.
The shared cumulative ledger remains authoritative. The older README/evidence
ZIP records the initial blocked attempt; final artifacts will replace it after
the active Anthropic cohort completes or reaches the approved cap.
