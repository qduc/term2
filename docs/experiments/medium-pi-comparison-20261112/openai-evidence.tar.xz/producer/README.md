# Medium Term2 versus Pi: blocked before comparison

No head-to-head result is available. The first Term2 run failed to reach the
upstream service, made no task edits, and exhausted the available conservative
budget headroom through five transport-error reservations. Pi has not run live.
No quality, speed or cost winner can be inferred.

The selected medium task is the historical built-in OpenRouter migration: base
`c5f0002c3f086d3a7daf99c62fbcd5c6bbf6a3f8`, reference
`7b63338f042bbb3830a828e366abf8213ffe7d5c`. The actual historical change spans
15 files, 494 insertions and 442 deletions, including the owned adapter,
serializer, provider registration, dependencies, documentation and regression
fixtures. This is a much larger task than the prior small benchmark. See
[task.md](task.md) and the frozen [protocol](PROTOCOL.md).

Both agents receive identical full historical snapshots and installed dependencies.
The intended comparison is unchanged Bare Term2 source `d277aa0` versus Pi 1.5.2,
not Term2 variants. Sandbox is OFF and tools are always approved in both arms.
Five repetitions per runner and provider were planned, with alternating order.

## Completed evidence

- Four free actual CLI fixtures passed: Term2 and Pi on both provider protocols.
  Each made two loopback requests, executed its shell tool without an approval
  prompt, and wrote both inside its temporary directory and outside its workspace
  to an owned marker. Fake token usage/cost is excluded from live totals.
- The historical solution passes the full automated rubric: TypeScript, 43 frozen
  real HTTP contracts, 15 independent registry/HTTP/SSE checks, dependency scope,
  frozen offline lock consistency, layers/complexity/rule guards and instruction
  integrity. The starting version fails (42/43 contracts, 9/15 supplemental), as
  expected. Both controls use the same prepared integrity manifest as candidates.
- Independent fault controls detect lost options, continuity and cancellation;
  a mismatched dependency importer is rejected by the offline lock check.
- Reference full-source lint: zero errors, 39 warnings; formatting passes.
  Module documentation and authored test quality still require qualitative review
  for a future successful candidate. Automated green alone is not a full quality
  claim. No successful candidate exists in this attempt.
- Independent verification accepted readiness but its upstream coverage was
  incomplete: loopback fixtures could not detect the parent proxy omission.
  Subsequent independent review agrees reservations must stay and more inference
  cannot fit the current cap.

## Live attempt and accounting

| Runner/model | Completed coding tasks | Physical upstream attempts | CLI wall time | Native metered cost | Unresolved bound |
| --- | ---: | ---: | ---: | ---: | ---: |
| Term2 / gpt-6-luna, repetition 1 | 0 | 5 | 24.741 s | Not available | $2.91 |
| Pi / gpt-6-luna | 0 | 0 | Not measured | Not measured | $0 |
| Term2 / claude-haiku-5-5 | 0 | 0 | Not measured | Not measured | $0 |
| Pi / claude-haiku-5-5 | 0 | 0 | Not measured | Not measured | $0 |

The failed CLI exited 1. The source stayed at the starting version, which failed
acceptance. Treat this as an infrastructure failure, not evidence of model task
quality. There are no completed pairs, per-cell spreads, or meaningful ratios.
All retries and the failed attempt remain in the artifacts and accounting.

Cumulative ledger before this attempt: $1.410903305 natively metered plus $5.286
older conservative reserves, exposure **$6.696903305**. New ledger entries
01756–01760 retain five $0.582 reservations. Cumulative exposure is now
**$9.606903305** of the approved $10 cap, leaving **$0.393096695**, less than a
single OpenAI $0.582 or Anthropic $1.18 send reservation. No actual new charge is
known; zero metered usage must not be called zero spend. The $2.91 is a bound,
not an invoice. Prior unresolved reserves were not reset or released.

## Cause and correction

The launch command omitted `NODE_USE_ENV_PROXY=1` for the **parent budget gateway**;
it set that variable only on the coding-agent subprocesses. I made this setup
error. The unchanged gateway uses native Node fetch, which did not inherit proxy
handling without that startup setting. Five client retries then returned generic
`fetch failed`; the guard retained each reservation and stopped the campaign.

A subsequent credential-safe read-only GET `/v1/models` reproduced `fetch failed`
with `ECONNREFUSED` without the setting and returned HTTP 200 with it. Those free
probes strongly support the cause but cannot retrospectively establish the exact
failure phase or billing outcome for each earlier POST. Each retained record lacks
HTTP status, provider request ID, native usage and a detailed cause. Neither the
author nor verifier released their reservations.

The added [launch.mjs](launch.mjs) re-executes Node with proxy handling enabled,
then checks both providers with a read-only authenticated models-list request
before starting the existing frozen harness. `--probe-only` returned HTTP 200 for
both providers. The exact executed `run.mjs` is retained as `frozen-producer/run.mjs` in the
evidence archive. The current `run.mjs` additionally refuses a live direct launch
without parent proxy handling; resuming the old protocol with changed bytes fails
closed. The budget gateway is unchanged. A route probe proves connectivity, not live inference
compatibility. No paid retry followed the correction.

## Remaining blocker

More matched inference requires either provider billing evidence that settles the
five uncertain requests, or explicit approval for additional cumulative budget
headroom. A proposed cumulative cap of **$15**, retaining all current reserves,
would allow the matched study to restart with the corrected launcher. Raising it
also requires an independently checked budget configuration change; no such
increase has been applied. Do not bypass the shared ledger or start a fresh budget.

The 20-run comparison, quality pass rates, request/cost/time spreads, qualitative
completion review and final native-cost audit remain unfinished. No hosted CI,
model acceptance, product improvement, release or merge is claimed. No product
source was changed.

## Reproduction and evidence

`prepare.py`, `grade.py`, archived `frozen-producer/run.mjs` and
`budget-gateway.mjs` reproduce the frozen attempt. `summarize.py <campaign-dir>` is read-only; its zero-dollar metered field
for an unresolved attempt is not a billing conclusion. `launch.mjs --probe-only`
performs no inference. Avoid running `run.mjs --live` directly.

The evidence ZIP includes the exact Git source tar, frozen HTTP/oracle sources,
producer scripts, full failed-run outputs and final source manifest, all four final
loopback fixtures, independent controls/reviews, network probes, and the complete
cumulative ledger. For this attempt there are request captures but no responses.
Earlier wire bodies remain in the prior Bare hillclimb archive at
`codex/bare-hillclimb-report`, SHA256
`44cb3058a940bce67ba296ac78a89f31770dae2afb8b2324358b512f932a9952`;
this archive retains their ledger entries without duplicating all those bodies.
Consult `evidence-manifest.json` for exact files and hashes.
