from pathlib import Path
import hashlib,json
old=Path('.handoff/frozen-v3-producer');new=Path('docs/experiments/medium-pi-comparison-20261112');changes={}
for name in ['run.mjs','budget-gateway.mjs','grade.py','prepare.py','launch.mjs','task.md']:
 before=(old/name).read_text();after=(new/name).read_text();expected=before
 if name=='budget-gateway.mjs':assert before.count('capUsd <= 15')==1;expected=expected.replace('capUsd <= 15','capUsd <= 30')
 if name=='run.mjs':
  assert before.count('capUsd: 15')==2 and before.count("BENCH_LIVE_APPROVED_CAP_USD !== '15'")==1 and before.count('RESERVATIONS[spec.provider] + 0.01 > 15')==1
  expected=expected.replace('capUsd: 15','capUsd: 30').replace("BENCH_LIVE_APPROVED_CAP_USD !== '15'","BENCH_LIVE_APPROVED_CAP_USD !== '30'").replace('RESERVATIONS[spec.provider] + 0.01 > 15','RESERVATIONS[spec.provider] + 0.01 > 30')
 assert expected==after,name;changes[name]={'changed':before!=after,'oldSha256':hashlib.sha256(before.encode()).hexdigest(),'newSha256':hashlib.sha256(after.encode()).hexdigest()}
protocol=json.loads(Path('.handoff/campaign-v3/protocol-live.json').read_text());assert protocol['capUsd']==15
for name,hash in protocol['hashes'].items():assert hashlib.sha256((old/name).read_bytes()).hexdigest()==hash
source=(new/'run.mjs').read_text();assert source.index("fs.existsSync(path.join(runRoot, 'result.json'))")<source.index("fs.existsSync(path.join(runRoot, 'started.json'))")<source.index('gateway.register(spec.id)')<source.index("write(path.join(runRoot, 'started.json')")
record={'capOnlySourceDiffVerified':True,'allNonBudgetTaskGradingLauncherSourceUnchanged':True,'oldProtocolStillMatchesFrozenCap15Producer':True,'completedResultSkipPrecedesAnyRegistrationOrSpawn':True,'files':changes};Path('.handoff/verifier/cap30-source-review.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'sourceCapOnlyVerified':True,'frozenOldProtocolVerified':True}))
