from pathlib import Path
import tempfile,shutil,json,hashlib,subprocess
v=Path('.handoff/verifier').resolve();base=Path(tempfile.mkdtemp(prefix='cap30-transition-',dir=v));source=Path('docs/experiments/medium-pi-comparison-20261112').resolve();script=source/'apply-cap30-transition.py';old=Path('.handoff/campaign-v3/protocol-live.json').read_bytes();assert json.loads(old)['capUsd']==15;initial=Path('.handoff/v3-initial-ledger.json').read_bytes();controls=[]
for label in ['success','active-writer','unknown-v3','wrong-marker','extra-completed']:
 repo=base/label;root=repo/'.handoff/campaign-v3';wire=root/'wire-live';wire.mkdir(parents=True);(wire/'ledger.json').write_bytes(initial);(root/'protocol-live.json').write_bytes(old);s=repo/'docs/experiments/medium-pi-comparison-20261112';s.mkdir(parents=True)
 for n in ['run.mjs','budget-gateway.mjs','grade.py','prepare.py','task.md','launch.mjs']:shutil.copyfile(source/n,s/n)
 marker=root/'runs/medium-live-v3-openai-r1-pi/started.json';marker.parent.mkdir(parents=True);marker.write_text(json.dumps({'controllerPauseSentinel':True,'agentWasNotStarted':label!='wrong-marker'}));result=root/'runs/medium-live-v3-openai-r1-t2/result.json';result.parent.mkdir();result.write_text(json.dumps({'syntheticOnly':True,'id':'medium-live-v3-openai-r1-t2'}));resultbytes=result.read_bytes()
 if label=='active-writer':(wire/'active.lock').mkdir()
 if label=='unknown-v3':a=json.loads(initial);a.append({'runId':'medium-live-v3-unsettled','priced':None});(wire/'ledger.json').write_text(json.dumps(a))
 if label=='extra-completed':f=root/'runs/medium-live-v3-openai-r2-t2/result.json';f.parent.mkdir();f.write_text('{}')
 ledgerbefore=(wire/'ledger.json').read_bytes();p=subprocess.run(['python3',str(script)],cwd=repo,capture_output=True,text=True,timeout=10);assert (wire/'ledger.json').read_bytes()==ledgerbefore
 if label=='success':
  assert p.returncode==0,p.stderr;lineage=json.loads((root/'protocol-lineage.json').read_text());new=json.loads((root/'protocol-live.json').read_text());before=json.loads(old);expected=json.loads(old);expected['capUsd']=30
  for name in ['run.mjs','budget-gateway.mjs']:expected['hashes'][name]=hashlib.sha256((source/name).read_bytes()).hexdigest()
  assert new==expected;assert (root/'protocol-live.cap15.json').read_bytes()==old;assert result.read_bytes()==resultbytes;assert not marker.exists();assert json.loads((root/'controller-checkpoints/cap30-unstarted-pause.json').read_text())['agentWasNotStarted'];assert lineage['beforeProtocolSha256']==hashlib.sha256(old).hexdigest();assert lineage['afterProtocolSha256']==hashlib.sha256((root/'protocol-live.json').read_bytes()).hexdigest();assert lineage['keptResultSha256']=={'medium-live-v3-openai-r1-t2':hashlib.sha256(resultbytes).hexdigest()};assert lineage['ledgerSha256Before']==hashlib.sha256(ledgerbefore).hexdigest()
 else:assert p.returncode!=0 and marker.exists() and (root/'protocol-live.json').read_bytes()==old and not (root/'protocol-lineage.json').exists(),(label,p.stderr)
 controls.append({'case':label,'pass':True,'exit':p.returncode,'ledgerUnmodified':True})
report={'syntheticOnly':True,'transitionScriptSha256':hashlib.sha256(script.read_bytes()).hexdigest(),'controls':controls,'noActualTransitionOrLedgerChanges':True,'noProviderCalls':True};(v/'cap30-transition-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'controls':len(controls),'passed':len(controls)}))
