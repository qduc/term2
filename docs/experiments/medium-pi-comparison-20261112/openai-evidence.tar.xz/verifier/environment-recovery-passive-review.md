# Passive environment recovery evidence audit

Actual receipts reconcile; no controls, regrades, execution gates, process actions or provider calls by verifier.

Nine prior result files retain their exact hashes. Archived/current protocol hashes match lineage. Deep comparison allows ONLY old unfinished PiR5 plan ID→restart1 and run.mjs hash; task/models/rubric/runtime identities/cap remain unchanged. Both frozen producer snapshots match their respective protocols. Recovery ledger prefix2669rows reconstructs the recorded hash; all1936pre-v3 ledger rows remain unchanged, including$8.196 retained unmetered bounds.

Interrupted PiR5 has11native HTTP200 completed responses, independently reconstructed usage and integer pricing$0.015769435. Two stored request trees reconstruct raw SHA exactly; nine contain documented signature redactions, so original-byte hash reconstruction is unavailable for those. Interrupted source receipt verifies2877files plus recorded symlink/deletion states. There is no completed result for the old execution; CLI stdout was buffered in the terminated coordinator and is unavailable, original agent wall time unknown. Do not infer0walltime or a clean task failure from absent stdout.

Source of applied recovery checks old owner stateZ, exact PI_CODING_AGENT_DIR for possible orphan handling, all settled primary usage, exactly9keptresults and11interrupted requests; recorded orphan list empty. The pre-removal zombie state is parent-captured recovery evidence, not independently recreated afterward. Old owner receipt preserved. No new process operation performed by verifier.

Final reporting: old11charges remain in full campaign AND PiR5fullcase cost alongside clean replacement; show replacement execution separately and full-case wall censored/unknown. Preserve all9completed observations without reruns, and old partial source/captures/metadata. Root summary currently needs explicit case retry/censor fields before final reporting. Costs under exact replacement plan IDs alone would omit the interrupted execution from primary case attribution, even if cumulative ledger totals still contain it.

Evidence environment-recovery-receipt-audit.mjs/json. Completed-run partial native/grade audits additionally reconcile9results/722native responses; interrupted11 are a separate receipt and not silently counted as a completed execution.
