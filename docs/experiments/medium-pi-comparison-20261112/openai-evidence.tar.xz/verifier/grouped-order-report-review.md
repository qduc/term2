# Grouped provider order and terminal reporting review

ACCEPT grouping before v3 execution: pure plan control verifies20 distinct v3 IDs, ten OpenAI then ten Anthropic, five repetitions per runner/provider, exact original(rep+provider-index) runner parity. Fixture plan unchanged. No orchestrator import/execution or API calls in control. grouped-plan-review.mjs/json.

MEDIUM-ALLOWANCE.md records decision before primary cohort, budget reason, all-v2 pilot exclusion(including normally completed T2), unchanged task/rubric/runtime/cap, preserved overhead and remaining200/20minute censoring. No v2 outcome may enter primary v3 paired statistics. Under grouped schedule, provider order determines which cells can fit approved headroom; explicitly show incomplete/unattempted Anthropic cells. Do not generalize a completed OpenAI comparison to both providers. Unmatched attempted runs remain in total cost/failure accounting, while paired deltas use completed pairs only.

Pi terminal stopReason:error reporting matches captured zero-exit402 evidence and preserves frozen qualityPass. acceptedCompletion additionally excludes that terminal error, a separate reporting field rather than changed functional rubric. This detects the observed failure mode; it is not a universal proof of natural completion for every possible CLI stop reason. No new grading feedback reaches agents.

Reporting finding delivered to author: summarize.py genericstartswith('medium-live-') selector conflates primary v3 requests/costs with retained v1/v2 pilots. Primary cohort accounting must select exact protocol plan IDs; retain all-medium/pilot overhead separately and cumulative full-ledger exposure. Pair pass fields should retain frozen pass and accepted-completion fields separately so terminal errors cannot look like accepted pairs. This is a final-report correctness item, not a change to the accepted prospective inference cap/quota controls.

Prior200quota/$15cap loopback controls remain valid: provider ordering does not alter admission/cost/rubric logic. No verifier candidate edits, feedback, ledger changes or paid calls.
