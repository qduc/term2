"""Free copied-launcher controls: fake fetch + stub runner inside unshared network."""
from pathlib import Path
import tempfile,os,subprocess,json,hashlib
verifier=Path('.handoff/verifier').resolve();source=Path('docs/experiments/medium-pi-comparison-20261112/launch.mjs').resolve();base=Path(tempfile.mkdtemp(prefix='launcher-controls-',dir=verifier));env={k:v for k,v in os.environ.items() if not any(x in k for x in ['KEY','TOKEN','SECRET']) and k!='NODE_OPTIONS'};rows=[]
for name,flag,fail,probe in [('startup-reexec-success',False,None,False),('openai-fail-stops',True,'openai',False),('anthropic-fail-stops',True,'anthropic',False),('probe-only-no-run',False,None,True)]:
 case=base/name;case.mkdir();(case/'launch.mjs').write_bytes(source.read_bytes());trace=case/'trace.jsonl';ran=case/'runner.json';preload=case/'fake-fetch.mjs'
 preload.write_text("import fs from 'node:fs';fs.appendFileSync(process.env.CONTROL_TRACE,JSON.stringify({kind:'boot',proxy:process.env.NODE_USE_ENV_PROXY??null})+'\\n');globalThis.fetch=async(url)=>{const origin=new URL(url).origin;fs.appendFileSync(process.env.CONTROL_TRACE,JSON.stringify({kind:'fetch',origin,proxy:process.env.NODE_USE_ENV_PROXY??null})+'\\n');const fail=process.env.CONTROL_FAIL;return new Response('synthetic',{status:fail&&origin.includes(fail)?503:200});};")
 (case/'run.mjs').write_text("import fs from 'node:fs';fs.writeFileSync(process.env.CONTROL_RUNNER,JSON.stringify({args:process.argv.slice(2),proxy:process.env.NODE_USE_ENV_PROXY}));")
 ce={**env,'NODE_OPTIONS':'--import='+str(preload),'CONTROL_TRACE':str(trace),'CONTROL_RUNNER':str(ran),'CONTROL_FAIL':fail or '','HTTPS_PROXY':'http://127.0.0.1:9','OPENAI_API_KEY':'synthetic-key','ANTHROPIC_API_KEY':'synthetic-key'}
 if flag:ce['NODE_USE_ENV_PROXY']='1'
 else:ce.pop('NODE_USE_ENV_PROXY',None)
 cmd=['bwrap','--unshare-net','--unshare-pid','--ro-bind','/','/','--bind',str(case),str(case),'--tmpfs','/tmp','--proc','/proc','--dev','/dev','--die-with-parent','node',str(case/'launch.mjs'),'--probe-only' if probe else '--live']
 p=subprocess.run(cmd,env=ce,capture_output=True,text=True,timeout=15);traceRows=[json.loads(x) for x in trace.read_text().splitlines()];fetches=[r for r in traceRows if r['kind']=='fetch'];assert all(r['proxy']=='1' for r in fetches);assert len(fetches)==(1 if fail=='openai' else 2)
 assert (p.returncode==0)==(fail is None);assert ran.exists()==(fail is None and not probe)
 if ran.exists():assert json.loads(ran.read_text())['proxy']=='1'
 if not flag:assert any(r['kind']=='boot' and r['proxy'] is None for r in traceRows) and any(r['kind']=='boot' and r['proxy']=='1' for r in traceRows)
 rows.append({'case':name,'exit':p.returncode,'fetchStubs':len(fetches),'allFetchesAfterProxyEnabledStartup':True,'stubRunnerInvoked':ran.exists(),'trace':traceRows})
report={'syntheticOnly':True,'launcherSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'noActualProviderCalls':True,'noRealRunnerExecution':True,'controls':rows,'scope':'Exact copied launcher with verifier-only fake fetch preload and stub run.mjs, unshared network/PID, dummy keys. Proves sequencing/fail-closed behavior, not provider reachability.'};(verifier/'launcher-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'controls':len(rows),'passed':len(rows)}))
