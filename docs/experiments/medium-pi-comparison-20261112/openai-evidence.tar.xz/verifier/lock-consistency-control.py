from pathlib import Path
import tempfile,shutil,json,os,subprocess,hashlib
v=Path('.handoff/verifier').resolve();base=Path(tempfile.mkdtemp(prefix='lock-control-',dir=v));reference=Path('/workspace/term2/.worktrees/medium-task-reference');env={k:x for k,x in os.environ.items() if not any(y in k for y in ['KEY','TOKEN','SECRET']) and k!='NODE_OPTIONS'};env.update({'NODE_USE_ENV_PROXY':'0','pnpm_config_pm_on_fail':'ignore'})
for name in ['pnpm-lock.yaml','pnpm-workspace.yaml','web-client/package.json']:
 dest=base/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(reference/name,dest)
shutil.copytree(reference/'patches',base/'patches');pkg=json.loads((reference/'package.json').read_text());pkg.pop('devEngines',None);(base/'package.json').write_text(json.dumps(pkg));original=(base/'pnpm-lock.yaml').read_text();assert original.count('specifier: ^6.9.1')==1
cmd=['bwrap','--unshare-net','--unshare-pid','--ro-bind','/','/','--bind',str(base),str(base),'--proc','/proc','--dev','/dev','--die-with-parent','node','/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/pnpm/bin/pnpm.cjs','--pm-on-fail=ignore','--fetch-retries=0','--fetch-timeout=1000','install','--lockfile-only','--trust-lockfile','--frozen-lockfile','--ignore-scripts','--offline','--store-dir',str(base/'store')]
results=[]
for label,text,expected in [('consistent-reference',original,True),('mismatched-importer',original.replace('specifier: ^6.9.1','specifier: 0.0.0'),False)]:
 (base/'pnpm-lock.yaml').write_text(text);p=subprocess.run(cmd,cwd=base,env=env,capture_output=True,text=True,timeout=30);(v/('lock-'+label+'.txt')).write_text(p.stdout+p.stderr);assert (p.returncode==0)==expected,(label,p.stdout,p.stderr);results.append({'label':label,'exitCode':p.returncode,'expectedAccepted':expected})
report={'offlineOnly':True,'gradingCopyOnlyDevEnginesOmitted':True,'trustLockfileValidatesConsistencyNotRegistrySafety':True,'noPackageCodeInstalled':True,'controls':results};(v/'lock-consistency-control.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
