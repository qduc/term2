from pathlib import Path
import json,hashlib,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.handoff/campaign-v3');partial='--partial' in sys.argv
if not partial:assert not (root/'wire-live/active.lock').exists()
plan={r['id'] for r in json.loads((root/'protocol-live.json').read_text())['plan']};rows=[]
for file in (root/'runs').glob('*/result.json'):
 r=json.loads(file.read_text());run=file.parent.name
 if run not in plan:continue
 manifest=json.loads((file.parent/'manifest.json').read_text());hashes=json.loads((file.parent/'candidate-source.json').read_text());copy=file.parent/'grading-copy';original=Path(manifest['workspace']);same=0
 for name,digest in hashes.items():
  if not name.startswith('src/'):continue
  if digest is None:assert not (copy/name).exists();continue
  assert isinstance(digest,str);assert hashlib.sha256((copy/name).read_bytes()).hexdigest()==digest;same+=1
 expectedFrozen=Path('.handoff/grading-source/provider-black-box')
 for fixed in expectedFrozen.rglob('*'):
  if fixed.is_file():assert (copy/'scripts/provider-black-box'/fixed.relative_to(expectedFrozen)).read_bytes()==fixed.read_bytes()
 grade=json.loads((file.parent/'grade.json').read_text());assert grade==r['grade'];assert grade['pass']==all(grade['checks'].values());assert r['qualityPass']==(r['exitCode']==0 and not r['timedOut'] and grade['pass']);contracts=json.loads((file.parent/'contracts.json').read_text()) if (file.parent/'contracts.json').exists() else None;supplement=json.loads((file.parent/'supplement.json').read_text()) if (file.parent/'supplement.json').exists() else None
 if contracts:assert grade['contractPassed']==contracts['numPassedTests'] and grade['contractTotal']==contracts['numTotalTests'];assert grade['checks']['frozenHttpContracts']==bool(contracts['success'])
 if supplement:assert grade['supplementPassed']==sum(c['pass'] for c in supplement['results']);assert grade['supplementTotal']==len(supplement['results']);assert grade['checks']['supplementalContracts']==all(c['pass'] for c in supplement['results']);assert Path(supplement['staticRoot'])==original
 rows.append({'runId':run,'arm':r['arm'],'provider':r['provider'],'qualityPass':r['qualityPass'],'checks':grade['checks'],'contractPassed':grade['contractPassed'],'contractTotal':grade['contractTotal'],'supplementPassed':grade['supplementPassed'],'candidateSrcFilesIdenticalInGradingCopy':same,'frozenReferenceTestHelpersUnchanged':True,'qualitativeReviewRequired':r['qualityPass']})
Path('.handoff/verifier/medium-grade-audit-'+root.name+('-partial' if partial else '')+'.json').write_text(json.dumps({'partial':partial,'completedRuns':len(rows),'rows':rows,'scope':'Measured source receipt versus grading copy, immutable reference test helpers, exact stored grade booleans/counts. Docs/authored coverage/lint require separate qualitative acceptance.'},indent=2)+'\n');print(json.dumps({'completedRunGradesVerified':len(rows),'partial':partial}))
