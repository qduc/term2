# Independent historical OpenRouter oracle review

ACCEPT supplemental oracle for the bounded historical migration task, pending inspection of primary frozen-suite grading integration and actual CLI automatic-approval fixtures before paid readiness. No actual API/model calls made.

Base `c5f0002c3f086d3a7daf99c62fbcd5c6bbf6a3f8`; reference `7b63338f042bbb3830a828e366abf8213ffe7d5c`. Reviewed f17e885e2 migration,189a5bde7 follow-up,7b63338f0 rollback. Reference explicitly does NOT fix held-open in-band failure with a recorder actively reading its clone. This behavior is excluded from acceptance; a closed-stream recorder-retention scenario is included.

Oracle `.handoff/verifier/openrouter-supplement.mjs` SHA256 `15970d564a3190730909d3f339bffa9c9ed96d8c4c60dd24b31ff4b512b691a6`.
Invocation: `node --import <candidate-or-grading-copy>/node_modules/tsx/dist/loader.mjs openrouter-supplement.mjs DYNAMIC_ROOT OUTPUT_JSON [STATIC_ROOT]`.
For reference-owned dependency grading copies with candidate src overlay, pass original candidate workspace as STATIC_ROOT: package/lock and obsolete-source cleanup must not silently inspect reference bytes instead.

Fifteen cases cross real registry→provider→loopback HTTP/SSE boundaries in credential-scrubbed bwrap network/PID namespaces. External fetches additionally rejected in-process; per-case3.5s bound and per-request1.5s signal. Reference15/15GREEN; base9/15RED. Six discriminating base failures: actual owned-chat-class delegation, SDK dependency/obsolete-path cleanup, reported upstream provider metadata, object-valued upstream raw error detail, in-band upstream detail, native reasoning/tool continuity. Existing option behavior passes base and reference, guarding compatibility rather than implying a new gain.

Coverage includes three option-layer flattening and priority; top/nested explicit reasoning versus selected effort; default effort omission; no-tools tool_choice omission; HTTP referrer/title preservation; upstream metadata; HTTP and SSE string/object/null detail; no-op recorder held-open error settlement; closed-stream active-recorder frame retention; reasoning_details/tool-call/result replay and other-provider dialect/metadata isolation. Actual owned adapter reuse is instrumented through its real prototype during a registry HTTP completion, not inferred from an unused import.

Three verifier-only runtime fault injections are killed by the oracle: discarded options, discarded provider continuity, unread no-op response clone. They do not modify any production/harness source. run-supplement-controls.py and supplement-controls.json retain controls; exact baseline/reference reports retain all pass/fail labels.

Both original historical revisions independently typecheck successfully using their own installed `node_modules/.bin/tsc --noEmit --project tsconfig.json` under network-isolated read-only root. source-typechecks.json and base/reference-typecheck.log retain evidence.

Limits: these deterministic boundaries do not prove compatibility with live OpenRouter traffic or general task quality. Dependency/static-root integration and runtime deadlines must remain intact when applied to model outputs. Reference-owned tests/helpers must stay fixed, candidate-owned tests cannot substitute. No claim that the held-open active-recorder bug is fixed. Automatic approval/sandbox-off application execution still requires actual fixture observation on both runners before paid comparison.
