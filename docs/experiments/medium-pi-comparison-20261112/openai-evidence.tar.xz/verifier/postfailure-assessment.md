# Independent postfailure budget and launcher assessment

KEEP all five reservations; do not release them based on retrospective transport probes. Further paid comparison is blocked by the existing cumulative$10 cap. Verifier made no actual provider/API calls and did not alter ledger or frozen run.mjs.

## Failed attempt evidence

Physical attempt IDs01756–01760, one initial medium-live-openai-r1-t2 turn. Each reserves$0.582, totals$2.910. Each record has generic `fetch failed`, no HTTP status, no native usage or provider request ID, no captured per-attempt nested cause. Identical request-body hashes and timing support repeated transport failure but do not establish nonbilling. Run exit1; candidate.patch empty; no completed native model task output. This is an infrastructure-failed launch, not comparative model task-quality evidence.

Subsequent free GET/models observations: no NODE_USE_ENV_PROXY gives fetch failed/ECONNREFUSED; startup NODE_USE_ENV_PROXY=1 gives200 with request ID. This strongly supports the omitted parent-process proxy setting as cause. Those later requests do not establish the transport stage or billability of each earlier POST. No retrospective reserve release is justified without authoritative per-attempt/provider billing evidence.

Current conservative exposure$9.606903305 = prior$6.696903305 +$2.910 new unmetered bounds. Available$0.393096695 is below one OpenAI$0.582 or Anthropic$1.180 worst-case reservation (also below run-start margin). These bounds are not a claim that$2.910 was charged. Resume requires explicit additional approved cumulative headroom or evidence resolving the retained bounds; no inference is authorized by this review. Old campaign usage and reserves must remain counted.

My readiness review did not verify parent-gateway startup proxy configuration. Free CLI loopbacks verified application routing/tool effects but could not establish upstream reachability. The reservation guard bounded exposure; unknown-usage stopping occurred after the logical turn, allowing five transport retries before the outer stop. Do not claim immediate physical-attempt circuit breaking.

## Corrected launcher

ACCEPT launch.mjs sequencing for the actual HTTPS_PROXY environment. It re-executes Node with NODE_USE_ENV_PROXY=1 at startup, gates the runner on successful read-only models-list probes to both providers, and does not serialize headers or raw client objects. --probe-only does not invoke the runner. Parent's corrected-launch-probes.txt records200/200 free native GETs; this is reachability evidence, not inference acceptance or retrospective billing evidence.

Independent launcher-controls.py/json:4/4 synthetic controls pass using exact copied launcher, fake fetch preload, dummy keys, stub runner, unshared network/PID namespace. Success reexec verified all fetch stubs see enabled startup environment; OpenAI failure stops before second probe/runner; Anthropic failure stops before runner; probe-only never runs. No real provider or actual run.mjs execution in these controls. Launcher SHA256 is pinned in launcher-controls.json. Frozen paid producer remains unchanged. Launcher is a separately documented postfailure correction, not part of the original completed inference evidence.

Limit: direct invocation of old frozen run.mjs bypasses the launcher. Use the corrected launcher if future execution is separately authorized; no more paid calls under current remaining headroom. Medium comparison is incomplete, with no matched Term2/Pi outcome or efficiency conclusion.
