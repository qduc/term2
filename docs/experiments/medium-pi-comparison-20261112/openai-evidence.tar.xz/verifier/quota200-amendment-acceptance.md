# Independent request-quota amendment acceptance

ACCEPT new balanced v3 cohort readiness after current v2 run exits naturally and the controller pause checkpoint stops v2. Cumulative approval remains$15; no reserve releases or verifier paid/provider calls.

Only measured producer changes reviewed: per-run physical request ceiling60→200, live IDs v2→v3. Same native models/medium/32K,20minute CLI boundary,$15 per-send reservation check, task/rubric, runtime identities, approval/sandbox settings, ordering and serial20-run plan. Four cap200 actual CLI fixtures pass; five task/runtime/grader/oracle identities exactly match cap15 preflights. Old v2 six-file producer snapshot hashes match original v2 protocol, allowing historical audit without substituting amended code.

Private loopback controls:199 seeded priced requests for one run allow200th physical request;201st rejected402 before upstream. Exactly1 upstream contact, reservation/request file persisted first. Dollar headroom ample at rejection, proving request-quota branch. Existing cap15 controls independently rerun: default10 unchanged,16 rejected, synthetic exposure14.3 admits0.582 before upstream then blocks further overspend, prior1760 ledger rows unchanged, exclusive writer/pending lock/reopen persistence retained. Evidence quota200-boundary.mjs/json, quota200-protocol-review.json, quota200-cli-preflight-review.json and cap15-boundary.json.

v2 pause sentinel correctly targets next planned medium-live-v2-anthropic-r1-t2; run.mjs checks existing started.json BEFORE preparation, registration or spawn. Sentinel explicitly says controllerPauseSentinel=true,agentWasNotStarted=true. It is not evidence of an attempted task. No kill or alteration of active CLI is required.

All v2 pilots, including normal-completion T2, must remain outside the primary v3 comparison to avoid outcome-based selection. Retain all pilot costs, source artifacts, native captures, actual quota errors, and intervention chronology as campaign overhead. Complete fresh paired plan if budget permits; report unattempted/incomplete cells and residual200/20minute censoring. No grader feedback or repairs to model outputs; fresh identical snapshots/instructions. Raising an evidenced censoring limit is a methodology amendment, not retrospective promotion of pilot quality or proof an agent would have finished unrestricted.

No final outcome accepted by this readiness review. Data selected before/after amendment must remain distinguishable in final export/report.
