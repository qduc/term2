import { builtinProfileRegistry } from "file:///home/qduc/term2/.worktrees/bare-cheap-additions/dist/services/profiles/registry.js";
const p = JSON.parse(process.env.CHEAP_PROFILE);
builtinProfileRegistry.profiles.set('builtin:bare', p);
